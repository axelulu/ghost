
/*首页手机端js*/
$(document).ready(function(){
  /*下载页js*/
$(".flip").click(function(){
    $(".dl-declaration").slideToggle("slow");
  });
  /*手机端菜单栏*/
       $(".menuicon-label").click(function() {

           $("#zhaicy-nav-mobile__container").addClass('is-visible');                            // 添加当前元素的样式
           $("#mengban").css("display","block"); 
         
       });

       $(".poi-animated_fadeIn-enter-done").click(function() {

         $("#zhaicy-nav-mobile__container").removeClass('is-visible');  
           $("#mengban").css("display","none");                       // 添加当前元素的样式

       });

  /*手机端个人中心*/
  $(".zhaicy_shoujiduan_anniu").click(function() {

           $("#zhaicy-nav-mobile__container2").addClass('is-visible');                            // 添加当前元素的样式
           $("#mengban").css("display","block"); 
         
       });

       $(".poi-animated_fadeIn-enter-done").click(function() {

         $("#zhaicy-nav-mobile__container2").removeClass('is-visible');  
           $("#mengban").css("display","none");                       // 添加当前元素的样式

       });
/*登陆弹窗特效*/
       $(".login-actions").click(function() {

         $("#zhaicy-login-from").addClass('zhaicy-tx');  
         $(".modal").css("display","block");       

           $("#mengban2").css("display","block"); 
       });
  
       $(".unfollowed").click(function() {

         $("#zhaicy-login-from").addClass('zhaicy-tx');  
         $(".modal").css("display","block");       

           $("#mengban2").css("display","block"); 
       });
  
       $(".login-link").click(function() {

         $("#zhaicy-login-from").addClass('zhaicy-tx');  
         $(".modal").css("display","block");       

           $("#mengban2").css("display","block"); 
       });
       
       $(".zhaicy-pc-meng").click(function() {

         $("#zhaicy-login-from").removeClass('zhaicy-tx');  
         $(".single").css("padding-right","0px");
         $(".home").css("padding-right","0px");
         $(".modal").css("display","none");           

         $("#mengban2").css("display","none");     
       });
  
  
  
  /*投诉弹窗特效*/
       $(".outwin-title").click(function() {

         $(".zhaicy-toushu").addClass('zhaicy-tx');  
         $(".zhaicy-toushu").css("display","block");       

           $("#mengban4").css("display","block"); 
       });
       $(".zhaicy-pc-meng4").click(function() {

         $(".zhaicy-toushu").removeClass('zhaicy-tx');  
         $(".single").css("padding-right","0px");
         $(".home").css("padding-right","0px");
         $(".zhaicy-toushu").css("display","none");           

         $("#mengban4").css("display","none");     
       });
  /*评论弹窗特效*/
       $(".zhaicy-comment-active").click(function() {

         $("#zhaicy-comment-reply").addClass('zhaicy-tx');  
         $("#zhaicy-comment-reply").css("display","block");       

           $("#mengban2").css("display","block"); 
       });
       
       $(".zhaicy-pc-meng").click(function() {

         $("#zhaicy-comment-reply").removeClass('zhaicy-tx');  
         $("#zhaicy-comment-reply").css("display","none");       

         $("#mengban2").css("display","none");     
       });
 
  /*表情弹窗特效*/
       $(".zhaicy-reply-button1").click(function() {

         $("#zhaicy-comment-biaoqing").addClass(' ');       

           $("#mengban3").css("display","block"); 
       });
       
       $(".zhaicy-pc-meng3").click(function() {

         $("#zhaicy-comment-biaoqing").removeClass(' ');  

         $("#mengban3").css("display","none");     
       });
  
/*搜索弹窗特效*/
       $("#zhaicy-search-bar2").click(function() {

         $(".zhaicy-search-bar").addClass('zhaicy-tx');
         $(".zhaicy-search-bar").css("display","block");       

           $(".zhaicy-poi-dialog__overlay").css("display","block"); 
       });
/*搜索弹窗特效2*/
       $("#zhaicy-search-bar3").click(function() {

         $(".zhaicy-search-bar").addClass('zhaicy-tx');   
         $(".zhaicy-search-bar").css("display","block");       

           $(".zhaicy-poi-dialog__overlay").css("display","block"); 
       });
  
       $(".zhaicy-poi-dialog__overlay").click(function() {

         $(".zhaicy-search-bar").removeClass('zhaicy-tx'); 
         $(".zhaicy-search-bar").css("display","none");       

         $(".zhaicy-poi-dialog__overlay").css("display","none");     
       });

   });
/** 导航相关JS */
if ($("#scroll-header").length > 0) {
	var new_scroll_position = 0;
	var last_scroll_position;
	var header = document.getElementById("scroll-header");
	window.addEventListener('scroll', function (e) {
		last_scroll_position = window.scrollY;
		if (new_scroll_position < last_scroll_position && last_scroll_position > 10) {
			header.classList.remove("slideDown");
			header.classList.add("slideUp");
		} else if (new_scroll_position > last_scroll_position) {
			header.classList.remove("slideUp");
			header.classList.add("slideDown")
		}
		new_scroll_position = last_scroll_position
	});
}
 
//
$(window).scroll(function () {
	if ($(window).scrollTop() > 100) {
		$("#topBulletins").addClass("active")
	} else {
		$("#topBulletins").removeClass("active")
	}
});

//导航js
$(window).scroll(function () {
	if ($(window).scrollTop() > 135) {
		$("#scroll-header").addClass("zhaicy-scroll-header")
        $("#scroll-header").css("position","fixed")
        $("#scroll-header").css("margin-top","0px")
        $("#topBulletins").css("margin-bottom","-32px")
	} else {
		$("#scroll-header").removeClass("zhaicy-scroll-header")
        $("#scroll-header").css("position","relative")
        $("#scroll-header").css("margin-top","")
        $("#topBulletins").css("margin-bottom","-0px")
	}
});


//side_btn
$(window).scroll(function () {
	if ($(window).scrollTop() > 360) {
		$(".side_btn").addClass("active")
	} else {
		$(".side_btn").removeClass("active")
	}
});
      //$("#back-to-top").click(function() {
      //  $("body,html").animate({
      //    scrollTop: 0
      //  },
      //  800);
      //  return false
      //});
