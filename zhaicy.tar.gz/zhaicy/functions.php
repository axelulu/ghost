<?php
/**
 * Copyright 2016, WebApproach.net
 * All right reserved.
 *
 * @author Zhiyan
 * @date 16/5/27 16:30
 *
 * @license GPL v3 LICENSE
 */
?>
<?php

/* 安全检测 */
//defined( 'ABSPATH' ) || exit;
if (!defined('ABSPATH')) {
    wp_die(__('Lack of WordPress environment', 'tt'), __('WordPress internal error', 'tt'), array('response' => 500));
}

defined('THREAD_DEBUG') || define('THREAD_DEBUG', false);

// 有问题可以这里取消注释开启调试
// defined('TT_DEBUG') || define('TT_DEBUG', true);
// ini_set('display_errors', 'On');
// error_reporting(E_ALL);

/* 小程序信息 */
global $tt_mp_config;
//appid
$tt_mp_config['appid'] = '';
//appsecret
$tt_mp_config['appsecret'] = '';

/* 引入加载器 */
require_once get_template_directory().DIRECTORY_SEPARATOR.'core'.DIRECTORY_SEPARATOR.'functions'.DIRECTORY_SEPARATOR.'func.Loader.php';

/* 请在下方添加你的自定义函数和功能 */
///////////////////////////////////////////////////
/*function my_custom_post_movie() {
  $labels = array(
    'name'               => _x( 'Movies', 'post type 名称' ),
    'singular_name'      => _x( 'Movie', 'post type 单个 item 时的名称，因为英文有复数' ),
    'add_new'            => _x( '新建电影', '添加新内容的链接名称' ),
    'add_new_item'       => __( '新建一个电影' ),
    'edit_item'          => __( '编辑电影' ),
    'new_item'           => __( '新电影' ),
    'all_items'          => __( '所有电影' ),
    'view_item'          => __( '查看电影' ),
    'search_items'       => __( '搜索电影' ),
    'not_found'          => __( '没有找到有关电影' ),
    'not_found_in_trash' => __( '回收站里面没有相关电影' ),
    'parent_item_colon'  => '',
    'menu_name'          => 'Movies'
  );
  $args = array(
    'labels'        => $labels,
    'description'   => '我们网站的电影信息',
    'public'        => true,
    'menu_position' => 5,
    'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
    'has_archive'   => true
  );
  register_post_type( 'movie', $args );
}
add_action( 'init', 'my_custom_post_movie' );

*/

//自定义分类法
add_action('init', 'MBT_post_type');
 function MBT_post_type() {
 register_taxonomy(
 'zhuanti',
 'post',
 array(
 'label' => '专题',
 'rewrite' => array( 'slug' => 'zhuanti' ),
 'hierarchical' => true
 )
 );
 register_taxonomy(
 'teji',
 'post',
 array(
 'label' => '特辑',
 'rewrite' => array( 'slug' => 'teji' ),
 'hierarchical' => true
 )
 );
 }
