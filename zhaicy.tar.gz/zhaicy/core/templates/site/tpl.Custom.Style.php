<?php

/**
 * Copyright (c) 2014-2017, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2017/12/31 11:07
 *
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @see https://webapproach.net/tint.html
 */

?>
<?php
error_reporting(0);

$main_color = tt_get_option('tt_main_color', '#55ca56');

//缓存过期时间
$expires_offset = 3600 * 24 * 7;
header('Content-Type: text/css; charset=UTF-8');
header('Expires: '.gmdate('D, d M Y H:i:s', time() + $expires_offset).' GMT');
//header('Last-Modified: ' . gmdate( "D, d M Y H:i:s", time() - $expires_offset ) . ' GMT');
header("Cache-Control: public, max-age=$expires_offset");

?>
input:focus, textarea:focus {border-color: <?php echo $main_color; ?>}
.form-control:focus, .form-group.focus .form-control {border-color: <?php echo $main_color; ?>}
.form-group.focus .input-group-addon, .input-group.active .input-group-addon, .input-group.focus .input-group-addon {background-color: <?php echo $main_color; ?>;border-color: <?php echo $main_color; ?>;}
.input-group-addon+input.form-control {border-color: <?php echo $main_color; ?>;}
a {color: <?php echo $main_color; ?>}

#cms-stickies>.block-wrapper .sticky-container>.home-heading>span {border-bottom-color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cat-col .cat-container>.home-heading>span {border-bottom-color: <?php echo $main_color; ?>}

#sidebar>.widget>.widget-title>span {border-bottom-color: <?php echo $main_color; ?>}
#sidebar>.widget_float-sidebar>.widget>.widget-title>span {border-bottom-color: <?php echo $main_color; ?>}

.widget_tag-cloud>.widget-content>.tags>a:hover {background-color: <?php echo $main_color; ?>}

body.error-page .wrapper .main #linkBackHome {color: <?php echo $main_color; ?>}

#main>.post>.single-body>.article-header>.post-tags>a {background-color: <?php echo $main_color; ?>; opacity: 0.9;}
#main>.post>.single-body>.article-header>.post-tags>a:hover {background-color: <?php echo $main_color; ?>; opacity: 1;}

#main>.page>.single-body>.article-header>.post-tags>a {background-color: <?php echo $main_color; ?>; opacity: 0.9;}
#main>.page>.single-body>.article-header>.post-tags>a:hover {background-color: <?php echo $main_color; ?>; opacity: 1;}

body.home>#content>#mod-show>#slider>.unslider>.slides-wrap>ul>li>.slider-content>.meta-category>a {background-color: <?php echo $main_color; ?>;}

.widget_hot-posts>.widget-content>article>.entry-detail>h2 a:hover {color: <?php echo $main_color; ?>}
.widget_recent-comments>.widget-content>.comment>.comment-title a:hover {color: <?php echo $main_color; ?>}

.loop-rows article.post>.entry-detail>.entry-header>h2 a:hover {color: <?php echo $main_color; ?>}
.loop-rows article.post>.entry-detail>.entry-header>.entry-meta>.author>a:hover {color: <?php echo $main_color; ?>}

body.home>#content>#mod-show>#popular>.block3-widget>.block3-widget-content>article a:hover {color: <?php echo $main_color; ?>}

#cms-cats>.block-wrapper .cat-col .cat-container>.home-heading>a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cms-cat-s2>.col-left>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cms-cat-s2>.col-right>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cms-cat-s5>.col-full>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cms-cat-s5>.col-small>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cat-col-1_2 .row-small>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cat-col-1_2 .row-big>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cms-cat-s4>.col-large>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cms-cat-s4>.col-small>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cms-cat-s3>.col-left>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cms-cat-s3>.col-right>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cms-cat-s1>.col>article .entry-detail h3 a:hover {color: <?php echo $main_color; ?>}
#cms-cats>.block-wrapper .cat-col-1_2 .row-small>article .entry-detail h3 i {background-color: <?php echo $main_color; ?>}

header.white nav>ul a:hover {color: <?php echo $main_color; ?>}
#main>.post>.navigation a:hover {color: <?php echo $main_color; ?>}
#main>.post>.related-posts article .entry-detail .entry-title a:hover {color: <?php echo $main_color; ?>}

.widget_author-info>.widget-content>.author-card_content>.author-fields>.author-user_level {background-color: <?php echo $main_color; ?>}

body.manage>.wrapper>.main-area .nav>.mg_tabs>li>a.active {color: <?php echo $main_color; ?>}
body.me>.wrapper>.user-area .nav>.me_tabs>li>a.active {color: <?php echo $main_color; ?>}

<?php echo tt_get_option('tt_custom_css', ''); ?>