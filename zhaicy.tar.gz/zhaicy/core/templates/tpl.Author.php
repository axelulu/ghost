<?php
/**
 * Copyright 2016, WebApproach.net
 * All right reserved.
 *
 * Author Template
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2016/08/22 22:01
 * @license GPL v3 LICENSE
 */
?>
<?php

echo 'author-template';

global $wp_query;

var_dump($wp_query);