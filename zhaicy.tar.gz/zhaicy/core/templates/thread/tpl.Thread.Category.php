<?php
/**
 * Copyright (c) 2016-2018, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2018/4/29 下午3:33
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */

?>
<?php tt_get_header(); ?>
<div style="background-image: url(https://chun.zhaicy.com/2018/10/timg-3.jpg);position: fixed; background-size: cover; top: 0; opacity: .3; left: 0; -webkit-filter: blur(5px); filter: blur(5px); right: 0; height: 100vh; z-index: -1;" class="inn-author-page__bg"></div>
<div id="app" class="header white thread-category wrapper container full-page"></div>
<?php tt_get_footer(); ?>
