<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/08/28 17:25
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php tt_get_header(); ?>
<div id="content" style="
    margin-top: 15px;
" class="wrapper">
<div style="background-image: url(<?php echo tt_get_option('zhaicy_bg_1'); ?>);position: fixed; background-size: cover; top: 0; opacity: .3; left: 0; -webkit-filter: blur(<?php echo tt_get_option('zhaicy_blur_1'); ?>); filter: blur(<?php echo tt_get_option('zhaicy_blur_1'); ?>); right: 0; height: 100vh; z-index: -1;" class="inn-author-page__bg"></div>
   <!-- 主要内容区 -->
    <section class="container user-area">
        <div class="inner row">
            <?php load_mod('me/me.NavMenu'); ?>
            <?php load_mod('me/me.Tab.Messages'); ?>
        </div>
    </section>
</div>
<?php tt_get_footer(); ?>