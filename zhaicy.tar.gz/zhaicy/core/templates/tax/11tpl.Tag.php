<?php
/**
 * Copyright 2016, WebApproach.net
 * All right reserved.
 *
 * Tag Template
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2016/08/22 22:03
 * @license GPL v3 LICENSE
 */
?>
<?php tt_get_header(); ?>
<?php $paged = get_query_var('paged') ? : 1; ?>
    <div id="content" class="wrapper">
<div style="background-image: url(<?php echo tt_get_option('zhaicy_bg_1'); ?>);position: fixed; background-size: cover; top: 0; opacity: .3; left: 0; -webkit-filter: blur(<?php echo tt_get_option('zhaicy_blur_1'); ?>); filter: blur(<?php echo tt_get_option('zhaicy_blur_1'); ?>); right: 0; height: 100vh; z-index: -1;" class="inn-author-page__bg"></div>
        <?php $vm = TagPostsVM::getInstance($paged); ?>
        <?php if($vm->isCache && $vm->cacheTime) { ?>
            <!-- Tag posts cached <?php echo $vm->cacheTime; ?> -->
        <?php } ?>
        <?php if($data = $vm->modelData) { $pagination_args = $data->pagination; $tag = $data->tag; $tag_posts = $data->tag_posts; ?>
            <!-- 标签名及介绍信息 -->
            <section style="margin-top: 35px;" class="">
                <div class="container text-center">
                  <h4><a style="padding:2px;background-color:#FFE4E1;"><i class="tico tico-price-tag"></i><span style="font-weight: 900"><?php echo $tag['name']; ?></span></a></h4>
                    <?php if($tag['description'] != ''){ ?><p><?php echo $tag['description']; ?></p><?php } ?>
                </div>
            </section>
            <!-- 标签文章 -->
            <section class="ajaxposts container archive-posts category-posts">
                <div class="ajaxpost row loop-grid posts-loop-grid mt20 mb20 clearfix">
                    <?php foreach ($tag_posts as $tag_post) { ?>
                        <div class="col-md-3">
                            <article id="<?php echo 'post-' . $tag_post['ID']; ?>" class="post type-post status-publish <?php echo 'format-' . $tag_post['format']; ?>">
                                <div class="entry-thumb hover-scale">
                                    <a href="<?php echo $tag_post['permalink']; ?>"><img width="250" height="170" src="<?php echo $tag_post['thumb']; ?>" class="thumb-medium wp-post-image" alt="<?php echo $tag_post['title']; ?>"></a>
                                    <?php echo $tag_post['category']; ?>
                                </div>
                                <div class="entry-detail">
                                    <header class="entry-header">
                                        <h2 class="entry-title h4"><a href="<?php echo $tag_post['permalink']; ?>" rel="bookmark"><?php echo $tag_post['title']; ?></a></h2>
                                        <div class="entry-meta entry-meta-1">
                                            <span class="author vcard"><a class="url" href="<?php echo $tag_post['author_url']; ?>"><?php echo $tag_post['author']; ?></a></span>
                                            <span class="entry-date text-muted"><time class="entry-date" datetime="<?php echo $tag_post['datetime']; ?>" title="<?php echo $tag_post['datetime']; ?>"><?php echo $tag_post['timediff']; ?></time></span>
                                            <span class="comments-link text-muted pull-right"><i class="tico tico-comments-o"></i><a href="<?php echo $tag_post['permalink'] . '#respond'; ?>"><?php echo $tag_post['comment_count']; ?></a></span>
                                            <span class="likes-link text-muted pull-right mr10"><i class="tico tico-favorite"></i><a href="javascript:void(0)"><?php echo $tag_post['star_count']; ?></a></span>
                                        </div>
                                    </header>
                                    <div class="entry-excerpt">
                                        <div class="post-excerpt"><?php echo $tag_post['excerpt']; ?></div>
                                    </div>
                                </div>
                            </article>
                        </div>
                    <?php } ?>
                </div>

                <?php if($pagination_args['max_num_pages'] > $paged) { ?>
                    <!--        <div class="row pagination-wrap clearfix">-->
                    <!--            <nav aria-label="Page navigation">-->
                    <!--                <ul class="pagination">-->
                    <!--                    --><?php //$pagination = paginate_links(array(
//                        'base' => $pagination_args['base'],
//                        'format' => '?paged=%#%',
//                        'current' => $pagination_args['current_page'],
//                        'total' => $pagination_args['max_num_pages'],
//                        'type' => 'array',
//                        'prev_next' => true,
//                        'prev_text' => '<i class="tico tico-angle-left"></i>',
//                        'next_text' => '<i class="tico tico-angle-right"></i>'
//                    )); ?>
                    <!--                    --><?php //foreach ($pagination as $page_item) {
//                        echo '<li class="page-item">' . $page_item . '</li>';
//                    } ?>
                    <!--                </ul>-->
                    <!--            </nav>-->
                    <!--        </div>-->
                <?php } ?>
                <?php if($pagination_args['max_num_pages'] > 1) { ?>
                    <?php tt_pagination($pagination_args['base'], $pagination_args['current_page'], $pagination_args['max_num_pages']); ?>
                <?php } ?>
            </section>
        <?php } ?>
    </div>
<!--ajax加载-->
  <script type="text/javascript" src="<?php echo THEME_ASSET.'/js/jquery-ias.min.js';?>"></script>
 <script type="text/javascript">
   var ias=$.ias({
     container:".ajaxposts",
     item:".ajaxpost",
     pagination:".pagination-new",
     next:".page-numbers",
   });
   ias.extension(new IASSpinnerExtension());
   ias.extension(new IASTriggerExtension({html:'<div style="text-align: center;cursor: pointer;margin-top: 30px;"><button class="hz-btn">加载更多</button></div>',offset:2,}));
   ;ias.extension(new IASNoneLeftExtension({text:'已经加载到天涯海角了！',}));
   ias.on('rendered',function(items){$("img").lazyload({effect:"fadeIn",failure_limit:10})})
</script>  
<?php tt_get_footer(); ?>