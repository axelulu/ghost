<?php
/**
 * Copyright 2016, WebApproach.net
 * All right reserved.
 *
 * Category Template
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2016/08/22 22:03
 * @license GPL v3 LICENSE
 */
?>
<?php tt_get_header(); ?>
<?php
    $cat_id = get_queried_object_id();
    $alt_tpl_cats = tt_get_option('tt_alt_template_cats', array());
    if (isset($alt_tpl_cats[$cat_id]) && $alt_tpl_cats[$cat_id]) {
        load_mod('mod.Category.Blocks');
    } else {
        load_mod('mod.Category.Normal');
    }
?>
<?php tt_get_footer(); ?>