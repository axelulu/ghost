<?php
/**
 * Copyright (c) 2014-2017, WebApproach.net
 * All right reserved.
 *
 * @since 2.1.0
 * @package Tint
 * @author Zhiyan
 * @date 2017/05/24 21:52
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php tt_get_header(); ?>
<?php $fullSlide = tt_get_option('tt_enable_home_full_width_slides', false); ?>
<div id="content" class="wrapper right-aside">
<div style="background-image: url(<?php echo tt_get_option('zhaicy_bg_1'); ?>);position: fixed; background-size: cover; top: 0; opacity: .3; left: 0; -webkit-filter: blur(<?php echo tt_get_option('zhaicy_blur_1'); ?>); filter: blur(<?php echo tt_get_option('zhaicy_blur_1'); ?>); right: 0; height: 100vh; z-index: -1;" class="inn-author-page__bg"></div>
    <?php load_mod(('banners/bn.Top')); ?>
    <?php if(tt_get_option('tt_enable_home_slides', false)) : ?>
        <!-- 顶部幻灯片 + 推荐栏 -->
        <section id="mod-show" class="content-section clearfix <?php if ($fullSlide) echo 'full'; ?>">
            <?php load_mod('mod.HomePopular'); ?>
          <p class="zhaicy-tongzhi"><?php echo tt_get_option('zhaicy_tongzhi'); ?></p>
            <?php if ($fullSlide == false) { load_mod('mod.HomeSlide'); } ?>
        </section>
        <?php load_mod(('banners/bn.Slide.Bottom')); ?>
    <?php endif; ?>
    <!-- 分类模块与边栏 -->
    <section id="mod-insideContent" class="main-wrap content-section clearfix">
        <!-- 分类模块列表 -->
        <?php load_mod('mod.HomeCMSCats'); ?>
        <!-- 边栏 -->
        <?php load_mod('mod.Sidebar'); ?>
    </section>
    <?php if(tt_get_option('tt_home_products_recommendation', false)) { ?>
        <!-- 商品展示 -->
        <section id="mod-sales" class="content-section clearfix">
            <?php load_mod('mod.ProductGallery', true); ?>
        </section>
    <?php } ?>
    <?php load_mod(('banners/bn.Bottom')); ?>
</div>
<?php tt_get_footer(); ?>