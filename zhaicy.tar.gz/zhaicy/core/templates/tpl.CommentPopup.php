<?php
/**
 * Copyright 2016, WebApproach.net
 * All right reserved.
 *
 * Comments Popup Template
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2016/08/22 22:09
 * @license GPL v3 LICENSE
 */
?>
<?php

echo 'comments-popup-template';