<?php 
/* template name: 专题页面
description: template for Git theme 
*/ 
 ?>
<?php tt_get_header(); ?>
<?php
    $args = array(
        'post_type' => 'post', //自定义文章类型名称
        'showposts' => 12, //输出的文章数量，这个可以是缺省值，不用设置
        'tax_query' => array(
            array(
                'taxonomy' => 'zhuanti',//自定义分类法名称
                'terms' => 5367 //id为64的分类。也可是多个分类array(12,64)
                ),
            )
        );
    $my_query = new WP_Query($args);
    if( $my_query->have_posts() ) {
        while ($my_query->have_posts()) : $my_query->the_post();?>
        <h3><?php the_title(); ?></h3>
        <p><?php the_content(); ?></p>
        <?php endwhile; wp_reset_query(); //重置query查询
       } ?>
<!--这里放你独立页面的内容-->
<?php tt_get_footer(); ?>