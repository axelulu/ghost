<?php
/**
 * Template Name: 积分榜
 *
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/12/10 19:00
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php tt_get_header(); ?>
<div id="content" class="wrapper container full-page">
        <section id="mod-insideContent" class="main-wrap content-section clearfix">
            <!-- 页面 -->
            <div id="main" class="main primary post-box" role="main">
                <?php global $post; $vm = CreditsRank::getInstance($instance['num']); ?>
                <?php if($vm->isCache && $vm->cacheTime) { ?>
                    <!-- Page cached <?php echo $vm->cacheTime; ?> -->
                <?php } ?>
                <?php global $postdata; $postdata = $vm->modelData; ?>

    <div id="content" class="wrapper container full-page">
        <div class="zhaicy-credits-container">
            <div class="zhaicy-credits-poi-row">
                <?php foreach ($rank_items as $rank_item) {
            ?>
                    <div class="zhaicy-credits-poi-g_1-3">
					  <a class="zhaicy-credits-item" href="<?php echo $rank_item->link; ?>" target="_blank" title="<?php echo $rank_item->display_name; ?>"> 
						<div class="zhaicy-credits-item__img__container"> 
						  <img class="zhaicy-credits-item__img zhaicy-credits-avatar__img zhaicy-credits-lazyload zhaicy-credits-lazyloaded lazy" data-original="<?php echo $rank_item->avatar; ?>" src="<?php echo LAZY_PENDING_IMAGE; ?>" width="100" height="100" alt="<?php echo $rank_item->display_name; ?>"> 
						</div> 
						<div class="zhaicy-credits-item__name"><?php echo $rank_item->display_name; ?></div> 
						<div class="zhaicy-credits-item__point"><?php echo $rank_item->credits; ?></div> 
					  </a>
                        
                    </div>
                <?php
        } ?>
            </div>
        </div>
    </div></div>
        </section>
    </div>
<?php tt_get_footer(); ?>