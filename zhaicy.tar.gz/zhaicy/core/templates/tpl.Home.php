<?php
/**
 * Copyright (c) 2014-2017, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2017/05/24 22:00
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php if (tt_get_option('tt_enable_tinection_home', false) && (!isset($_GET['mod']) || $_GET['mod'] != 'blog')): ?>
    <?php load_tpl('tpl.CmsHome'); ?>
<?php else: ?>
    <?php load_tpl('tpl.ZhaicyHome'); ?>
<?php endif; ?>