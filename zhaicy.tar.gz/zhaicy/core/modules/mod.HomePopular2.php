<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/09/22 20:48
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<!-- 六边形幻灯片 -->
<?php $vm = PopularVM::getInstance(); ?>
<?php if($vm->isCache && $vm->cacheTime) { ?>
    <!-- Popular posts cached <?php echo $vm->cacheTime; ?> -->
<?php } ?>
<div id="popular" class="hotpost col-md-4a block3">
  
    <div id="zhaicy-popular-container" class="zhaicy-popular-container">
        <!-- <h2 class="widget-title"><?php _e('Popular', 'tt'); ?><?php //_e('Most Popular', 'tt'); ?></h2> -->
        <div class="zhaicy-popular">
          
		  <ul id="hexGrid">
        <!--第一行(lineFirst)-->
      <?php if($data = $vm->modelData) { ?>
            <?php foreach ($data as $seq=>$popular) { ?>
          
                <li class="hex">
			<a class="hexIn" href="<?php echo $popular['permalink']; ?>" target="_blank">
				<img src="<?php echo LAZY_PENDING_IMAGE; ?>" data-original="<?php echo $popular['thumb']; ?>" alt="<?php echo $popular['title']; ?>" width="200" height="300" class="lazy zhaicy-popular-img" style="background-color: rgb(245, 217, 215);">
				<h1><?php echo $popular['title']; ?></h1>
				<p><?php echo $popular['title']; ?></p>
			</a>
		</li>
            
             <?php } ?>
        <?php } ?>
              </div>
          <!--第二行(lineSecond)-->
        
    </div>
        </div>
    </div>
</div>