<?php

/**
 * Copyright 2017, Zhiyanblog.com
 * All right reserved.
 *
 * @author Zhiyan
 * @date 2017/12/2 16:41
 *
 * @license GPL v3 LICENSE
 */

?>
<?php

/**
 * Class CreditsRank.
 */
class CreditsRank extends WP_Widget
{
    public function __construct()
    {
        parent::__construct(false, __('TT-User Credits Rank', 'tt'), array('description' => __('TT-Show user credits rank', 'tt'), 'classname' => 'widget_credits-rank'));
    }

    public function widget($args, $instance)
    {
        $vm = WidgetCreditsRankVM::getInstance($instance['num']);
        if ($vm->isCache && $vm->cacheTime) {
            echo '<!-- Credits rank widget cached '.$vm->cacheTime.' -->';
        }
        $rank_items = $vm->modelData; ?>
        <?php echo $args['before_widget']; ?>
        <?php if ($instance['title']) {
            echo $args['before_title'].$instance['title'].$args['after_title'];
        } ?>
        <div class="zhaicy-credits-container">
            <div class="zhaicy-credits-poi-row">
                <?php foreach ($rank_items as $rank_item) {
            ?>
                    <div class="zhaicy-credits-poi-g_1-3">
					  <a class="zhaicy-credits-item" href="<?php echo $rank_item->link; ?>" target="_blank" title="<?php echo $rank_item->display_name; ?>"> 
						<div class="zhaicy-credits-item__img__container"> 
						  <img class="zhaicy-credits-item__img zhaicy-credits-avatar__img" src="<?php echo $rank_item->avatar; ?>" width="100" height="100" alt="<?php echo $rank_item->display_name; ?>"> 
						</div> 
						<div class="zhaicy-credits-item__name"><?php echo $rank_item->display_name; ?></div> 
						<div class="zhaicy-credits-item__point"><?php echo $rank_item->credits; ?></div> 
					  </a>
                        
                    </div>
                <?php
        } ?>
            </div>
        </div>
        <?php echo $args['after_widget']; ?>
        <?php
    }

    public function update($new_instance, $old_instance)
    {
        // TODO 清除小工具缓存

        return $new_instance;
    }

    public function form($instance)
    {
        $title = esc_attr(isset($instance['title']) ? $instance['title'] : __('CREDITS RANK', 'tt'));
        $num = absint(isset($instance['num']) ? $instance['num'] : 5); ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title：', 'tt'); ?><input class="input-lg" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('num'); ?>"><?php _e('Number：', 'tt'); ?></label><input class="input-lg" id="<?php echo $this->get_field_id('num'); ?>" name="<?php echo $this->get_field_name('num'); ?>" type="text"  value="<?php echo $num; ?>" /></p>
        <?php
    }
}

/* 注册小工具 */
if (!function_exists('tt_register_widget_credits_rank')) {
    function tt_register_widget_credits_rank()
    {
        register_widget('CreditsRank');
    }
}
add_action('widgets_init', 'tt_register_widget_credits_rank');