<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/08/24 23:01
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<!-- Footer -->
<!--<footer class="footer simple-footer">
    <div class="foot-copyright">&copy;&nbsp;<?php echo tt_copyright_year(); ?><?php echo ' ' . get_bloginfo('name') . ' · <b style="color: #ff4425;">♥</b>&nbsp;<a href="https://www.zhaicy.com" title="Tint" rel="link" target="_blank">zhaicy</a> & Design by <a href="' . TT_SITE . '" rel="link" title="zhaicy">zhaicy.</a>'; ?>
    </div>
</footer>-->
<?php if(tt_get_option('tt_foot_code')) { echo tt_get_option('tt_foot_code'); } ?>
<?php wp_footer(); ?>
<!--<?php echo get_num_queries();?> queries in <?php timer_stop(1); ?> seconds.-->
</body>
</html>