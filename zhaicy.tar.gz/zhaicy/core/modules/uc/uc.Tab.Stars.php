<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/11/06 17:53
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php global $tt_author_vars; $tt_paged = $tt_author_vars['tt_paged']; $tt_author_id = $tt_author_vars['tt_author_id']; ?>
<?php $vm = UCStarsVM::getInstance($tt_paged, $tt_author_id); ?>
<?php if($vm->isCache && $vm->cacheTime) { ?>
    <!-- Author star posts cached <?php echo $vm->cacheTime; ?> -->
<?php } ?>
<div class="ajaxposts author-tab-box stars-tab" style="background: rgba(0,0,0,0);">
    <div class="ajaxpost tab-content star-posts">
        <?php if($data = $vm->modelData) { $pagination_args = $data->pagination; $uc_star_posts = $data->uc_star_posts; ?>
            <?php if(count($uc_star_posts) > 0) { ?>
                <?php $logged_user_id = get_current_user_id(); ?>
                <div class="loop-rows posts-loop-rows">
                    <?php foreach ($uc_star_posts as $uc_star_post) { ?>
                  
                  <article id="<?php echo 'post-' . $uc_star_post['ID']; ?>" class="zhaicy-credits-poi-g_1-2 zhaicy-credits-item-1 is-xs is-type-post is-status-publish is-format-standard is-hentry">
            <div class="zhaicy-uc-post">
			<div class="zhaicy-credits-item__container"> 
			  <a href="<?php echo $uc_star_post['permalink']; ?>" target="_blank" class="zhaicy-credits-item__thumbnail__container zhaicy-credits-card__thumbnail__container_xs">
                <img class="lazy zhaicy-credits-lazyload zhaicy-credits-item__thumbnail__img zhaicy-credits-lazyloaded-2" src="<?php echo LAZY_PENDING_IMAGE; ?>" data-original="<?php echo $uc_star_post['thumb']; ?>" alt="<?php echo $uc_star_post['title']; ?>" width="200" height="300"> 
			</a>
              <?php if($logged_user_id && $logged_user_id == $tt_author_id) { ?><span class="zhaicy-credits-item__point-7 unstar-link text-muted"><i class="tico tico-favorite"></i><a style="color: #fff;" href="javascript: void 0" data-post-id="<?php echo $uc_star_post['ID']; ?>"><?php _e('Unstar', 'tt'); ?></a></span><?php } ?>
              <div class="zhaicy-credits-item__point-4"><a class="url" style="color: #fff;" href="<?php echo $uc_star_post['author_url']; ?>">作者：<?php echo $uc_star_post['author']; ?></a></div>
			  <div class="zhaicy-credits-item__point-6"><i class="tico tico-comments-o"></i><a style="color: #fff;" href="<?php echo $uc_star_post['permalink'] . '#respond'; ?>">评论数：<?php echo $uc_star_post['comment_count']; ?></a></div>
			  <div class="zhaicy-credits-item__point-5"><time datetime="<?php echo $uc_star_post['datetime']; ?>" title="<?php echo $uc_star_post['datetime']; ?>"><?php echo $uc_star_post['time']; ?></time></div>
			</div>
            <h3 class="zhaicy-credits-item__title" title="<?php echo $uc_star_post['title']; ?>">
				<a href="<?php echo $uc_star_post['permalink']; ?>" target="_blank" class="zhaicy-credits-item__title__link"><?php echo $uc_star_post['title']; ?></a>
			  </h3>
              </div>
		  </article>
                  
                    <?php } ?>
                </div>
                
        <?php } ?>
    </div>
  <?php if($pagination_args['max_num_pages'] > 1) { ?>
                    <?php tt_pagination($pagination_args['base'], $pagination_args['current_page'], $pagination_args['max_num_pages']); ?>
                <?php } ?>
            <?php }else{ ?>
                <div class="empty-content">
                    <span class="tico tico-dropbox"></span>
                    <p><?php _e('Nothing found here', 'tt'); ?></p>
                    <a class="btn btn-info" href="/"><?php _e('Back to home', 'tt'); ?></a>
                </div>
            <?php } ?>
</div>
<!--ajax加载-->
  <script type="text/javascript" src="<?php echo THEME_ASSET.'/js/jquery-ias.min.js';?>"></script>
 <script type="text/javascript">var ias=$.ias({container:".ajaxposts",item:".ajaxpost",pagination:".pagination-new",next:".page-numbers",});ias.extension(new IASTriggerExtension({html:'<div style="clear:both;text-align: center;cursor: pointer;margin-top: 30px;"><button class="hz-btn">加载更多</button></div>',offset:2,}));ias.extension(new IASSpinnerExtension());ias.extension(new IASNoneLeftExtension({html:'<div style="text-align: center;cursor: pointer;clear:both;margin-top: 30px;">已经加载到天涯海角了！</div>',}));ias.on('rendered',function(items){$("img").lazyload({effect:"fadeIn",failure_limit:10})})</script>  
