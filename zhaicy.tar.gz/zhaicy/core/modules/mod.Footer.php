<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2016/08/24 23:01
 *
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @see https://webapproach.net/tint.html
 */
?>
<footer class="footer">
    <!--div class="footer-before"><img src="<?php echo THEME_ASSET.'/img/colorful-line.png'; ?>" ></div-->
    <div class="footer-wrap">
        <!-- 页脚小工具区 -->
        <div class="footer-widgets">

        </div>
        <!-- 页脚菜单/版权信息 IDC No. -->
        <div class="footer-nav">
		  <div class="zhaicy-footer-width">
		  <div class="zhaicy-footer">
		  <aside>
			<div class="widget widget_text">
			  <div class="heading">
				<i class="fas fa-link"></i><span class="widget-title">链接导航</span>
			  </div>
			  <div class="textwidget">
				<ul class="zhaicy-links-daohang">
          <?php echo tt_get_option('zhaicy_footer_links'); ?>
                  
				</ul>
			  </div>
			</div>
		  </aside>
		  </div>
		 <div class="zhaicy-footer">
		  <aside>
			<div class="widget widget_text">
			  <div class="heading">
				<i class="fas fa-bullhorn"></i><span class="widget-title">声明</span>
			  </div>
			  <div class="textwidget">
				<?php echo tt_get_option('zhaicy_footer_statement'); ?>
			  </div>
			</div>
		  </aside>
		  </div>
		  <div class="zhaicy-footer">
		  <aside>
			<div class="widget widget_text">
			  <div class="heading">
				<i class="fas fa-user-circle"></i><span class="widget-title">关于我们</span>
			  </div>
			  <div class="textwidget">
				<?php echo tt_get_option('zhaicy_footer_about'); ?>
			  </div>
			</div>
		  </aside>
		  </div>
		  <div class="zhaicy-footer">
		  <aside>
			<div class="widget widget_text">
			  <div class="heading">
				<i class="fas fa-envelope"></i><span class="widget-title">联系我们</span>
			  </div>
			  <div class="textwidget">
				<?php echo tt_get_option('zhaicy_footer_contect'); ?>
			  </div>
			</div>
		  </aside>
		  </div>
			</div>
        </div>
    </div>
</footer>
<?php load_mod('mod.FixedControls'); ?>
<?php load_mod('mod.ModalSearch'); ?>
<?php if (is_author() && current_user_can('edit_users')) {
        load_mod('mod.ModalBanBox');
    } ?>
<?php if (is_home() || is_single() || is_author()) {
        load_mod('mod.ModalPmBox');
        do_action('tt_ref'); // 推广检查的钩子
    } ?>
<?php if (!is_user_logged_in()) {
        load_mod('mod.ModalLoginForm');
    } ?>
<!-- 页脚自定义代码 -->

<?php if (tt_get_option('tt_foot_code')) {
        echo tt_get_option('tt_foot_code');
    } ?>
<?php wp_footer(); ?>
<!--<?php echo get_num_queries(); ?> queries in <?php timer_stop(1); ?> seconds.-->
<!--底部蒙版区-->
<div id="mengban2" class="zhaicy-pc-meng"></div>
<div id="mengban3" class="zhaicy-pc-meng3"></div>
<div id="mengban4" class="zhaicy-pc-meng4"></div>
<div id="mengban" class="zhaicy-mobile-meng"><div class="poi-dialog__z-index"><div><div component="div" class="poi-dialog__overlay poi-animated_fadeIn-enter-done"></div></div></div></div>
</body>
</html>