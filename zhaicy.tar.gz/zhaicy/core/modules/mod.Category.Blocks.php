<?php
/**
 * Copyright (c) 2014-2017, WebApproach.net
 * All right reserved.
 *
 * @since 2.1.0
 * @package Tint
 * @author Zhiyan
 * @date 2017/05/30 23:39
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php $paged = get_query_var('paged') ? : 1; ?>
        <!-- 分类模块一-->
<div id="content" class="wrapper">
  
<div style="background-image: url(<?php echo tt_get_option('zhaicy_bg_1'); ?>);position: fixed; background-size: cover; top: 0; opacity: .3; left: 0; -webkit-filter: blur(<?php echo tt_get_option('zhaicy_blur_1'); ?>); filter: blur(<?php echo tt_get_option('zhaicy_blur_1'); ?>); right: 0; height: 100vh; z-index: -1;" class="inn-author-page__bg"></div>

    <?php $vm = CategoryPostsVM::getInstance($paged); ?>
    <?php if($vm->isCache && $vm->cacheTime) { ?>
        <!-- Category posts cached <?php echo $vm->cacheTime; ?> -->
    <?php } ?>
    <?php if($data = $vm->modelData) { $pagination_args = $data->pagination; $category = $data->category; $category_posts = $data->category_posts; ?>
        <!-- 分类名及介绍信息 -->
  
  <div style="margin: 0px auto;margin-top: 26px;" class="header white crumb-container"> 
   <nav class="poi-crumb"> 
    <a href="https://zhaicy.com" class="poi-crumb__item poi-crumb__link poi-crumb__item_home" title="返回到首页" aria-label="返回到首页"> <i class="fa-home fas poi-icon poi-crumb__item__icon poi-crumb__item__home__icon" aria-hidden="true"></i> </a>
    <span class="poi-crumb__split"><i class="fa-angle-right fas poi-icon" aria-hidden="true"></i> </span>
    <a class="poi-crumb__item poi-crumb__link" href="<?php $catID = get_query_var('cat');$thisCat = get_category($catID);$parentCat = get_category($thisCat->parent);echo get_category_link($parentCat->term_id);?>"><?php echo zhaicy_father_name();?></a>
    <span class="poi-crumb__split"><i class="fa-angle-right fas poi-icon" aria-hidden="true"></i> </span>
    <a class="poi-crumb__item poi-crumb__link" href="<?php get_category_link( get_current_category_id() );?>"><?php echo $category['cat_name']; ?></a>
    <span class="poi-crumb__split"><i class="fa-angle-right fas poi-icon" aria-hidden="true"></i> </span>
    <span class="poi-crumb__item">目录浏览</span> 
   </nav> 
  </div>
   <!-- 分类页排序-->
  
  <?php global $wp_query;
$cat_ID = get_query_var('cat');
  $cat=get_term_by('id', $cat_ID, 'category');
$cat_links=get_category_link($cat->term_id);
?>
  <div style="margin: 0px auto;margin-top: 0px;" class="header white crumb-container"> 
   <nav class="poi-crumb"> 
     <a class="zhaicy-paixu" href="<?php echo $cat_links; ?>">按最新修改</a>
     <a class="zhaicy-paixu" href="?orderby=comment_count">按评论多少</a>
     <a class="zhaicy-paixu" href="?orderby=date?">按发布日期</a>
     <a class="zhaicy-paixu" href="?orderby=ID">按文章ID</a>
     <a class="zhaicy-paixu" href="?orderby=rand">随机排序</a>
   </nav> 
  </div>
        <!-- 分类文章 -->
        <section class="container archive-posts category-posts">
            <div class="row loop-grid posts-loop-grid mt20 mb20 clearfix">
                <?php foreach ($category_posts as $category_post) { ?>
                    <div class="col-md-3">
                        <article id="<?php echo 'post-' . $category_post['ID']; ?>" class="post type-post status-publish <?php echo 'format-' . $category_post['format']; ?>">
                            <div class="entry-thumb hover-scale">
                                <a href="<?php echo $category_post['permalink']; ?>"><img width="500" height="340" src="<?php echo LAZY_PENDING_IMAGE; ?>" data-original="<?php echo $category_post['thumb']; ?>" class="thumb-medium lazy" alt="<?php echo $category_post['title']; ?>"></a>
                                <!--                        <span class="shadow"></span>-->
                                <!--a class="entry-category" href="">XXX</a-->
                                <?php echo $category_post['category']; ?>
                            </div>
                            <div class="entry-detail">
                                <header class="entry-header">
                                    <h2 class="entry-title h4"><a href="<?php echo $category_post['permalink']; ?>" rel="bookmark"><?php echo $category_post['title']; ?></a></h2>
                                    <div class="entry-meta entry-meta-1">
                                        <span class="author vcard"><a class="url" href="<?php echo $category_post['author_url']; ?>"><?php echo $category_post['author']; ?></a></span>
                                        <span class="entry-date text-muted"><time class="entry-date" datetime="<?php echo $category_post['datetime']; ?>" title="<?php echo $category_post['datetime']; ?>"><?php echo $category_post['timediff']; ?></time></span>
                                        <span class="comments-link text-muted pull-right"><i class="tico tico-comments-o"></i><a href="<?php echo $category_post['permalink'] . '#respond'; ?>"><?php echo $category_post['comment_count']; ?></a></span>
                                        <span class="likes-link text-muted pull-right mr10"><i class="tico tico-favorite"></i><a href="javascript:void(0)"><?php echo $category_post['star_count']; ?></a></span>
                                    </div>
                                </header>
                                <div class="entry-excerpt">
                                    <div class="post-excerpt"><?php echo $category_post['excerpt']; ?></div>
                                </div>
                            </div>
                        </article>
                    </div>
                <?php } ?>
            </div>

            <?php if($pagination_args['max_num_pages'] > 1) { ?>
                <?php tt_pagination($pagination_args['base'], $pagination_args['current_page'], $pagination_args['max_num_pages']); ?>
            <?php } ?>
            <!--        --><?php //if($pagination_args['max_num_pages'] > $paged) { ?>
            <!--            <div class="row load-next clearfix mt30 mb30 text-center">-->
            <!--                <a class="btn btn-danger btn-wide btn-next" title="--><?php //_e('LOAD NEXT', 'tt'); ?><!--" data-component="loadNext" data-next-page="--><?php //echo $paged + 1; ?><!--" data-next-page-url="--><?php //echo $pagination_args['next']; ?><!--"><i class="tico tico-angle-down"></i></a>-->
            <!--            </div>-->
            <!--        --><?php //} ?>
        </section>
    <?php } ?>
</div>