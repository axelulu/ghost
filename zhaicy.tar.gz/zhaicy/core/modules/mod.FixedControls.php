<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/10/22 23:48
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<!-- 返回顶部等固定按钮 -->
<section class="side_btn">
  <!--提交问题-->
  <a class="btn" href="https://www.zhaicy.com/gbook" rel="external nofollow" data-tooltip="提交问题">
    <i class="tico tico-question-circle"></i>
  </a>
  <a href="http://wpa.qq.com/msgrd?v=3&amp;uin=2419857357&amp;site=qq&amp;menu=yes" class="btn" rel="external nofollow" target="_blank" data-tooltip="在线咨询">
    <i class="tico tico-qq"></i>
  </a>
  <!--去评论-->
  <?php
if(is_single()){
    echo  '<a href="#respond" class="btn" data-tooltip="返回评论"><i class="tico tico-bubble"></i></a>';
}else
{
    echo "";
}
?>
 <div id="zhaicy-search-bar3"> <a class="btn" data-tooltip="搜索">
    <i class="tico tico-search"></i>
  </a></div>
  <!--回顶部-->
  <a class="btn top scroll-to scroll-top" title="返回顶部" rel="external nofollow" data-tooltip="返回顶部">
    <i class="tico tico-arrow-up2"></i>
  </a>
</section>