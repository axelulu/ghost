<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/08/24 23:00
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php load_mod('mod.Head'); ?>
<body <?php body_class('is-loadingApp'); ?>>
  <!--loding加载动画-->
<!--  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/imagehover.css/1.0/css/imagehover.min.css">
  <script src="https://cdn.bootcss.com/clipboard.js/1.7.1/clipboard.min.js"></script>
  -->
  <div class="zhaicy-topbar__container header.white"> 
	<div class="header-yonghu poi-container"> 
	  <nav class="zhaicy-topbar">
		<ul id="zhaicy-topbar" class="menu">
           <?php  
	if (is_user_logged_in()){            
      echo "<li class='zhaicy-topbar__item is-icon-text'><a title='我的圈子' target='_self' href='",home_url(),"/u/",get_current_user_id(),"'", " class='zhaicy-topbar__item__link is-icon-text'><i style='
    font-size: 1.4em;
' class='fas fa-circle fa-2x poi-icon zhaicy-topbar__item__link__icon' aria-hidden='true'></i> <span class='zhaicy-topbar__item__link__text'> 我的圈子</span></a></li>
<li class='zhaicy-topbar__item is-icon-text'><a title='我的消息' target='_self' href='",home_url(),"/me/messages/inbox'", "class='zhaicy-topbar__item__link is-icon-text' ><i style='
    font-size: 1.4em;
' class='fas fa-envelope fa-2x poi-icon zhaicy-topbar__item__link__icon' aria-hidden='true'></i> <span class='zhaicy-topbar__item__link__text'> 我的消息</span></a></li>
<li class='zhaicy-topbar__item is-icon-text'><a title='我的会员' target='_self' href='",home_url(),"/me/membership'", "class='zhaicy-topbar__item__link is-icon-text'><i style='
    font-size: 1.4em;
' class='fas fa-user-circle fa-2x poi-icon zhaicy-topbar__item__link__icon' aria-hidden='true'></i> <span class='zhaicy-topbar__item__link__text'> 我的会员</span></a></li>
<li class='zhaicy-topbar__item is-icon-text'><a title='资源投稿' target='_self' href='",home_url(),"/me/newpost'", "class='zhaicy-topbar__item__link is-icon-text'><i style='
    font-size: 1.4em;
' class='fas fa-paint-brush fa-2x poi-icon zhaicy-topbar__item__link__icon' aria-hidden='true'></i> <span class='zhaicy-topbar__item__link__text'> 资源投稿</span></a></li>";
	}else { 
		echo "<li class='zhaicy-topbar__item is-icon-text'><a title='我的圈子' target='_self' class='login-actions zhaicy-topbar__item__link is-icon-text'><i style='
    font-size: 1.4em;
' class='fas fa-circle fa-2x poi-icon zhaicy-topbar__item__link__icon' aria-hidden='true'></i> <span class='zhaicy-topbar__item__link__text'> 我的圈子</span></a></li>
<li class='zhaicy-topbar__item is-icon-text'><a title='我的消息' target='_self' class='login-actions zhaicy-topbar__item__link is-icon-text' ><i style='
    font-size: 1.4em;
' class='fas fa-envelope fa-2x poi-icon zhaicy-topbar__item__link__icon' aria-hidden='true'></i> <span class='zhaicy-topbar__item__link__text'> 我的消息 </span></a></li>
<li class='zhaicy-topbar__item is-icon-text'><a title='我的会员' target='_self' class='login-actions zhaicy-topbar__item__link is-icon-text'><i style='
    font-size: 1.4em;
' class='fas fa-user-circle fa-2x poi-icon zhaicy-topbar__item__link__icon' aria-hidden='true'></i> <span class='zhaicy-topbar__item__link__text'> 我的会员</span></a></li>
<li class='zhaicy-topbar__item is-icon-text'><a title='资源投稿' target='_self' class='login-actions zhaicy-topbar__item__link is-icon-text'><i style='
    font-size: 1.4em;
' class='fas fa-paint-brush fa-2x poi-icon zhaicy-topbar__item__link__icon' aria-hidden='true'></i> <span class='zhaicy-topbar__item__link__text'> 资源投稿</span></a></li>";           
	};  
?>
		</ul>
	  </nav> 
	</div>
  </div>
  <div style="background-image:url(<?php echo tt_get_option('zhaicy_bg_header'); ?>);" class="header-tu">
  <!-- Logo -->
		  <div class="zhaicy-header-menu">
		  <a class="logo nav-col" href="<?php echo home_url(); ?>" title="<?php echo get_bloginfo('name'); ?>">
                <img class="zhaicy-me-logo" src="<?php echo tt_get_option('tt_logo'); ?>" alt="<?php echo get_bloginfo('name'); ?>">
            </a>
		  </div>
    </div>
  
    <div class="loading-line"></div>
   
      <!-- 顶部公告 -->
    <?php load_mod('mod.HomeBulletins'); ?>
  <div class="tint-nav__placeholder"></div>
  <!--手机端个人中心-->
   <div id="zhaicy-nav-mobile__container2" style="right:0px" class="zhaicy-nav-mobile__container slideInLeft"> 
   <a href="https://zhaicy.com" class="zhaicy-nav-mobile__title">宅次元</a> 
   <nav>
    <ul id="zhaicy-nav-shoujiduan" class="menu">
     <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children"><a><i class="zhaicy-shouyecaidan fas fa-address-card"> </i>个人设置<span class="num"></span></a> 
      <ul class="sub-menu"> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_url_for('my_settings', $tt_me_vars['tt_user_id']); ?>"><i class="fas fa-cog"></i>我的设置</a></li> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_url_for('my_drafts', $tt_me_vars['tt_user_id']); ?>"><i class="fas fa-copy"></i>我的草稿</a></li> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_url_for('new_post'); ?>"><i class="fas fa-paint-brush"></i>新建文章</a></li> 
      </ul> </li> 
     <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children"><a><i class="zhaicy-shouyecaidan fas fa-file-alt"> </i>消息管理<span class="num"></span></a> 
      <ul class="sub-menu"> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_url_for('all_notify', $tt_me_vars['tt_user_id']); ?>"><i class="fas fa-bell"></i>我的通知</a></li> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_url_for('in_msg', $tt_me_vars['tt_user_id']); ?>"><i class="fas fa-envelope"></i>我的消息</a></li> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_url_for('my_all_orders', $tt_me_vars['tt_user_id']); ?>"><i class="fas fa-shopping-cart"></i>我的订单</a></li> 
      </ul> </li> 
      <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children"><a><i class="zhaicy-shouyecaidan fas fa-user-circle"> </i>个人中心<span class="num"></span></a> 
      <ul class="sub-menu"> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo home_url(),'/u/',get_current_user_id(),'/stars'; ?>"><i class="fas fa-heart"></i>我的收藏</a></li> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo home_url(),'/u/',get_current_user_id(),'/latest'; ?>"><i class="fas fa-file-alt"></i>我的文章</a></li> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo home_url(),'/u/',get_current_user_id(),'/followers'; ?>"><i class="fa-users fas"></i>我的粉丝</a></li> 
      </ul> </li> 
      <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children"><a><i class="zhaicy-shouyecaidan fas fa-file-alt"> </i>我的会员<span class="num"></span></a> 
      <ul class="sub-menu"> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_url_for('my_membership', $tt_me_vars['tt_user_id']); ?>"><i class="fas fa-play-circle"></i>我的会员</a></li> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_url_for('my_cash', $tt_me_vars['tt_user_id']); ?>"><i class="fas fa-credit-card"></i>我的余额</a></li> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_url_for('my_credits', $tt_me_vars['tt_user_id']); ?>"><i class="fas fa-gem"></i>我的积分</a></li> 
      </ul> </li> 
      <li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children"><a><i class="zhaicy-shouyecaidan fas fa-file-alt"> </i>管理设置<span class="num"></span></a> 
      <ul class="sub-menu"> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_add_redirect(tt_url_for('signout'), tt_get_current_url()); ?>"><i class="fas fa-sign-out-alt"></i>注销账号</a></li> 
        <?php if(current_user_can('edit_users')) { ?>
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo get_dashboard_url(); ?>"><i class="fas tico-meter"></i>访问后台</a></li> 
       <li class="menu-item menu-item-type-taxonomy menu-item-object-category"><a href="<?php echo tt_url_for('manage_home'); ?>"><i class="fas tico-list-small-thumbnails"></i>站务管理</a></li> 
        <?php } ?>
      </ul> </li> 
    </ul>
   </nav> 
  </div>
<!--手机端个人中心-->
  <!--手机端菜单栏-->
  <div id="zhaicy-nav-mobile__container" class="zhaicy-nav-mobile__container slideInLeft"> 
    <a href="https://zhaicy.com" class="zhaicy-nav-mobile__title">宅次元</a>
    <?php wp_nav_menu( array( 'theme_location' => 'header-menu', 'container' => 'nav', 'menu_id'=> 'zhaicy-nav-shoujiduan', 'menu_class' => 'menu', 'depth' => '2', 'fallback_cb' => false  ) ); ?>
    </div>
   <header id="scroll-header" class="header common-header white">
        <input type="checkbox" id="menustate" class="menustate hide">
	    <div class="zhaicy-header-logo" style="background-color: rgba(225,225,225,0);"> 
		  
		  <div id="inn-banner__mask__bg" class="header-yonghu-bg inn-banner__mask__bg">
			
		  </div>
	    </div>
        <nav style="padding-left: 0px;padding-right: 0px;" id="header-nav" class="navigation clearfix" role="navigation">
            <!-- Menu Icon -->
            <li class="menuicon visible-xs-block">
                <label class="menuicon-label" aria-hidden="true">
					<a style="font-size: 1.5rem;line-height: 50px;" class="zhaicy-nav-mobile-aaa fa fa-bars"></a>
                </label>
<!--                <a href="#menustate" class="menuanchor menuanchor-open" id="menuanchor-open">-->
<!--                    <span class="menuanchor-label">Open Menu</span>-->
<!--                </a>-->
<!--                <a href="#" class="menuanchor menuanchor-close" id="menuanchor-close">-->
<!--                    <span class="menuanchor-label">Close Menu</span>-->
<!--                </a>-->
            </li>
            
            <!-- Top Menu -->
          <?php wp_nav_menu( array( 'theme_location' => 'header-menu', 'container' => 'nav', 'menu_id'=> 'header-menu', 'menu_class' => 'header-menu nav-col', 'depth' => '2', 'fallback_cb' => false  ) ); ?>
       <!-- End Top Menu -->
            <!-- Header Right Tools -->
<div class="zhaicy-nav-tool__container">
            <!--    <li class="zhaicy-top-search"><a href="javascript:void(0)" data-toggle="modal" data-target="#globalSearch" data-backdrop="1"><span class="zhaicy-header-search fa fa-search fa-2x"></span></a></li>   -->
                <?php $user = wp_get_current_user(); ?>
                <?php if($user && $user->ID) { ?>
                    <?php $unread = tt_count_pm_cached($user->ID, 0, MsgReadStatus::UNREAD); ?>
              <div id="inn-sign__login-btn__container" class="inn-sign__login-btn__container"></div>
              <div id="zhaicy-nav__pm__container" class="zhaicy-nav__pm__container"></div>
              <div id="zhaicy-nav__notification" class="zhaicy-nav__notification"></div>
                    <div class="zhaicy_shoujiduan_anniu"></div>
                    <div class="zhaicy-user-menu__nav__avatar-btn">
                      <a class="zhaicy-user-menu__nav__avatar-btn__link">
                        <img class="zhaicy-user-menu__nav__avatar-btn__img inn-avatar__img" src="<?php echo tt_get_avatar($user->ID, 'small'); ?>" width="50" height="50" alt="@宅次元菌">
                      </a>
                      
<div class="zhaicy-user-menu__nav">
<div class="zhaicy-user-menu__nav__item">
  <div class="zhaicy-user-menu__nav__item__title">
	<div class="zhaicy-user-menu__nav__item__title__icon">
	  <i class="poi-icon fas fa-address-card" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__title__text">个人设置</div></div>
  <a href="<?php echo tt_url_for('my_settings', $tt_me_vars['tt_user_id']); ?>" title="我的设置" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-cog" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的设置</div></a>
  <a href="<?php echo tt_url_for('my_drafts', $tt_me_vars['tt_user_id']); ?>" title="我的草稿" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-copy" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的草稿</div></a>
  <a href="<?php echo tt_url_for('new_post'); ?>" title="<?php _e('New Post', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-paint-brush" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text"><?php _e('New Post', 'tt'); ?></div></a>
</div>
<div class="zhaicy-user-menu__nav__item">
  <div class="zhaicy-user-menu__nav__item__title">
	<div class="zhaicy-user-menu__nav__item__title__icon">
	  <i class="poi-icon fa-bell fas" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__title__text">消息管理</div></div>
  <a href="<?php echo tt_url_for('all_notify', $tt_me_vars['tt_user_id']); ?>" title="我的<?php _e('NOTIFICATIONS', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-bell" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的<?php _e('NOTIFICATIONS', 'tt'); ?></div></a>
  <a href="<?php echo tt_url_for('in_msg', $tt_me_vars['tt_user_id']); ?>" title="我的<?php _e('MESSAGES', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-envelope" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的<?php _e('MESSAGES', 'tt'); ?><?php if($unread) { ?><i class="badge"></i><?php } ?></div></a>
  <a href="<?php echo tt_url_for('my_all_orders', $tt_me_vars['tt_user_id']); ?>" title="我的<?php _e('ORDERS', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-shopping-cart" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的<?php _e('ORDERS', 'tt'); ?></div></a>
</div>
<div class="zhaicy-user-menu__nav__item">
  <div class="zhaicy-user-menu__nav__item__title">
	<div class="zhaicy-user-menu__nav__item__title__icon">
	  <i class="poi-icon fas fa-user-circle" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__title__text">个人中心</div></div>
  <a href="<?php echo home_url(),'/u/',get_current_user_id(),'/stars'; ?>" title="我的<?php _e('MY STARS', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-heart" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的<?php _e('MY STARS', 'tt'); ?></div></a>
  <a href="<?php echo home_url(),'/u/',get_current_user_id(),'/latest'; ?>" title="我的<?php _e('MY POSTS', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-file-alt" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的<?php _e('MY POSTS', 'tt'); ?></div></a>
  <a href="<?php echo home_url(),'/u/',get_current_user_id(),'/followers'; ?>" title="我的<?php _e('MY FOLLOWERS', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fa-users fas" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的<?php _e('MY FOLLOWERS', 'tt'); ?></div></a>
</div>
<div class="zhaicy-user-menu__nav__item">
  <div class="zhaicy-user-menu__nav__item__title">
	<div class="zhaicy-user-menu__nav__item__title__icon">
	  <i class="poi-icon fas fa-user-circle" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__title__text">我的会员</div></div>
  <a href="<?php echo tt_url_for('my_membership', $tt_me_vars['tt_user_id']); ?>" title="我的<?php _e('MEMBERSHIP', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-user-circle" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的<?php _e('MEMBERSHIP', 'tt'); ?></div></a>
  <a href="<?php echo tt_url_for('my_cash', $tt_me_vars['tt_user_id']); ?>" title="我的<?php _e('MY CASH', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-credit-card" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的<?php _e('MY CASH', 'tt'); ?></div></a>
  <a href="<?php echo tt_url_for('my_credits', $tt_me_vars['tt_user_id']); ?>" title="我的<?php _e('CREDITS', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-gem" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text">我的<?php _e('CREDITS', 'tt'); ?></div></a>
</div>
<div class="zhaicy-user-menu__nav__item">
  <div class="zhaicy-user-menu__nav__item__title">
	<div class="zhaicy-user-menu__nav__item__title__icon">
	  <i class="poi-icon fas fa-unlock" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__title__text">管理设置</div></div>
  <a href="<?php echo tt_add_redirect(tt_url_for('signout'), tt_get_current_url()); ?>" title="<?php _e('Sign Out', 'tt'); ?>账号" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas fa-sign-out-alt" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text"><?php _e('Sign Out', 'tt'); ?>账号</div></a> 
  
  <?php if(current_user_can('edit_users')) { ?>
  <a href="<?php echo get_dashboard_url(); ?>" title="<?php _e('Go Dashboard', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas tico-meter" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text"><?php _e('Go Dashboard', 'tt'); ?></div></a>
  <a href="<?php echo tt_url_for('manage_home'); ?>" title="<?php _e('Site Management', 'tt'); ?>" class="zhaicy-user-menu__nav__item__link">
	<div class="zhaicy-user-menu__nav__item__link__icon">
	  <i class="poi-icon fas tico-list-small-thumbnails" aria-hidden="true"></i>
	</div>
	<div class="zhaicy-user-menu__nav__item__link__text"><?php _e('Site Management', 'tt'); ?></div></a>
</div>
					  <?php } ?>
  
</div>
               </div>
                <?php }else{ ?>
              <li class="login-actions">
                        <a class="login-link bind-redirect"><span>登陆</span></a>
                    </li>
              <div id="zhaicy-search-bar2" class="zhaicy_header_search_anniu zhaicy-search-bar__toggle-btn__container"><a class="poi-icon fa-search fa fa-2x zhaicy-search-bar__btn" aria-label="搜索" title="搜索"></a></div>
                <?php } ?>
  <?php if(current_user_can('edit_users')) { ?>
              <div id="zhaicy-search-bar2" class="zhaicy_header_search_anniu zhaicy-search-bar__toggle-btn__container"><a class="poi-icon fa-search fa fa-2x zhaicy-search-bar__btn" aria-label="搜索" title="搜索"></a></div>
  <?php } ?>
          </div>
  <?php if (is_user_logged_in()){ ?>
              <div id="zhaicy-search-bar2" class="zhaicy_header_search_anniu zhaicy-search-bar__toggle-btn__container"><a class="poi-icon fa-search fa fa-2x zhaicy-search-bar__btn" aria-label="搜索" title="搜索"></a></div>
    <?php } ?>
        </nav>
    </header>