<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/11/20 20:05
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php global $productdata; $catIDs = $productdata->catIDs; $rand_products = $productdata->rands; ?>
<?php $tool_vm = ShopHeaderSubNavVM::getInstance(); $data = $tool_vm->modelData; $all_categories = $data->categories; $all_tags = $data->tags;?>
<!-- Product category -->
<h3 class="widget-title" style="margin: 0px;">
  <span>
    <i class="fas fa-bullseye" style="margin-right: 5px;font-size: 1.5rem;"></i>
    <span style="font-size: 1.5rem;"><?php _e('Categories', 'tt'); ?></span>
  </span>
</h3>
<aside class="commerce-widget widget_product_categories">
    <ul class="widget-content category-list">
        <?php foreach ($all_categories as $category) { ?>
            <li class="<?php if(in_array($category['ID'], $catIDs)){echo 'tico-angle cat-item active';}else{echo 'tico-angle cat-item';}; ?>">
                <a class="product-cat cat-link" href="<?php echo $category['permalink']; ?>" title=""><?php echo $category['name']; ?></a>
            </li>
        <?php } ?>
    </ul>
</aside>
<!-- 销量 -->
<aside class="product-info__section product-info__table"> 
  <h2 style="font-size: 14px;
    font-weight: 400;
    margin: 0 0 20px 0;
    text-align: center;
    position: relative;"><?php _e('SKU: ', 'tt'); ?><?php echo $productdata->ID; ?></h2> 
  <table>
    <tbody>
      <tr>
        <td><?php _e('Sales: ', 'tt'); ?><?php echo $productdata->sales; ?></td> 
        <td><?php _e('Inventory: ', 'tt'); ?><?php echo $productdata->amount; ?></td>
      </tr>
    </tbody>
  </table>
</aside>
<!-- Product list -->
<h3 class="widget-title" style="margin: 0px;">
  <span>
    <i class="fas fa-shopping-bag" style="margin-right: 5px;font-size: 1.5rem;"></i>
    <span style="font-size: 1.5rem;"><?php _e('Products', 'tt'); ?></span>
  </span>
</h3>
<aside class="commerce-widget widget_products">
    <ul class="widget-content product-list">
        <?php foreach ($rand_products as $rand_product) { ?>
      
      
      <article style="float:left" class="zhaicy-credits-poi-g_1-2 zhaicy-credits-item-1 is-xs is-type-post is-status-publish is-format-standard is-hentry"> 
            <div class="zhaicy-widgets-post">
			<div class="zhaicy-credits-item__container"> 
			  <a href="<?php echo $rand_product['permalink']; ?>" target="_blank" class="zhaicy-credits-item__thumbnail__container zhaicy-credits-card__thumbnail__container_xs">
				<img class="lazy zhaicy-credits-lazyload zhaicy-credits-item__thumbnail__img zhaicy-credits-lazyloaded-2" data-original="<?php echo $rand_product['thumb']; ?>" src="<?php echo LAZY_PENDING_IMAGE; ?>" alt="<?php echo $rand_product['title']; ?>" width="320" height="180"></a>
			  <?php if(!($view_product['price'] > 0)) { ?>
                    <div class="zhaicy-credits-item__point-2"><?php _e('FREE', 'tt'); ?></div>
                <?php }elseif(!isset($view_product['discount'][0]) || $view_product['discount'][0] >= 100){ ?>
                    <div class="zhaicy-credits-item__point-3"><?php echo $rand_product['price_icon']; ?><?php echo $rand_product['price']; ?></div>
                <?php }else{ ?>
                    <del><?php echo $rand_product['price_icon']; ?><span class="zhaicy-credits-item__point-3"><?php echo $rand_product['price']; ?></span></del>
                    <ins><?php echo $rand_product['price_icon']; ?><span class="zhaicy-credits-item__point-2"><?php $discount_price = $rand_product['currency'] == 'cash' ? sprintf('%0.2f', $rand_product['price'] * $rand_product['discount'][0] / 100) : intval($rand_product['price'] * $rand_product['discount'][0] / 100); echo $discount_price; ?></span></ins>
                <?php } ?>
			</div>
			  <h3 class="zhaicy-credits-item__title" title="<?php echo $rand_product['title']; ?>">
				<a href="<?php echo $rand_product['permalink']; ?>" target="_blank" class="zhaicy-credits-item__title__link"><?php echo $rand_product['title']; ?></a>
			  </h3>
              </div>
		  </article>
        <?php } ?>
    </ul>
</aside>
<!-- Product tags -->
<h3 class="widget-title" style="margin: 0px;">
  <span>
    <i class="fas fa-tags" style="margin-right: 5px;font-size: 1.5rem;"></i>
    <span style="font-size: 1.5rem;"><?php _e('Product Tags', 'tt'); ?></span>
  </span>
</h3>
<aside class="commerce-widget widget_product_tag_cloud">
    <div class="widget-content tagcloud">
        <?php foreach ($all_tags as $tag) { ?>
            <a class="product-tag tag-link" href="<?php echo $tag['permalink']; ?>" title=""><?php echo $tag['name']; ?></a>
        <?php } ?>
    </div>
</aside>