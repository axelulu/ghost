
<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/09/28 23:09
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<!-- 搜索模态框 -->
<div aria-hidden="true">
  <div class="fadeScale poi-dialog__z-index">
    <div>
      <div component="div" class="zhaicy-poi-dialog__overlay poi-animated_fadeIn-enter-done"></div>
    </div>
    <div class="fadeScale zhaicy-search-bar">
      <div>
        <form method="get" action="<?php echo home_url(); ?>" role="search" class="zhaicy-search-bar__fm poi-animated_fadeInDown-enter-done">
          <label class="zhaicy-search-bar__fm__label">搜索</label>
          <input name="s" type="search" class="zhaicy-search-bar__fm__input" type="search" placeholder="试试：gal" aria-label="搜索" value="">
          <input type="submit" hidden=""></form>
        <div class="zhaicy-search-bar__presets poi-animated_fadeInUp-enter-done">
          
     <?php 
        $zhaicy_search=explode(",",tt_get_option('zhaicy_search_slides'));
        foreach ($zhaicy_search as $value) {
   echo "<a href='",home_url(),"/?s=$value' class='zhaicy-search-bar__presets__item'>$value</a>";
}
     ?>
          </div>
        
      </div>
      <!--搜索栏推荐文章-->
      <?php 
     //   $zhaicy_search_post=explode(",",tt_get_option('zhaicy_search_post'));
    //    foreach ($zhaicy_search_post as $value2) {
 //  echo "$medium_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->$value2), 'medium');
  //  echo $medium_image_url[0];
 //   <a href='zhaicy/$value2' class='zhaicy-search-bar__presets__item'>$value2</a>";
//}
     ?>
    </div>
  </div>
</div>