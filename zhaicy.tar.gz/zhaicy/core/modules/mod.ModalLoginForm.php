<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2016/10/13 23:29
 *
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @see https://webapproach.net/tint.html
 */
?>
<!-- 登录弹窗 -->
<div style="position: relative;" id="zhaicy-modalSignBox">
  <div class="form-signin modal fadeScale" id="zhaicy-login-from">
    <!--<h2><?php _e('Sign In', 'tt'); ?></h2>-->
  <h2>赶快注册登录吧！</h2>
  <!-- Open Login -->
    <?php
    $open_weibo = tt_get_option('tt_enable_weibo_login');
    $open_qq = tt_get_option('tt_enable_qq_login');
    $open_weixin = tt_get_option('tt_enable_weixin_login');
    $has_open_login = $open_weibo || $open_qq || $open_weixin;
    ?>
    <?php if ($has_open_login) {
        ?>
        <div class="open-login clearfix">
            <!--<p class="mb20 hidden-xs"><?php _e('SignIn with Social Account', 'tt'); ?></p>-->
            <div class="social-items">
            <?php if ($open_weibo) {
            ?>
                <!--<a href="<?php echo tt_add_redirect(tt_url_for('oauth_weibo'), tt_get_current_url()); ?>" class="btn btn-sn-weibo">-->
                  <a href="<?php echo tt_add_redirect(tt_url_for('oauth_weibo'), tt_get_current_url()); ?>" class="btn btn-sn-qq" title="微博登陆"><i class="fa-weibo fab fa-fw" aria-hidden="true"></i><span class=""> 微博登陆</span></a>
                    <!--<span class="tico tico-weibo"></span></a>-->
            <?php
        } ?>
            <?php if ($open_qq) {
            ?>
                <!--<a href="<?php echo tt_add_redirect(tt_url_for('oauth_qq'), tt_get_current_url()); ?>" class="btn btn-sn-qq">-->
                  <a href="<?php echo tt_add_redirect(tt_url_for('oauth_qq'), tt_get_current_url()); ?>" class="btn btn-sn-qq" title="QQ 登录"><i class="fa-qq fab fa-fw" aria-hidden="true"></i><span class=""> QQ 登录</span></a>
                    <!--<span class="tico tico-qq"></span></a>-->
            <?php
        } ?>
            <?php if ($open_weixin) {
            ?>
                <a href="<?php echo tt_add_redirect(tt_url_for('oauth_weixin'), tt_get_current_url()); ?>" class="btn btn-sn-weixin">
                    <span class="tico tico-weixin"></span>
                </a>
            <?php
        } ?>
            </div>
        </div>
    <?php
    } ?>
    <!-- End Open Login -->
  
    <form style="
    bottom: 0px;
    position: absolute;
" class="local-signin">
        <!-- fake fields are a workaround for chrome autofill getting the wrong fields -->
        <input style="display:none" type="text" name="fakeusernameremembered"/>
        <input style="display:none" type="password" name="fakepasswordremembered"/>
        <div class="form-group input-container clearfix">
          <span class="zhaicy-loginform"><i class="fa fa-at fas fa-fw" aria-hidden="true"></i></span>
            <span class=""><input autocomplete="off" name="user_login" type="text" class="form-control input text-input" id="user_login-input" title="" required="required" placeholder="<?php _e('Email/Username', 'tt'); ?>">
            </span>
        </div>
        <div class="form-group input-container clearfix">
          <span class="zhaicy-loginform"><i class="fa fa-unlock-alt fas fa-fw" aria-hidden="true"></i></span>
            <span class=""><input autocomplete="new-password" name="password" type="password" class="form-control input password-input" id="password-input" title="" required="required" placeholder="<?php _e('Password', 'tt'); ?>">
            </span>
        </div>
      <div class="text-center login-help" style="padding: 0px 0px 15px 0px;">
            <a href="<?php echo tt_add_redirect(tt_url_for('signup')); ?>" id="go-register" class="mr20 register-link" rel="link"><?php _e('Register Now', 'tt'); ?></a>
            <span class="dot-separator" role="separator"></span>
            <a href="<?php echo tt_url_for('findpass'); ?>" id="go-findpass" class="ml20 findpass-link" rel="link"><?php _e('Forgot your password?', 'tt'); ?></a>
        </div>
        <input name="nonce" type="hidden" value="<?php echo wp_create_nonce('page-signin'); ?>">
        <button class="btn btn-info btn-block submit" type="submit">
          <i class="fa fa-user fas" aria-hidden="true"></i>
          <span><?php _e('Submit', 'tt'); ?></span>
      </button>
    </form>
    </div>
</div>