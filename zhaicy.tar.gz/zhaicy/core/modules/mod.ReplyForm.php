<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/10/09 13:34
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php
global $postdata;
?>
<div class="submit-box comment-form clearfix" id="comment-form">
    <?php //comment_id_fields(); ?>
    <input type="hidden" name="comment_post_ID" value="<?php echo $postdata->ID; ?>" id="comment_post_ID">
    <input type="hidden" name="comment_parent" id="comment_parent" value="0">
    <input type="hidden" name="tt_comment_nonce" id="comment_nonce" value="<?php echo wp_create_nonce('tt_comment_nonce'); ?>">
    <?php do_action('comment_form', $postdata->ID); ?>
    
    <?php if(is_user_logged_in()) { ?>
 <div class="zhaicy-comment-active zhaicy-super-comment__faker">
      <img class="zhaicy-super-comment__faker__avatar zhaicy-avatar__img" src="https://ws2.sinaimg.cn/large/686ee05djw1f5dm9khva8j2074074dfn.jpg" alt="avatar" width="18" height="18">
      <span class="zhaicy-super-comment__faker__text">一起参与评论</span>
    </div>
  <?php }else{ ?>
  <div class="login-actions zhaicy-super-comment__faker">
      <img class="zhaicy-super-comment__faker__avatar zhaicy-avatar__img" src="https://ws2.sinaimg.cn/large/686ee05djw1f5dm9khva8j2074074dfn.jpg" alt="avatar" width="18" height="18">
      <span class="zhaicy-super-comment__faker__text"><?php _e('Signin and Leave some words...', 'tt'); ?></span>
    </div>
        <?php } ?>
  <div style="display:none" class="fadeScale" id="zhaicy-comment-reply">
   
     <div style="padding: 20px;" class="text">
        <textarea class="form-control" style="width: 100%;" name="comment" placeholder="请勿发送垃圾评论，如多次发现，将会带来封号的危险！" id="comment-text" required></textarea>
        
    </div>
    
    <div class="zhaicy-reply-bottom">
    <button class="zhaicy-reply-button btn btn-info comment-submit" id="submit" type="submit" title="<?php _e('Submit', 'tt'); ?>">提交</button>
  <div class="comment-kits">
	    <button class="zhaicy-reply-button1 zhaicy-reply-button btn emotion-ico btn-info transition comment-kits" data-emotion="0" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">表情</button>
            <div id="zhaicy-comment-biaoqing" class="qqFace dropdown-menu" data-inputbox-id="comment-text"></div>
        </div>
  
    </div>
  </div>
</div>