<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/09/22 20:48
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<!-- 首页幻灯片 -->
<?php $vm = PopularVM::getInstance(); ?>
<?php if($vm->isCache && $vm->cacheTime) { ?>
    <!-- Popular posts cached <?php echo $vm->cacheTime; ?> -->
<?php } ?>
<div id="popular" class="hotpost col-md-4a block3">
  
    <div id="zhaicy-popular-container" class="zhaicy-popular-container">
        <!-- <h2 class="widget-title"><?php _e('Popular', 'tt'); ?><?php //_e('Most Popular', 'tt'); ?></h2> -->
        <div class="zhaicy-popular">
        <?php if($data = $vm->modelData) { ?>
            <?php foreach ($data as $seq=>$popular) { ?>
		  
		  
		  <a class="zhaicy-slideshow__item__link zhaicy-popular-link" href="<?php echo $popular['permalink']; ?>" target="_blank" style="background-color: rgb(153, 102, 151);">
			<img src="<?php echo LAZY_PENDING_IMAGE; ?>" data-original="<?php echo $popular['thumb']; ?>" alt="<?php echo $popular['title']; ?>" width="200" height="300" class="lazy zhaicy-popular-img" style="background-color: rgb(245, 217, 215);">
			<div class="zhaicy-popular-mask"></div>
			<h3 class="zhaicy-popular-title">
			  <span class="zhaicy-popular-text"><?php echo $popular['title']; ?></span>
			</h3>
		  </a>
		  
		  
            <?php } ?>
        <?php } ?>
        </div>
    </div>
</div>