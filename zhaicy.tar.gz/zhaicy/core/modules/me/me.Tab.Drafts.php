<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/12/15 00:16
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php global $tt_me_vars; $tt_user_id = $tt_me_vars['tt_user_id']; $tt_page = $tt_me_vars['tt_paged']; ?>
<div class="col col-right drafts">
    <?php $vm = MeDraftsVM::getInstance($tt_user_id, $tt_page); ?>
    <?php if($vm->isCache && $vm->cacheTime) { ?>
        <!-- Drafts cached <?php echo $vm->cacheTime; ?> -->
    <?php } ?>
    <?php $data = $vm->modelData; $drafts = $data->drafts; $count = $data->count; $max_pages = $data->max_pages; ?>
    <div class="me-tab-box drafts-tab">
        <div class="tab-content me-drafts">
            <!-- 草稿列表 -->
            <section style="width: 100%;" class="zhaicy-me-section my-drafts clearfix">
                <header style="padding: 0px 0px 0px 15px;top: -25px;"><span class="zhaicy-me-anniu"><?php _e('My Drafts', 'tt'); ?></span></header>
                <?php if($count > 0) { ?>
                    <div class="loop-wrap loop-rows posts-loop-rows clearfix">
                        <?php foreach ($drafts as $draft) { ?>
         <article id="<?php echo 'post-' . $draft['ID']; ?>" class="zhaicy-credits-poi-g_1-2 zhaicy-credits-item-1 is-xs is-type-post is-status-publish is-format-standard is-hentry">
            <div class="zhaicy-uc-post">
			<div class="zhaicy-credits-item__container"> 
			  <a href="<?php echo $draft['edit_link']; ?>" target="_blank" class="zhaicy-credits-item__thumbnail__container zhaicy-credits-card__thumbnail__container_xs">
                <img class="lazy zhaicy-credits-lazyload zhaicy-credits-item__thumbnail__img zhaicy-credits-lazyloaded-2" src="<?php echo LAZY_PENDING_IMAGE; ?>" data-original="<?php echo $draft['thumb']; ?>" alt="<?php echo $draft['title']; ?>" width="200" height="300"> 
			</a>
              <span><a class="zhaicy-credits-item__point-7" href="<?php echo $draft['edit_link']; ?>" title="<?php _e('Edit Draft', 'tt'); ?>">编辑文章 <i class="tico tico-new"></i></a> </span>
			  <div class="zhaicy-credits-item__point-5"><time datetime="<?php echo $draft['datetime']; ?>" title="<?php echo $draft['datetime']; ?>"><?php echo $draft['time']; ?></time></div>
			</div>
            <h3 class="zhaicy-credits-item__title" title="<?php echo $uc_latest_post['title']; ?>">
				<a href="<?php echo $draft['edit_link']; ?>" target="_blank" class="zhaicy-credits-item__title__link"><?php echo $draft['title']; ?></a>
			  </h3>
              </div>
		  </article>
                        <?php } ?>
                    </div>
                    <?php if($max_pages > 1) { ?>
                        <div class="pagination-mini clearfix">
                            <?php if($tt_page == 1) { ?>
                                <div class="col-md-3 prev disabled"><a href="javascript:;"><?php _e('← 上一页', 'tt'); ?></a></div>
                            <?php }else{ ?>
                                <div class="col-md-3 prev"><a href="<?php echo $data->prev_page; ?>"><?php _e('← 上一页', 'tt'); ?></a></div>
                            <?php } ?>
                            <div class="col-md-6 page-nums">
                                <span class="current-page"><?php printf(__('Current Page %d', 'tt'), $tt_page); ?></span>
                                <span class="separator">/</span>
                                <span class="max-page"><?php printf(__('Total %d Pages', 'tt'), $max_pages); ?></span>
                            </div>
                            <?php if($tt_page != $data->max_pages) { ?>
                                <div class="col-md-3 next"><a href="<?php echo $data->next_page; ?>"><?php _e('下一页 →', 'tt'); ?></a></div>
                            <?php }else{ ?>
                                <div class="col-md-3 next disabled"><a href="javascript:;"><?php _e('下一页 →', 'tt'); ?></a></div>
                            <?php } ?>
                        </div>
                    <?php } ?>
                <?php }else{ ?>
                    <div class="empty-content">
                        <span class="tico tico-dropbox"></span>
                        <p><?php _e('Nothing found here', 'tt'); ?></p>
                        <a class="btn btn-info" href="/"><?php _e('Back to home', 'tt'); ?></a>
                    </div>
                <?php } ?>
            </section>
        </div>
    </div>
</div>