<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/12/24 17:03
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php global $tt_me_vars; $tt_user_id = $tt_me_vars['tt_user_id']; ?>
<?php $allow_catIds = tt_filter_of_multicheck_option(tt_get_option('tt_contribute_cats', array())); ?>
<?php $categories = get_categories(array('include' => $allow_catIds)); ?>
<div class="col col-right contribute">
    <div class="me-tab-box contribute-tab">
        <div class="tab-content me-contribute">
            <!-- 文章编辑区 -->
            <section class="post-editor clearfix">
                <div class="info-group clearfix">
                    <?php if(current_user_can('edit_posts')): ?>
				  <!--投稿必读-->
				  <fieldset style="display:none" class="dl-declaration zhaicy-post-fieldset">
                    <legend class="zhaicy-me-anniu">
					<span class="zhaicy-me-anniu"><i class="fa fa-paint-brush fas" aria-hidden="true"></i>
					  <span class=""> 小宅：（投稿说明）</span></span></legend><div class="inn-account__item__content is-expand">
					<div class="inn-account__preface"><p class="zhaicy-me-p">欢迎您在宅次元进行投稿，投稿前请认真阅读投稿说明，投稿即代表您同意以下协议---</p><ol>
                    <li class="zhaicy-me-p">关于投稿：所有资源禁止H（不露点为准），如果发现H，您的贴子将会直接被编辑删除（本站所有图片将会采用阿里云oss的图片扫描技术）</li>
                    <li class="zhaicy-me-p">关于文章：文章内容请尽可能写满资源简介，建议您在百度百科复制粘贴即可。 动漫下载、游戏都要加上介绍和预览图（2-3张），不然无法通过审核哦（将会变回草稿状态）</li>
                    <li class="zhaicy-me-p">关于资源：图集类资源需大于 30 M，最好将资源存在百度云，游戏类资源需要您自行确定游戏能玩的前提下才能分享哦！</li>
                    <li class="zhaicy-me-p">发帖前一定搜索有没有重复资源，发现撞车将会以时间顺序为参考删除重复资源。（确定方法：搜索您要发的资源名称~~~）</li>
                    </ol>
                    <p class="zhaicy-me-p">投稿后您可以获得以下奖励：</p>
                    <ol>
                    <li class="zhaicy-me-p">发布成功 + 20积分</li>
                    </ol>
                    <p class="zhaicy-me-p">积分可以抽奖兑换奖品等</p>
                    <p class="zhaicy-me-p">如果您的资源失效后，我们会通过私信告知，帖子回到草稿状态 30 日，超时后帖子可能会飘到宇宙里～</p><p></p>
                    </div>
					</div>
				  </fieldset>
				  <p class="flip">点我查看投稿必读</p>
				    <!-- 标题 -->
                    <div class="zhaicy-me-section form-group">
			        <header style="padding: 0px 0px 0px 15px;top: -25px;"><span class="zhaicy-me-anniu"><?php _e('添加标题', 'tt'); ?></span></header>
                        <input type="text" class="form-control" name="post_title" placeholder="<?php _e('Input your title here', 'tt');?>" value="" aria-required='true' required>
					</div>
                    <!-- 摘要 -->
                    <div class="zhaicy-me-section form-group">
			        <header style="padding: 0px 0px 0px 15px;top: -25px;"><span class="zhaicy-me-anniu"><?php _e('Add excerpt', 'tt'); ?></span></header>
                        <textarea type="text" class="form-control" id="excerpt-input" name="post_excerpt" rows="5" placeholder=""></textarea>
                    </div>
                    <!-- 内容编辑器 -->
                    <div class="zhaicy-me-section form-group">
                        <?php tt_editor_quicktags(); ?>
                        <?php wp_editor( wpautop(__('Write your words here...', 'tt')), 'post_content', array('media_buttons'=>true, 'quicktags'=>true, 'editor_class'=>'form-control', 'editor_css'=>'<style>.wp-editor-container{border:1px solid #ddd;}.switch-html, .switch-tmce{height:25px !important}</style>' ) ); ?>
                    </div>
                    <!-- 分类选择 -->
                    <div id="zhaicy-select" class="zhaicy-me-select zhaicy-me-section form-group">
                      <header style="padding: 0px 0px 0px 15px;top: -15px;"><span class="zhaicy-me-anniu"><?php _e('Choose the category', 'tt'); ?></span></header>
                <!--        <select id="cat-selector" name="post_cat" class="form-control">     -->
                <!--            <?php foreach ($categories as $category) { ?> -->
                <!--            <option value="<?php echo $category->term_id; ?>"><?php echo $category->name; ?></option> -->
                <!--            <?php } ?> -->
                <!--        </select>       -->
                      
                  <?php wp_dropdown_categories('hide_empty=0&id=cat-selector&show_count=1&hierarchical=1'); ?>
                      
             <!--         <?php wp_list_categories('orderby=id&depth=2&hide_empty=0&title_li='); ?>-->
                      
                    </div>
                    <!-- 标签 -->
                    <div class="zhaicy-me-section form-group">
			  <header style="padding: 0px 0px 0px 15px;top: -25px;"><span class="zhaicy-me-anniu"><?php _e('Input the tags, comma separate multi tags', 'tt'); ?></span></header>
         <!--               <input type="text" class="form-control" id="tags-input" name="post_tags" placeholder="" value="">-->
                      <div class="tagsinput-primary">
	                 <input name="post_tags" id="tags-input" class="tagsinput" data-role="tagsinput" value="动漫图集" placeholder="输入后回车"/>
	                 </div>
                    </div>
                    <!-- 版权信息 - 源文章标题 -->
                    <div class="zhaicy-me-section form-group">
			  <header style="padding: 0px 0px 0px 15px;top: -25px;"><span class="zhaicy-me-anniu"><?php _e('Copyright - Original post title', 'tt'); ?></span></header>
                        <input type="text" class="form-control" id="origin-title" name="origin_title" placeholder="" value="">
                    </div>
                    <!-- 版权信息 - 源文章链接 -->
                    <div class="zhaicy-me-section form-group">
			  <header style="padding: 0px 0px 0px 15px;top: -25px;"><span class="zhaicy-me-anniu"><?php _e('Copyright - Original post link, please leave empty if yours is original', 'tt'); ?></span></header>
                        <input type="text" class="form-control" id="origin-link" name="origin_link" placeholder="" value="">
                    </div>
                    <!-- 内嵌免费资源 -->
                    <div class="zhaicy-me-section form-group">
			  <header style="padding: 0px 0px 0px 15px;top: -25px;"><span class="zhaicy-me-anniu"><?php _e('Embed free resources', 'tt'); ?></span></header>
                      <!--文章名字-->
                      <input id="free-downloads" name="free_downloads" rows="5" class="poi-form__control-zhaicy" type="text" placeholder="文章名称" title="文章名称" value="">
                      <!--文章链接-->
                      <input id="free-downloads2" name="free_downloads" rows="5" class="poi-form__control-zhaicy" type="text" placeholder="下载链接" title="下载链接" value="">
                      <!--文章密码-->
                      <input id="free-downloads3" name="free_downloads" rows="5" class="poi-form__control-zhaicy" type="text" placeholder="提取密码" title="提取密码" value="无">
                        <!--<textarea type="text" class="form-control" id="free-downloads" name="free_downloads" rows="5" placeholder=""></textarea>-->
                        <!--<p class="help-block"><?php _e('普通下载资源，格式为 资源1名称|资源1url|下载密码,资源2名称|资源2url|下载密码 资源名称与url用|隔开，不同资源用英文逗号隔开，url请添加http://头，如提供百度网盘加密下载可以填写密码，也可以留空', 'tt'); ?></p>-->
                    </div>
                    <!-- 内嵌付费资源 -->
<!-- <p><span><a href="#" id="AddMoreFileBox" class="btn btn-info">添加更多的input输入框</a></span></p>  
<div id="InputsWrapper">  
    <div>
        <input class="poi-form__control-zhaicy" type="text" name="mytext[0][postname]" id="fieldpostname_0" value="文章名1"/>
        <input class="poi-form__control-zhaicy" type="text" name="mytext[0][downloadurl]" id="fielddownloadurl_0" value="链接1"/>
        <input class="poi-form__control-zhaicy" type="text" name="mytext[0][passwd]" id="fieldpasswd_0" value="密码1"/>
        <input class="poi-form__control-zhaicy" type="text" name="mytext[0][creditnumber]" id="fieldcreditnumber_0" value="积分数1"/>
        <select style="width:10%" class="poi-form__control-zhaicy" name="mytext[0][huobi]" id="fieldhuobi_0" ><option value="credit">积分</option><option value="cash">金币</option></select>
        <a href="#" style="width:8%" class="poi-form__control-zhaicy2 btn btn-info removeclass">删除</a>
    </div>  
</div>-->
                  <script>  
/*$(document).ready(function() {  
  
    var MaxInputs       = 8; //maximum input boxes allowed  
    var InputsWrapper   = $("#InputsWrapper"); //Input boxes wrapper ID  
    var AddButton       = $("#AddMoreFileBox"); //Add button ID  
  
    var x = InputsWrapper.length; //initlal text box count  
    var FieldCount=1; //to keep track of text box added  
  
    $(AddButton).click(function (e)  //on add input button click  
    {  
        if(x <= MaxInputs) //max input box allowed  
        {  
            FieldCount++; //text box added increment  
            //add input box  
            $(InputsWrapper).append('<div><input class="poi-form__control-zhaicy" type="text" name="mytext['+FieldCount+'][postname]" id="fieldpostname_'+ FieldCount +'" value="Text '+ FieldCount +'"/><input class="poi-form__control-zhaicy" type="text" name="mytext['+FieldCount+'][downloadurl]" id="fielddownloadurl_'+ FieldCount +'" value="Text '+ FieldCount +'"/><input class="poi-form__control-zhaicy" type="text" name="mytext['+FieldCount+'][passwd]" id="fieldpasswd_'+ FieldCount +'" value="Text '+ FieldCount +'"/><input class="poi-form__control-zhaicy" type="text" name="mytext['+FieldCount+'][creditnumber]" id="fieldcreditnumber_'+ FieldCount +'" value="Text '+ FieldCount +'"/><select style="width:10%" class="poi-form__control-zhaicy" name="mytext['+FieldCount+'][huobi]" id="fieldhuobi_'+ FieldCount +'" ><option value="credit">积分</option><option value="cash">金币</option></select><a href="#" style="width:8%" class="poi-form__control-zhaicy2 btn btn-info removeclass">删除</a></div>');  
            x++; //text box increment  
        }  
        return false;  
    });  
  
    $("body").on("click",".removeclass", function(e){ //user click on remove text  
        if( x > 1 ) {  
                $(this).parent('div').remove(); //remove text box  
                x--; //decrement textbox  
        }  
        return false;  
    })   
  
}); */ 
</script>
                    <div class="zhaicy-me-section form-group">
			  <header style="padding: 0px 0px 0px 15px;top: -25px;"><span class="zhaicy-me-anniu"><?php _e('Embed sale resources', 'tt'); ?></span></header>
                      <!--文章名字-->
                      <input id="sale-downloads" name="sale_downloads" rows="5" class="poi-form__control-zhaicy" type="text" placeholder="文章名称" title="文章名称" value="">
                      <!--文章链接-->
                      <input id="sale-downloads2" name="sale_downloads" rows="5" class="poi-form__control-zhaicy" type="text" placeholder="下载链接" title="下载链接" value="">
                      <!--文章密码-->
                      <input id="sale-downloads3" name="sale_downloads" rows="5" class="poi-form__control-zhaicy" type="text" placeholder="提取密码" title="提取密码" value="无">
                      <!--积分数量-->
                      <input id="sale-downloads4" name="sale_downloads" rows="5" class="poi-form__control-zhaicy" type="text" placeholder="积分数量" title="积分数量" value="">
                      <!--货币选择-->
                      <select name="post_status2" class="inn-account__post__source__selector poi-form__control-zhaicy">
                        <option value="credit">积分</option>
                        <option value="cash">金币</option></select>
                        <!--<p class="help-block"><?php _e( '收费下载资源，格式为 资源名称|资源下载url1__密码1,资源下载url2__密码2|资源价格|币种(Cash或Credit)，一行一个资源记录', 'tt' );?></p>-->
                    </div>
                    <!-- 提交按钮 -->
                    <div style="margin: 0px 0;" class="separator"></div>
                    <div class="form-inline text-right pull-right submit-form">
                        <div class="form-group">
                            <select name="post_status" class="form-control">
                                <option value ="pending"><?php _e('Submit for review', 'tt');?></option>
                                <option value ="draft"><?php _e('Save draft', 'tt');?></option>
                                <?php if(current_user_can('publish_posts')) { ?>
                                <option value ="publish"><?php _e('Publish post', 'tt');?></option>
                                <?php } ?>
                            </select>
                        </div>
                        <input type="hidden" name="post_id" value="0">
                        <button class="btn btn-success" id="submit-post"><?php _e('Confirm Action', 'tt');?></button>
                    </div>
                    <?php else: ?>
                    <div class="warning">
                        <span class="tico tico-quill"></span>
                        <p><?php _e('Sorry, you do not have the capability of contributing', 'tt'); ?></p>
                    </div>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </div>
</div>