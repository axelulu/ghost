<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/12/14 22:05
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php global $tt_me_vars; ?>
<?php $tt_me_vars['tt_user_id'] = get_current_user_id(); ?>
<?php $tt_me_vars['tt_user'] = get_user_by('ID', $tt_me_vars['tt_user_id']); ?>
<?php $tt_me_vars['tt_paged'] = get_query_var('paged') ? : 1; ?>
<?php global $wp_query; $query_vars=$wp_query->query_vars; $me_tab = isset($query_vars['me_child_route']) && in_array($query_vars['me_child_route'], array_keys((array)json_decode(ALLOWED_ME_ROUTES))) ? $query_vars['me_child_route'] : 'settings'; $tt_me_vars['me_child_route'] = $me_tab; ?>
<aside style="overflow: auto;height: 600px;" class="col col-left">
    <nav class="nav clearfix">
        <ul class="me_tabs">
		  <li>
		    <a class="zhaicy-me-link">
			<i class="fas fa-address-card poi-icon inn-account__sidebar__item__link__icon poi-nav_verical__item__link__icon" aria-hidden="true"></i>
			<span>个人设置</span>
			</a>
			<ul class="zhaicy-me-link-item">
			  <li class="zhaicy-me-li-li">
			    <a class="zhaicy-me-link-item-one <?php echo tt_conditional_class('me_tab settings', $me_tab == 'settings'); ?>" href="<?php echo tt_url_for('my_settings', $tt_me_vars['tt_user_id']); ?>">
				  <i style="margin-bottom: 0px;" class="fas fa-cog poi-icon poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('SETTINGS', 'tt'); ?></span>
				</a>
			  </li>
			  <li>
			    <a class="zhaicy-me-link-item-one <?php echo tt_conditional_class('me_tab drafts', $me_tab == 'drafts'); ?>" href="<?php echo tt_url_for('my_drafts', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-copy poi-icon poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('MY DRAFTS', 'tt'); ?></span>
				</a>
			  </li>
			  <li>
			    <a class="zhaicy-me-link-item-one <?php echo tt_conditional_class('me_tab newpost', $me_tab == 'newpost'); ?>" href="<?php echo tt_url_for('new_post'); ?>">
				  <i class="fas fa-paint-brush poi-icon poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('New Post', 'tt'); ?></span>
				</a>
			  </li>
			</ul>
		  </li>
		  
		  <li>
		    <a class="zhaicy-me-link">
			<i class="fas fa-bell poi-icon inn-account__sidebar__item__link__icon poi-nav_verical__item__link__icon" aria-hidden="true"></i>
			<span>消息管理</span>
			</a>
			<ul class="zhaicy-me-link-item">
			  <li>
			    <a class="zhaicy-me-link-item-one <?php echo tt_conditional_class('me_tab notifications', $me_tab == 'notifications'); ?>" href="<?php echo tt_url_for('all_notify', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-bell poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('NOTIFICATIONS', 'tt'); ?></span>
				</a>
			  </li>
			  <li>
			    <a class="zhaicy-me-link-item-one <?php echo tt_conditional_class('me_tab messages', $me_tab == 'messages'); ?>" href="<?php echo tt_url_for('in_msg', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-envelope poi-icon poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('MESSAGES', 'tt'); ?></span>
				</a>
			  </li>
			  <li>
			    <a class="zhaicy-me-link-item-one <?php echo tt_conditional_class('me_tab orders', $me_tab == 'orders'); ?>" href="<?php echo tt_url_for('my_all_orders', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-shopping-cart poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('ORDERS', 'tt'); ?></span>
				</a>
			  </li>
			</ul>
		  </li>
		  
		  <li>
		    <a class="zhaicy-me-link">
			<i class="fas fa-user-circle poi-icon inn-account__sidebar__item__link__icon poi-nav_verical__item__link__icon" aria-hidden="true"></i>
			<span>个人中心</span>
			</a>
			<ul class="zhaicy-me-link-item">
			  <li>
			    <a class="zhaicy-me-link-item-one" href="<?php echo tt_url_for('uc_stars', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-heart poi-icon inn-account__sidebar__item__link__icon poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('MY STARS', 'tt'); ?></span>
				</a>
			  </li>
			  <li>
			    <a class="zhaicy-me-link-item-one" href="<?php echo tt_url_for('uc_latest', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-file-alt poi-icon poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('MY POSTS', 'tt'); ?></span>
				</a>
			  </li>
			  <li>
			    <a class="zhaicy-me-link-item-one" href="<?php echo tt_url_for('uc_followers', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-users poi-icon poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('MY FOLLOWERS', 'tt'); ?></span>
				</a>
			  </li>
			  <li>
			    <a class="zhaicy-me-link-item-one" href="<?php echo tt_url_for('uc_following', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-users poi-icon poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('MY FOLLOWING', 'tt'); ?></span>
				</a>
			  </li>
			</ul>
		  </li>
		  
		  <li>
		    <a class="zhaicy-me-link">
			<i class="fas fa-user-circle poi-icon inn-account__sidebar__item__link__icon poi-nav_verical__item__link__icon" aria-hidden="true"></i>
			<span>我的会员</span>
			</a>
			<ul class="zhaicy-me-link-item">
			  <li>
			    <a class="zhaicy-me-link-item-one <?php echo tt_conditional_class('me_tab membership', $me_tab == 'membership'); ?>" href="<?php echo tt_url_for('my_membership', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-user-circle poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('MEMBERSHIP', 'tt'); ?></span>
				</a>
			  </li>
			  <li>
			    <a class="zhaicy-me-link-item-one <?php echo tt_conditional_class('me_tab cash', $me_tab == 'cash'); ?>" href="<?php echo tt_url_for('my_cash', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-credit-card poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('MY CASH', 'tt'); ?></span>
				</a>
			  </li>
			  <li>
			    <a class="zhaicy-me-link-item-one <?php echo tt_conditional_class('me_tab credits', $me_tab == 'credits'); ?>" href="<?php echo tt_url_for('my_credits', $tt_me_vars['tt_user_id']); ?>">
				  <i class="fas fa-gem poi-icon poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('CREDITS', 'tt'); ?></span>
				</a>
			  </li>
			  <li>
			    <a class="zhaicy-me-link-item-one <?php echo tt_conditional_class('me_tab settings', $me_tab == 'settings'); ?>" href="<?php echo tt_add_redirect(tt_url_for('signout'), tt_get_current_url()); ?>">
				  <i class="fas fa-sign-out-alt poi-icon poi-nav_verical__item__link__icon-2" aria-hidden="true"></i>
				  <span><?php _e('Sign Out', 'tt'); ?></span>
				</a>
			  </li>
			</ul>
		  </li>
        </ul>
    </nav>
</aside>