<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2016/09/20 23:35
 *
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @see https://webapproach.net/tint.html
 */
?>
<!-- 首页推荐栏 -->
<?php $vm = SlideVM::getInstance(); ?>
<?php if ($vm->isCache && $vm->cacheTime) {
    ?>
<!-- Slide cached <?php echo $vm->cacheTime; ?> -->
<?php
} ?>

<div id="slider" class="zhaicy-homeslide header white <?php if (tt_get_option('tt_enable_home_full_width_slides', false)) {
        echo 'full block2';
    } else {
        echo 'col-md-8 block2';
    } ?>">
  
    <div style="padding: 0px 0px 0px 0px;" class="slides-wrap">
        <?php if ($data = $vm->modelData) {
        ?>
      <div class="zhaicy-lazyloaded zhaicy-recomm-post__header poi-panel__header zhaicy-panel__header">
  <h4 class="zhaicy-recomm-post__title poi-panel__title zhaicy-panel__title">
    <a class="zhaicy-recomm-post__title__link poi-panel__title__link zhaicy-panel__title__link" target="_blank">
      <i class="fa-star fa poi-icon" aria-hidden="true"></i>
      <span class="poi-icon__text">推荐栏</span></a>
  </h4>
</div>
            <div class="zhaicy-recomm-post__body zhaicy-card_variable-width__container">
                <?php foreach ($data as $seq => $slide) {
            ?>
                    
              <article class="zhaicy-recomm-post__item zhaicy-card_variable-width__item is-variable-width is-type-post is-status-publish is-format-standard is-hentry">
  <div class="zhaicy-recomm-post__item__container zhaicy-card_variable-width__item__container">
    <a href="<?php echo $slide['permalink']; ?>" target="_blank" class="zhaicy-recomm-post__item__link zhaicy-card_variable-width__item__link">
      <img class="lazy zhaicy-recomm-post__item__thumbnail__img zhaicy-card_variable-width__item__thumbnail__img zhaicy" src="<?php echo LAZY_PENDING_IMAGE; ?>" data-original="<?php echo $slide['thumb']; ?>" alt="<?php echo $slide['title']; ?>" width="200" height="300">
      </a>
      <div class="zhaicy-recomm-post__item__category zhaicy-card_variable-width__item__category zhaicy-card__category">
  <span class="zhaicy-recomm-post__item__category__item zhaicy-card_variable-width__item__category__item zhaicy-card__category__item" style="background-color: #ff6699;"><?php echo $slide['category']; ?></span></div>
    
    <h3 class="zhaicy-recomm-post__item__title zhaicy-card_variable-width__item__title" title="<?php echo $slide['title']; ?>">
      <a href="<?php echo $slide['permalink']; ?>" target="_blank" class="zhaicy-recomm-post__item__title__link zhaicy-card_variable-width__item__title__link"><?php echo $slide['title']; ?></a></h3>
    <a href="<?php echo $slide['author_url']; ?>" target="_blank" class="zhaicy-recomm-post__item__author__link zhaicy-card_variable-width__item__author__link" title="<?php echo $slide['author']; ?>">
      <img class="zhaicy-recomm-post__item__author__avatar__img zhaicy-card_variable-width__item__author__avatar__img zhaicy-lazyload inn-avatar__img zhaicy-lazyloaded lazy" title="<?php echo $slide['author']; ?>" src="<?php echo LAZY_PENDING_IMAGE; ?>" data-original="<?php echo $slide['thumb']; ?>" width="50" height="50" alt="<?php echo $slide['author']; ?>">
      <span class="zhaicy-recomm-post__item__author__name zhaicy-card_variable-width__item__author__name"><?php echo $slide['author']; ?></span></a>
    <div class="zhaicy-recomm-post__item__meta zhaicy-card_variable-width__item__meta">
      <span class="zhaicy-recomm-post__item__views zhaicy-card_variable-width__item__views" title="评论数">
        <i class="zhaicy-recomm-post__item__views__icon zhaicy-card_variable-width__item__views__icon tico tico-comments-o" aria-hidden="true"></i>
        <span class="poi-icon__text"><?php echo $slide['comment_count']; ?></span></span>
    </div>
  </div>
</article>
              
              
                <?php
        } ?>
            </div>
      
  <!--首页广告区域-->
      <?php echo tt_get_option('zhaicy_ad_1'); ?>
  
        <?php
    } ?>
    </div>
</div>