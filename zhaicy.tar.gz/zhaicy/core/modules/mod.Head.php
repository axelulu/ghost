<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2016/11/14 20:26
 *
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @see https://webapproach.net/tint.html
 */
?>
<?php $keywords_description = tt_get_keywords_and_description(); ?>
<!DOCTYPE html>
<html lang="zh">
<head>
  
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
  <!--自定义灯箱开始-->
  <script src="//code.jquery.com/jquery-3.2.1.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.css" target="_blank" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.2.5/jquery.fancybox.min.js"></script>
  <!--自定义灯箱结束-->
  <!--自定义css-->
  <link rel="stylesheet" href="<?php echo THEME_ASSET.'/css/custom.css';?>" target="_blank" />
  <!--自定义js-->
  <script type="text/javascript" src="<?php echo THEME_ASSET.'/js/custom.js';?>"></script>
  <script type="text/javascript" src="<?php echo THEME_ASSET.'/js/tagsinput.js';?>"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/hint.css/2.5.0/hint.css">
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <?php if (!isset($_GET['vp']) && get_post_type() != 'thread' && !get_query_var('is_thread_route')) {
    ?>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,minimal-ui=yes">
    <?php
} else {
        ?>
    <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no,minimal-ui=yes">
    <?php
    } ?>
    <title><?php echo tt_get_page_title(); ?></title>
    <meta name="keywords" content="<?php echo $keywords_description['keywords']; ?>">
    <meta name="description" content="<?php echo $keywords_description['description']; ?>">
    <!--    <meta name="author" content="Your Name,Your Email">-->
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-transform">
    <meta http-equiv="Cache-Control" content="no-siteapp"> <!-- 禁止移动端百度转码 -->
    <meta http-equiv="Cache-Control" content="private">
    <!--    <meta http-equiv="Cache-Control" content="max-age=0">-->
    <!--    <meta http-equiv="Cache-Control" content="must-revalidate">-->
    <meta name="apple-mobile-web-app-title" content="<?php bloginfo('name'); ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="format-detection" content="telephone=no, email=no"> <!-- 禁止自动识别电话号码和邮箱 -->
    <?php if ($favicon = tt_get_option('tt_favicon')) {
        ?>
        <link rel="shortcut icon" href="<?php echo $favicon; ?>" >
    <?php
    } ?>
    <?php if ($png_favicon = tt_get_option('tt_png_favicon')) {
        ?>
        <link rel="alternate icon" type="image/png" href="<?php echo $png_favicon; ?>" >
    <?php
    } ?>
    <link rel='https://api.w.org/' href="<?php echo tt_url_for('api_root'); ?>" >
    <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
    <link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
    <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
   
    <!--[if lt IE 9]>
    <script src="<?php echo THEME_ASSET.'/vender/js/html5shiv/3.7.3/html5shiv.min.js'; ?>"></script>
    <script src="<?php echo THEME_ASSET.'/vender/js/respond/1.4.2/respond.min.js'; ?>"></script>
    <![endif]-->
    <!--[if lte IE 7]>
    <script type="text/javascript">
        window.location.href = "<?php echo tt_url_for('upgrade_browser'); ?>";
    </script>
    <![endif]-->
    <link rel="stylesheet" type="text/css" href="<?php echo THEME_ASSET.'/css/'.CSS_BASE; ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo tt_get_css(); ?>"  />
    <link rel="stylesheet" type="text/css" href="<?php echo tt_get_custom_css(); ?>"  />
    <script><?php echo 'var VUETT='.json_encode(VUETT); ?></script>
    <script src="https://cdn.jsdelivr.net/npm/vue@2.5.11/dist/vue.runtime.min.js"></script>
    <!-- 页头自定义代码 -->
    <?php if (tt_get_option('tt_head_code')) {
        echo tt_get_option('tt_head_code');
    } ?>
    <?php wp_head(); ?>
</head>