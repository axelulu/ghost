<?php
/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2016/12/11 12:43
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */
?>
<?php global $origin_post; ?>
<?php
    $free_dls = trim(get_post_meta($origin_post->ID, 'tt_free_dl', true));
    $free_dls = !empty($free_dls) ? explode(',', str_replace(PHP_EOL, ',', $free_dls)) : array();
    $sale_dls = trim(get_post_meta($origin_post->ID, 'tt_sale_dl', true));
    $sale_dls = !empty($sale_dls) ? explode(',', str_replace(PHP_EOL, ',', $sale_dls)) : array();
    $sale_dls2 = tt_get_post_sale_resources($origin_post->ID);
?>
<div id="main" class="main primary col-md-8 download-box" role="main">
  
<div style="background-image: url(<?php echo tt_get_option('zhaicy_bg_1'); ?>);position: fixed; background-size: cover; top: 0; opacity: .3; left: 0; -webkit-filter: blur(<?php echo tt_get_option('zhaicy_blur_1'); ?>); filter: blur(<?php echo tt_get_option('zhaicy_blur_1'); ?>); right: 0; height: 100vh; z-index: -1;" class="inn-author-page__bg"></div>

    <div class="download">
      
        <div class="dl-declaration contextual-callout callout-warning">
          <p class="zhaicy-download-1">1. 手机端解压软件：<a href="http://acj2.pc6.com/pc6_soure/2017-6/ru.zdevs.zarchiver_8523.apk">软件下载</a></p>  
		  <p class="zhaicy-download-1"><?php _e('*注意：本站所刊载内容均为网络上收集整理，包括但不限于代码、应用程序、影音资源、电子书籍资料等，并且以研究交流为目的，所有仅供大家参考、学习，不存在任何商业目的与商业用途。若您使用开源的软件代码，请遵守相应的开源许可规范和精神，若您需要使用非免费的软件或服务，您应当购买正版授权并合法使用。如果你下载此文件，表示您同意只将此文件用于参考、学习使用而非任何其他用途。*', 'tt'); ?></p>
      <h3>一.磁力链接下载必看</h3>
     <p>由于本站有部分内容使用的是磁力链接，为方便使用，宅友们可以使用迅雷或者百度网盘离线下载功能获取到该资源。</p>
     <p><strong><a href="https://www.zhaicy.com/zhaicy/8623">磁力链接下载教程</a></strong></p>

<p><strong>有些番剧百度网盘离线下载同样会被和谐，请换用迅雷下载。</strong></p>

<p><strong>大家请不要使用百度云在线解压功能，因为这样百度云会检测到压缩包内的资源，导致资源更快被和谐～</strong></p>
<h3>二.BD字幕下载必看</h3>
<p>绝大数BD在压制做种时并不会加入字幕，因此我们需要自行搜索字幕，推荐几个好用的字幕网站：</p>
<ul>
 	<li><strong>1.VCB-Studio论坛：<a href="http://bbs.vcb-s.com/forum.php" target="_blank" rel="noopener">http://bbs.vcb-s.com/</a></strong></li>
 	<li><strong>2.伪射手字幕站：<a href="http://assrt.net/" target="_blank" rel="noopener">http://assrt.net/</a></strong></li>
</ul>
<h3>三.播放器推荐必看</h3>
<p>由于部分设备对<strong>x265(HEVC)</strong>编码的视频支持不佳，我们推荐以下播放器：</p>

<p>1.Windows平台推荐<a href="https://potplayer.daum.net/?lang=zh_CN" target="_blank" rel="noopener">potplayer</a></p>
<p>2.安卓平台推荐<a href="https://mxplayerdownload.co/" target="_blank" rel="noopener">MXplayer</a></p>
<p>3.iOS平台推荐<a href="https://itunes.apple.com/cn/app/nplayer/id1116905928?mt=8" target="_blank" rel="noopener">nplayer</a></p>

<h3>四.破解版网盘下载</h3>
<p>1.百度网盘被限速的漫友，PC端推荐使用<a href="https://www.zhaicy.com/zhaicy/8629" target="_blank" rel="noopener">Pan Download</a> 或 <a href="https://greasyfork.org/zh-CN/scripts/17800-%E8%A7%A3%E5%86%B3%E7%99%BE%E5%BA%A6%E4%BA%91%E5%A4%A7%E6%96%87%E4%BB%B6%E4%B8%8B%E8%BD%BD%E9%99%90%E5%88%B6" target="_blank" rel="noopener">油猴脚本</a>（<a href="https://greasyfork.org/zh-CN" target="_blank" rel="noopener">请先安装脚本管理器</a>）+<a href="https://www.internetdownloadmanager.com/" target="_blank" rel="noopener">IDM</a></p>
<p>2.安卓端使用山寨云<a href="https://www.zhaicy.com/zhaicy/8634" target="_blank" rel="noopener">Village</a></p>
</div>
      <p class="flip">点我查看下载必读</p>
      
        <?php load_mod(('banners/bn.Download.Top')); ?>
        <div class="dl-detail zhaicy-download-2">
		  <legend class="zhaicy-download-3">
			<span class="zhaicy-download-4 poi-label poi-label_success"><?php _e('Sale Resources', 'tt'); ?>（注册即送200积分）凡是{1. 点击购买 ( 积分)}均为无效链接</span></legend>
        <?php if(count($free_dls)) { ?>
            <ul class="free-resources">
            <?php $seq = 0; foreach ($free_dls as $free_dl) { ?>
                <?php $free_dl = explode('|', $free_dl); ?>
                <?php if(count($free_dl) < 2) {continue;}else{ $seq++; ?>
                <li>
                    <?php echo sprintf(__('%d. %2$s <a href="%3$s" target="_blank"><i class="tico tico-cloud-download"></i>点击下载</a> (密码: %4$s)', 'tt'), $seq, $free_dl[0], $free_dl[1], isset($free_dl[2]) ? $free_dl[2] : __('None', 'tt')); ?>
                </li>
                <?php } ?>
            <?php } ?>
            </ul>
        <?php } ?>
        <?php if(!count($sale_dls2) && count($sale_dls)) { ?>
            <?php if (is_user_logged_in()) { ?>
                <ul class="sale-resources">
                    <?php $seq = 0; foreach ($sale_dls as $sale_dl) { ?>
                        <?php $sale_dl = explode('|', $sale_dl); ?>
                        <?php if(count($sale_dl) < 2) {continue;}else{ $seq++; ?>
                            <li>
                                <?php if(tt_check_bought_post_resources($origin_post->ID, $seq)) { ?>
							  
                                    <?php echo sprintf(__('%d. %2$s <a href="%3$s" target="_blank"><i class="tico tico-cloud-download"></i>点击下载</a> (密码: %4$s)', 'tt'), $seq, $sale_dl[0], $sale_dl[1], isset($sale_dl[3]) ? $sale_dl[3] : __('None', 'tt')); ?>
                                <?php }else{ ?>
                                    <?php echo sprintf(__('%1$s. %2$s <a class="buy-resource" href="javascript:;" data-post-id="%3$s" data-resource-seq="%1$s" target="_blank"><i class="tico tico-cart"></i>点击购买</a> (%4$s Credits)', 'tt'), $seq, $sale_dl[0], $origin_post->ID, isset($sale_dl[2]) ? $sale_dl[2] : 1); ?>
                                <?php } ?>
                            </li>
                        <?php } ?>
                    <?php } ?>
                </ul>
            <?php } else { ?>
                <p><?php _e('付费资源需要<a class="login-actions"><i class="tico tico-sign-in"></i>登录</a>才能查看', 'tt'); ?></p>
            <?php } ?>
        <?php } ?>
        <?php if(count($sale_dls2)) { ?>
            <?php if (is_user_logged_in()) { ?>
                <ul class="sale-resources">
                    <?php foreach ($sale_dls2 as $sale_dl) { ?>
                        <li>
                            <!-- 资源名称|资源下载url1_密码1,资源下载url2_密码2|资源价格|币种 -->
                            <?php if(tt_check_bought_post_resources2($origin_post->ID, $sale_dl['seq'])) { ?>
                                <?php echo sprintf(__('%d. %2$s ', 'tt'), $sale_dl['seq'], $sale_dl['name']); ?>
                                <?php $pans = $sale_dl['downloads'];
                                $pan_seq = 0;
                                foreach ($pans as $pan) {
                                    $pan_seq++;
                                    
								  echo sprintf(__('<a href="%1$s" target="_blank"><i class="tico tico-cloud-download"></i>下载地址%2$d</a> (密码: %3$s)', 'tt'), $pan['url'], $pan_seq, isset($pan['password']) ? $pan['password'] : __('None', 'tt'));
                                }
                                ?>
                            <?php }else{ ?>
                                <?php echo sprintf(__('%1$s. %2$s <a class="buy-resource2" href="javascript:;" data-post-id="%3$s" data-resource-seq="%1$s" target="_blank"><i class="tico tico-cart"></i>点击购买</a> (%4$s %5$s)', 'tt'), $sale_dl['seq'], $sale_dl['name'], $origin_post->ID, $sale_dl['price'], $sale_dl['currency'] == 'cash' ? '元' : '积分'); ?>
                            <?php } ?>
                        </li>
                    <?php } ?>
                </ul>
            <?php } else { ?>
                <p><?php _e('付费资源需要<a class="login-actions"><i class="tico tico-sign-in"></i>登录</a>才能查看', 'tt'); ?></p>
            <?php } ?>
        <?php } ?>
        </div>
        <div class="tt-gg"></div>
        <div class="dl-help contextual-bg bg-info">
            <p><?php _e('如果您发现本文件已经失效不能下载，请联系站长修正！', 'tt'); ?></p>
            <p><?php _e('本站提供的资源多数为百度网盘下载，对于大文件，你需要安装百度云客户端才能下载！', 'tt'); ?></p>
            <p><?php _e('部分文件引用的官方或者非网盘类他站下载链接，你可能需要使用迅雷、BT等下载工具下载！', 'tt'); ?></p>
            <p><?php _e('本站推荐的资源均经由站长检测或者个人发布，不包含恶意软件病毒代码等，如果你发现此类问题，请向站长举报！', 'tt'); ?></p>
            <p><?php _e('本站仅提供文件的免费下载服务，如果你对代码程序软件的使用有任何疑惑，请留意相关网站论坛。对于本站个人发布的资源，站长会提供有限的帮助！', 'tt'); ?></p>
        </div>
    </div>
    <?php load_mod(('banners/bn.Download.Bottom')); ?>
</div>