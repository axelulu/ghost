## NOTE

* v2 版本API将采用OAuth(1/2)，暂时占位