<?php
// Code is Poetry.