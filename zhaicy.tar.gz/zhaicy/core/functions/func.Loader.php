<?php

/**
 * Copyright (c) 2014-2016, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2016/12/25 16:21
 *
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @see https://webapproach.net/tint.html
 */
?>
<?php

/* 引入常量 */
require_once 'Constants.php';

/* 设置默认时区 */
date_default_timezone_set('PRC');

if (!function_exists('load_dash')) {
    function load_dash($path)
    {
        load_template(THEME_DIR.'/dash/'.$path.'.php');
    }
}

if (!function_exists('load_api')) {
    function load_api($path)
    {
        load_template(THEME_DIR.'/core/api/'.$path.'.php');
    }
}

if (!function_exists('load_class')) {
    function load_class($path, $safe = false)
    {
        if ($safe) {
            @include_once THEME_DIR.'/core/classes/'.$path.'.php';
        } else {
            load_template(THEME_DIR.'/core/classes/'.$path.'.php');
        }
    }
}

if (!function_exists('load_func')) {
    function load_func($path, $safe = false)
    {
        if ($safe) {
            @include_once THEME_DIR.'/core/functions/'.$path.'.php';
        } else {
            load_template(THEME_DIR.'/core/functions/'.$path.'.php');
        }
    }
}

if (!function_exists('load_mod')) {
    function load_mod($path, $safe = false)
    {
        if ($safe) {
            @include_once THEME_DIR.'/core/modules/'.$path.'.php';
        } else {
            load_template(THEME_DIR.'/core/modules/'.$path.'.php');
        }
    }
}

if (!function_exists('load_tpl')) {
    function load_tpl($path, $safe = false)
    {
        if ($safe) {
            @include_once THEME_DIR.'/core/templates/'.$path.'.php';
        } else {
            load_template(THEME_DIR.'/core/templates/'.$path.'.php');
        }
    }
}

if (!function_exists('load_widget')) {
    function load_widget($path, $safe = false)
    {
        if ($safe) {
            @include_once THEME_DIR.'/core/modules/widgets/'.$path.'.php';
        } else {
            load_template(THEME_DIR.'/core/modules/widgets/'.$path.'.php');
        }
    }
}

if (!function_exists('load_vm')) {
    function load_vm($path, $safe = false)
    {
        if ($safe) {
            @include_once THEME_DIR.'/core/viewModels/'.$path.'.php';
        } else {
            load_template(THEME_DIR.'/core/viewModels/'.$path.'.php');
        }
    }
}

/* 载入option_framework */
load_dash('of_inc/options-framework');

/* 载入主题选项 */
load_dash('options');

defined('THEME_ASSET') || define('THEME_ASSET', of_get_option('tt_tint_static_cdn_path', THEME_ASSET));

/* 调试模式选项保存为全局变量 */
defined('TT_DEBUG') || define('TT_DEBUG', of_get_option('tt_theme_debug', false));
if (TT_DEBUG) {
    ini_set('display_errors', 'On');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', 'Off');
}

/* 载入后台相关处理逻辑 */
//if( is_admin() ){
load_dash('dash');
//}

/* 载入REST API功能控制函数 */
load_api('api.Config');

/* 载入功能函数 */

load_func('base/func.L10n');

load_func('base/func.Account');

load_func('base/func.Avatar');

load_func('base/func.Cache');

load_func('base/func.Comment');

load_func('base/func.Init');

load_func('base/func.Install');

load_func('base/func.Kits');

load_func('base/func.Mail');

load_func('base/func.Metabox');

load_func('base/func.Module');

load_func('base/func.Optimization');

load_func('base/func.Page');

load_func('base/func.PostMeta');

load_func('base/func.Rewrite');

load_func('base/func.Robots');

load_func('base/func.Schedule');

load_func('base/func.Script');

load_func('base/func.Seo');

load_func('base/func.Sidebar');

load_func('base/func.Template');

load_func('base/func.Thumb');

load_func('base/func.User');

load_func('base/func.Content');

load_func('base/func.Follow');

load_func('base/func.Message');

load_func('base/func.Referral');

load_func('base/func.Query');

load_func('base/func.Credit');

load_func('base/func.Cash');

load_func('base/func.Card');

load_func('base/func.Member');

load_func('base/func.IP');

load_func('base/func.ShortCode');

load_func('base/func.Download');

load_func('base/func.Image');

load_func('base/func.OAuth');

load_func('base/func.API.Actions');

load_func('base/func.Theme');

load_func('base/func.Bulletin');

load_func('base/func.Role');

load_func('thread/func.Thread');

load_func('thread/func.Thread.Data');

load_func('thread/func.Thread.Service');

load_func('base/func.Common.Service');

if (TT_PRO && tt_get_option('tt_enable_shop', false)) {
    load_func('func.Shop.Loader');
}

/* 载入类 */
load_class('class.Avatar');
load_class('class.Captcha');
load_class('class.Open');
load_class('class.PostImage');
load_class('class.Utils');
load_class('class.Member');
load_class('class.Async.Task');
load_class('class.Async.Email');
load_class('class.Enum');
// Plates模板引擎
load_class('plates/Engine');
load_class('plates/Extension/ExtensionInterface');
load_class('plates/Template/Data');
load_class('plates/Template/Directory');
load_class('plates/Template/FileExtension');
load_class('plates/Template/Folder');
load_class('plates/Template/Folders');
load_class('plates/Template/Func');
load_class('plates/Template/Functions');
load_class('plates/Template/Name');
load_class('plates/Template/Template');
load_class('plates/Extension/Asset');
load_class('plates/Extension/URI');

if (is_admin()) {
    load_class('class.Tgm.Plugin.Activation');
}
if (TT_PRO && tt_get_option('tt_enable_shop', false)) {
    load_class('shop/class.Product');
    load_class('shop/class.OrderStatus');
    load_class('shop/alipay/alipay_notify.class');
    load_class('shop/alipay/alipay_submit.class');
}

/* 载入数据模型 */
load_vm('vm.Base');
load_vm('vm.Home.Slides');
load_vm('vm.Home.Popular');
load_vm('vm.Stickys');
load_vm('vm.Home.CMSCats');
load_vm('vm.Home.Latest');
load_vm('vm.Home.FeaturedCategory');
load_vm('vm.Single.Post');
load_vm('vm.Single.Page');
load_vm('vm.Post.Comments');
load_vm('vm.Category.Posts');
load_vm('vm.Tag.Posts');
load_vm('vm.Date.Archive');
load_vm('vm.Term.Posts');
load_vm('widgets/vm.Widget.Author');
load_vm('widgets/vm.Widget.HotHit.Posts');
load_vm('widgets/vm.Widget.HotReviewed.Posts');
load_vm('widgets/vm.Widget.Recent.Comments');
load_vm('widgets/vm.Widget.Latest.Posts');
load_vm('widgets/vm.Widget.CreditsRank');
load_vm('uc/vm.UC.Latest');
load_vm('uc/vm.UC.Stars');
load_vm('uc/vm.UC.Comments');
load_vm('uc/vm.UC.Followers');
load_vm('uc/vm.UC.Following');
load_vm('uc/vm.UC.Chat');
load_vm('uc/vm.UC.Profile');
load_vm('me/vm.Me.Settings');
load_vm('me/vm.Me.Credits');
load_vm('me/vm.Me.Drafts');
load_vm('me/vm.Me.Messages');
load_vm('me/vm.Me.Notifications');
load_vm('me/vm.Me.EditPost');
load_vm('vm.Search');
if (TT_PRO && tt_get_option('tt_enable_shop', false)) {
    load_vm('shop/vm.Shop.Header.SubNav');
    load_vm('shop/vm.Shop.Home');
    load_vm('shop/vm.Shop.Category');
    load_vm('shop/vm.Shop.Tag');
    load_vm('shop/vm.Shop.Search');
    load_vm('shop/vm.Shop.Product');
    load_vm('shop/vm.Shop.Comment');
    load_vm('shop/vm.Shop.LatestRated');
    load_vm('shop/vm.Shop.ViewHistory');
    load_vm('shop/vm.Embed.Product');
}
load_vm('bulletin/vm.Bulletin');
load_vm('bulletin/vm.Bulletins');
if (TT_PRO) {
    load_vm('me/vm.Me.Order');
    load_vm('me/vm.Me.Orders');
    load_vm('me/vm.Me.Membership');
    load_vm('me/vm.Me.Cash');
    load_vm('management/vm.Mg.Status');
    load_vm('management/vm.Mg.Comments');
    load_vm('management/vm.Mg.Coupons');
    load_vm('management/vm.Mg.Members');
    load_vm('management/vm.Mg.Orders');
    load_vm('management/vm.Mg.Order');
    load_vm('management/vm.Mg.Posts');
    load_vm('management/vm.Mg.Users');
    load_vm('management/vm.Mg.User');
    load_vm('management/vm.Mg.Products');
    load_vm('management/vm.Mg.Cards');
}

/* 载入小工具 */
load_widget('wgt.TagCloud');
load_widget('wgt.Author');
load_widget('wgt.HotHits.Posts');
load_widget('wgt.HotReviews.Posts');
load_widget('wgt.RecentComments');
load_widget('wgt.Latest.Posts');
load_widget('wgt.UC');
load_widget('wgt.Float');
load_widget('wgt.EnhancedText');
load_widget('wgt.Donate');
load_widget('wgt.AwardCoupon');
load_widget('wgt.CreditsRank');
load_widget('wgt.CreditIntro');

/* 实例化异步任务类实现注册异步任务钩子 */
new AsyncEmail();

/* 投诉相关函数 */
function wpts_activation_cretable(){
	global $wpdb;
	$table_name = $wpdb->prefix.'wpts';
	if($wpdb->get_var("show tables like '$table_name'") != $table_name){
		$sql = " CREATE TABLE `$table_name` (
			`wpts_id` bigint(20) NOT NULL AUTO_INCREMENT,
			PRIMARY KEY(wpts_id),
			`wpts_date` timestamp not null default current_timestamp,
			`wpts_type` int,
			`post_id` int,
			`postuser` int,
			`other` longtext,
			`ip` longtext
		) CHARSET=utf8;";
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}
}
if (!defined('wpts_DIR'))	define('wpts_DIR',get_stylesheet_directory_uri()."/wpts/");
function wpts_insertdate($wpts_type,$post_id,$postuser,$other,$ip){
	global $wpdb;  
	$data['ip'] = (string)$ip;
  	$data['other'] = (string)$other;
 	$data['postuser'] = (int)$postuser;
 	$data['post_id'] = (int)$post_id;
 	$data['wpts_type'] = (int)$wpts_type;
	$wpdb->insert( $wpdb->prefix.'wpts', $data);
}

function checktsnum($ip,$num){
	global $wpdb;
	global $table_prefix;
	$wpts_table_name = $table_prefix.'wpts';
  	$have = $wpdb->get_var("SELECT COUNT(*) FROM $wpts_table_name where ip = '$ip' and to_days(wpts_date) = to_days(now())");
  	if($have <= $num){
    	return true;
    }else{
      	return false;
    }
}

function wpts_getRealIp(){
	if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
		$ip = getenv('HTTP_CLIENT_IP');
	} elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
		$ip = getenv('HTTP_X_FORWARDED_FOR');
	} elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
		$ip = getenv('REMOTE_ADDR');
	}elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : '';
}

function ajaxwpts(){
	$wpts_type = isset($_POST['wpts_type']) ? $_POST['wpts_type'] : '';
	$post_id = isset($_POST['post_id']) ? $_POST['post_id'] : '';
	$postuser = wptsuser();
	$other = isset($_POST['other']) ? $_POST['other'] : '';
	$security = isset($_POST['security']) ? $_POST['security'] : '';
	$ip = htmlspecialchars(wpts_getRealIp());
	$wpts_type = intval($wpts_type);
	$post_id = intval($post_id);
	$postuser = intval($postuser);
	$other = htmlspecialchars($other);
	$security = htmlspecialchars($security);
	if(wp_verify_nonce( $security, 'wpts'.$post_id ) && checktsnum($ip,'300')==true){
		wpts_insertdate($wpts_type,$post_id,$postuser,$other,$ip);
	}
}
add_action('wp_ajax_nopriv_ajaxwpts', 'ajaxwpts');
add_action('wp_ajax_ajaxwpts', 'ajaxwpts');

function wptsuser(){
	if(is_user_logged_in()){
		return get_current_user_id();
	}else{
		return '0';
	}
}
function wpts_nonce(){
    global $post;
    $nonce = wp_create_nonce('wpts'.$post->ID); //生成nonce
    return $nonce;
}

function charuts($content){

if(is_singular('post')||is_page()) { 
	$content =$content.'
<div class="outwin cont-report">
	<div class="outwin-title">
		<strong>'._('内容投诉').'</strong>
	</div>
	<div class="zhaicy-toushu fadeScale  outwin-body" style="display:none;padding: 15px;">
		<form style="height: 100%;position: relative;" class="contReportForm tsForm" name="contReportForm">
			<fieldset style="
            display: inline-block;
    -webkit-margin-start: 0px;
    -webkit-margin-end: 0px;
    -webkit-padding-before: 0em;
    -webkit-padding-start: 0em;
    -webkit-padding-end: 0em;
    -webkit-padding-after: 0em;
    min-width: -webkit-min-content;
    margin: 0px;
    background: hsla(0,0%,100%,.95);
    padding: 1rem 2rem 0;
    margin-bottom: 20px;
    width: 100%;
    border: 0px solid #fff;
            padding: 0px;">
				<div class="zhaicy_toushu_h2">'._('您认为 ID:').'<span class="report-id fc-red">'.get_the_ID().'</span> '._('这篇内容有什么问题？').'</div>
				<ul class="form-list" style="list-style: none;">
					<li style="padding: 0px 20px;" class="form-line">
					<label class="radio-labelts" style="display: block;">
					<input type="radio" name="ts" value="1">'._('内容违规：存在色情暴力反动').'
					</label>
					<label class="radio-labelts" style="display: block;">
					<input type="radio" name="ts" value="2">'._('内容侵权：涉嫌侵犯他人版权').'
					</label>
					<label class="radio-labelts" style="display: block;">
					<input type="radio" name="ts" value="3">'._('恶意广告：有未明确标注').'
					</label>
					<label class="radio-labelts" style="display: block;">
					<input type="radio" name="ts" value="4" class="other">'._('其他问题').'
					</label>
					</li>
					<li style="padding: 0px 20px;" class="other-inputt" style="display:none">
					<textarea style="height: 40px;width: 100%;" name="ReportTxt" rows="3" maxlength="200" class="other-input" placeholder="'._('请填写你认为存在的其他问题，200字以内').'" datatype="*" nullmsg="'._('请其他填写问题描述').'"></textarea>
					</li>
					<li style="width: 100%;position: absolute;bottom: 0px;" class="form-bline">
					<span style="display:none;" class="norts">'.wpts_nonce().'</span>
					<button type="button" style="border-radius: 10px;width: 100%;margin:0px" class="btn btn-info btn-block submit" onclick="tssubmit()">'._('提交').'</button>
					</li>
				</ul>
			</fieldset>
		</form>
	</div>
</div>';
}
	return $content; 
}
add_filter ('the_content', 'charuts');


function wptsjs(){
	if(is_singular('post')||is_page()) { 
	?>
<script>
function loadjscssfile(filename){
		var fileref=document.createElement('script')//创建标签
		fileref.setAttribute("type","text/javascript")//定义属性type的值为text/javascript
		fileref.setAttribute("src", filename)//文件的地址
		document.getElementsByTagName("head")[0].appendChild(fileref) 
} 
if (typeof jQuery == 'undefined') { 
loadjscssfile("https://cdn.bootcss.com/jquery/3.3.1/jquery.min.js"); 
}
$('.outwin-body').click(function(){
	if($("input[name='ts']:checked").val()=='4'){
		$('.other-inputt').show();
	}else{
		$('.other-inputt').hide();
	}
});
function tssubmit(){
	a = $("input[name='ts']:checked").val();
	id = $('.report-id').html();
	nor = $('.norts').html();
	if(a==null){
		alert('<?php _e('请选择问题'); ?>');
	}else if(a !== '4'){
		$.post("<?php echo home_url('/wp-admin/admin-ajax.php?action=ajaxwpts'); ?>", { 
			wpts_type: a,
			post_id: id,
			postuser:"<?php echo wptsuser(); ?>",
			other:"",
			security:nor} 
		);
		alert('<?php _e('您的建议已收到'); ?>');
		$('.cont-report').hide();
	}else if(a == '4'){
		b = $('.other-input').val();
		if(b==''){
			alert('<?php _e('请先填写内容'); ?>');
		}else{
			$.post("<?php echo home_url('/wp-admin/admin-ajax.php?action=ajaxwpts'); ?>", { 
				wpts_type: a,
				post_id: id,
				postuser:"<?php echo wptsuser(); ?>",
				other:b,
				security:nor} 
			);
			alert('<?php _e('您的建议已收到'); ?>');
			$('.cont-report').hide();
		}
	}
}
</script>		

<?php
	}
}
add_action('wp_footer','wptsjs');


//设置页面
function wpts_menu_page() {

	$title = esc_html__('投诉列表', '投诉列表');

	add_menu_page($title, $title, 'manage_options', 'wpts_settings', 'wpts_display_settings');

}
add_action('admin_menu', 'wpts_menu_page');

function wptsfl($a){
	if($a=='1'){
    	return '内容违规：存在色情、暴力、反动等内容';
    }elseif($a=='2'){
      return '内容侵权：涉嫌侵犯他人版权';
    }elseif($a=='3'){
      return '恶意广告：有未明确标注的商业推广行为';
    }elseif($a=='4'){
      return '其他问题';
    }	
}

function checkuserts($a){
	if($a=='0'){
		return '未登录';
    }else{
      if (function_exists( 'zrz_get_user_page_url' ) ) {
        $display_name = get_the_author_meta('display_name',$a);
		$display_name = zrz_get_content_ex($display_name,16);
		return '<a target="_blank" href="'.zrz_get_user_page_url($a).'">'.$display_name.'</a>';
      }else{
      	return $a;
      }
    }	
}

function wpts_display_settings(){
  	global $wpdb;
	global $table_prefix;
	$wpts_table_name = $table_prefix.'wpts';
  	if(isset($_POST['scwpts'])) {
      	$delip = $_POST['scwpts'];
		$wpdb->query("DELETE FROM $wpts_table_name WHERE ip= '$delip'");
	} 
  	if(isset($_GET['id'])&&!empty($_GET['id'])){
		$uid=intval($_GET['id']);
		$wpdb->query("DELETE FROM $wpts_table_name WHERE wpts_id=$uid");
	}
  	$messagesalll = $wpdb->get_results("SELECT wpts_id,wpts_date,wpts_type,post_id,postuser,other,ip FROM $wpts_table_name ORDER BY wpts_id DESC LIMIT 150",ARRAY_A);

?>


<div style="padding: 20px;">
  <h2>投诉记录（最近150条）</h2>
<form action="" method="post" enctype="multipart/form-data" class="submit-form" id="m-form"> 
	<input style="width: 200px;" id="text-box" class="text-box" type="text" name="scwpts" placeholder="输入要删除所有投诉的ip"> 
	<input class="submit-btn" type="submit" value="删除">
</form>
<table class="wp-list-table widefat fixed striped shop_page_order_option" style="max-width: 100%;">
  <thead>
  <tr>
    <td style="width: 50px;">ID</td>
    <td style="width: 70px;">时间</td> 
    <td style="width: 270px;">投诉类型</td>
    <td>投诉文章</td>
    <td style="width: 70px;">投诉用户ID</td>
    <td>描述</td>
    <td>投诉人ip</td>
    <td>删除</td>
  </tr>
    </thead>
<tbody>
<?php  
  	foreach($messagesalll as $a){
   echo '<tr>
   	<td>'.$a['wpts_id'].'</td>
    <td>'.$a['wpts_date'].'</td>
    <td>'.wptsfl($a['wpts_type']).'</td>
    <td><a target="_blank" href="'.get_permalink($a['post_id']).'">'.get_the_title($a['post_id']).'[ID:'.$a['post_id'].']</a></td>
    <td>'.checkuserts($a['postuser']).'</td>
    <td>'.$a['other'].'</td>
    <td>'.$a['ip'].'</td>
    <td><a href="'.home_url('/wp-admin/admin.php?page=wpts_settings&id='.$a['wpts_id']).'" >已阅，删了</a></td>
  </tr>';  
    }
  
?>
</tbody>
</table>
</div>
<?php
}


/*
Plugin Name: Baidu-Accept
Plugin URI: http://www.d4v.com.cn
Description: 判断当前文章是否被百度收录，若没有被收录则可点击提交至百度，加速收录！(此插件在文章页面仅管理员可见) 
Version: 1.0
Author: Jovae
Author URI: http://www.d4v.com.cn
License: GPL
*/
function d4v($url){
	$url='http://www.baidu.com/s?wd='.$url;
	$curl=curl_init();
	curl_setopt($curl,CURLOPT_URL,$url);
	curl_setopt($curl,CURLOPT_RETURNTRANSFER,1);
	$rs=curl_exec($curl);
	curl_close($curl);
	if(!strpos($rs,'没有找到')){
		return 1;
	}else{
		return 0;
	}
}
add_filter( 'the_content',  'baidu_submit' );
function baidu_submit( $content ) {
	if( is_single() && current_user_can( 'manage_options') )
		if(d4v(get_permalink()) == 1) 
			$content="<p align=right>百度已收录(仅管理员可见)</p>".$content; 
		else 
			$content="<p align=right><b><a style=color:red target=_blank href=http://zhanzhang.baidu.com/sitesubmit/index?sitename=".get_permalink().">百度未收录!点击此处提交</a></b>(仅管理员可见)</p>".$content;  
		return $content;
	}

/** 
* WordPress 后台管理员免密一键切换其他账号登录 
* https://www.dujin.org/fenxiang/wp/10144.html 
*/ 
function wpdx_user_switch_action($actions, $user){
    $capability = (is_multisite())?'manage_site':'manage_options';
    if(current_user_can($capability)){
        $actions['login_as'] = '<a title="以此身份登录" href="'.wp_nonce_url("users.php?action=login_as&users=$user->ID", 'bulk-users').'">以此身份登录</a>';
    }
    return $actions;
}
add_filter('user_row_actions', 'wpdx_user_switch_action', 10, 2);
 
function wpdx_handle_user_switch_action($sendback, $action, $user_ids){
    if($action == 'login_as'){
        wp_set_auth_cookie($user_ids, true);
        wp_set_current_user($user_ids);
    }
    return admin_url();
}
add_filter('handle_bulk_actions-users','wpdx_handle_user_switch_action', 10, 3);


/*
==================================================
去除分类标志（不需要可删除）
==================================================
*/
// 去掉链接中category分类标志
add_action( 'load-themes.php',  'no_category_base_refresh_rules');
add_action('created_category', 'no_category_base_refresh_rules');
add_action('edited_category', 'no_category_base_refresh_rules');
add_action('delete_category', 'no_category_base_refresh_rules');
function no_category_base_refresh_rules() {
    global $wp_rewrite;
    $wp_rewrite -> flush_rules();
}
// register_deactivation_hook(__FILE__, 'no_category_base_deactivate');
// function no_category_base_deactivate() {
//     remove_filter('category_rewrite_rules', 'no_category_base_rewrite_rules');
//     // We don't want to insert our custom rules again
//     no_category_base_refresh_rules();
// }
// Remove category base
add_action('init', 'no_category_base_permastruct');
function no_category_base_permastruct() {
    global $wp_rewrite, $wp_version;
    if (version_compare($wp_version, '3.4', '<')) {         // For pre-3.4 support         $wp_rewrite -> extra_permastructs['category'][0] = '%category%';
    } else {
        $wp_rewrite -> extra_permastructs['category']['struct'] = '%category%';
    }
}
// Add our custom category rewrite rules
add_filter('category_rewrite_rules', 'no_category_base_rewrite_rules');
function no_category_base_rewrite_rules($category_rewrite) {
    //var_dump($category_rewrite); // For Debugging
    $category_rewrite = array();
    $categories = get_categories(array('hide_empty' => false));
    foreach ($categories as $category) {
        $category_nicename = $category -> slug;
        if ($category -> parent == $category -> cat_ID)// recursive recursion
            $category -> parent = 0;
        elseif ($category -> parent != 0)
            $category_nicename = get_category_parents($category -> parent, false, '/', true) . $category_nicename;
        $category_rewrite['(' . $category_nicename . ')/(?:feed/)?(feed|rdf|rss|rss2|atom)/?$'] = 'index.php?category_name=$matches[1]&feed=$matches[2]';
        $category_rewrite['(' . $category_nicename . ')/page/?([0-9]{1,})/?$'] = 'index.php?category_name=$matches[1]&paged=$matches[2]';
        $category_rewrite['(' . $category_nicename . ')/?$'] = 'index.php?category_name=$matches[1]';
    }
    // Redirect support from Old Category Base
    global $wp_rewrite;
    $old_category_base = get_option('category_base') ? get_option('category_base') : 'category';
    $old_category_base = trim($old_category_base, '/');
    $category_rewrite[$old_category_base . '/(.*)$'] = 'index.php?category_redirect=$matches[1]';
    //var_dump($category_rewrite); // For Debugging
    return $category_rewrite;
}
// Add 'category_redirect' query variable
add_filter('query_vars', 'no_category_base_query_vars');
function no_category_base_query_vars($public_query_vars) {
    $public_query_vars[] = 'category_redirect';
    return $public_query_vars;
}
// Redirect if 'category_redirect' is set
add_filter('request', 'no_category_base_request');
function no_category_base_request($query_vars) {
    //print_r($query_vars); // For Debugging
    if (isset($query_vars['category_redirect'])) {
        $catlink = trailingslashit(get_option('home')) . user_trailingslashit($query_vars['category_redirect'], 'category');
        status_header(301);
        header("Location: $catlink");
        exit();
    }
    return $query_vars;
}

//获取网站父目录名字
function zhaicy_father_name(){
$category = get_the_category();$parent = get_cat_name($category[0]->category_parent);
	if (!empty($parent)) {
		echo $parent;
	} else {
		echo $category[0]->cat_name;
	}
}
function get_current_category_id() {
$current_category = single_cat_title('', false);//获得当前分类目录名称
return get_cat_ID($current_category);//获得当前分类目录 ID
}


/*wordpress 仿bilibili 目录显示当前一周更新文章数量*/
function get_this_week_post_count_by_category($id){
 
    $date_query = array(
                        array(
                            'after'=>'1 week ago'
                            )
                        );
    $tax_query = array(
                    array(
                        'taxonomy' => 'category',
                            'field' => 'id',
                            'terms' => $id
                        )
                );
 
    $args = array(
                    'post_type' => 'post',
                    'post_status'=>'publish',
                    'tax_query' => $tax_query,
                    'date_query' => $date_query,
                    'no_found_rows' => true,
                    'suppress_filters' => true,
                    'fields'=>'ids',
                    'posts_per_page'=>-1
                );
 
    $query = new WP_Query( $args );
 
    $a = $query->post_count;
	if($a=='0'){
		return '';
	}
	return $a;
}

function zrz_add_has_children_to_nav_items_num( $items ){
    foreach ( $items as $item ){
        if($item->menu_item_parent=='0' ){
				$a=get_this_week_post_count_by_category($item->object_id);
				$item->title .= '<span class="num">'.$a.'</span>';
			}
    }
    return $items;
}
add_filter( 'wp_nav_menu_objects', 'zrz_add_has_children_to_nav_items_num' );


//自定义分类法
//为主题文章编辑器集成下一页按钮
//add_filter( 'mce_buttons', 'cmp_add_page_break_button', 1, 2 );
//function cmp_add_page_break_button( $buttons, $id ){
//if ( 'content' != $id )
//return $buttons;
//array_splice( $buttons, 13, 0, 'wp_page' );
//return $buttons;
//}
//view实现排序
// SEARCH FILTER 
function csyor_search_filter($query) {
  if( $query->is_search ) {
    $query->set('v_sortby' , 'views'); 
    $query->set('v_orderby' , 'desc'); 
    add_filter('posts_fields', 'views_fields'); 
    add_filter('posts_join', 'views_join'); 
    add_filter('posts_where', 'views_where'); 
    add_filter('posts_orderby', 'views_orderby'); 
  } 
} 
add_filter('pre_get_posts' , 'csyor_search_filter');

/*
==================================================
fancybox图片灯箱效果
==================================================
*/
add_filter('the_content', 'fancybox1');
add_filter('the_content', 'fancybox2');
function fancybox1($content){ 
    global $post;
    $pattern = "/<img(.*?)src=('|\")([^>]*).(bmp|gif|jpeg|jpg|png|swf)('|\")(.*?)>/i";
    $replacement = '<a$1href=$2$3.$4$5 data-fancybox="images"><img$1src=$2$3.$4$5$6></a>';
    $content = preg_replace($pattern, $replacement, $content);
    return $content;
}
function fancybox2($content){ 
    global $post;
    $pattern = "/<a(.*?)href=('|\")([^>]*).(bmp|gif|jpeg|jpg|png|swf)('|\")(.*?)>(.*?)<\/a>/i";
    $replacement = '<a$1href=$2$3.$4$5 data-fancybox="images"$6>$7</a>';
    $content = preg_replace($pattern, $replacement, $content);
    return $content;
}
//文章目录
function article_index($content) {
$matches = array();
$ul_li = '';
$r = '/<h([2-6]).*?\>(.*?)<\/h[2-6]>/is';
if(is_single() && preg_match_all($r, $content, $matches)) {
foreach($matches[1] as $key => $value) {
$title = trim(strip_tags($matches[2][$key]));
$content = str_replace($matches[0][$key], '<h' . $value . ' id="title-' . $key . '">'.$title.'</h2>', $content);
$ul_li .= '<li><a href="#title-'.$key.'" title="'.$title.'">'.$title."</a></li>\n";
}
$content = "\n<div id=\"article-index\">
<strong>文章目录</strong>
<ul id=\"index-ul\">\n" . $ul_li . "</ul>
</div>\n" . $content;
}
return $content;
}
add_filter( 'the_content', 'article_index' );