<?php

/**
 * 每天00:00检查过期订单.
 *
 * @since 2.3.0
 */
function tt_orders_maintenance_setup_schedule()
{
    if (!wp_next_scheduled('tt_orders_maintenance_daily_event')) {
        wp_schedule_event('1193875200', 'daily', 'tt_orders_maintenance_daily_event');
    }
}
add_action('wp', 'tt_orders_maintenance_setup_schedule');

/**
 * 订单状态维护定时任务回调函数.
 *
 * @since 2.3.0
 */
function tt_orders_maintenance_do_this_daily()
{
    $maintain_days = (int) tt_get_option('tt_maintain_orders_deadline', 0);
    if ($maintain_days < 1) {
        return;
    }

    tt_maintain_orders($maintain_days);
}
add_action('tt_orders_maintenance_daily_event', 'tt_orders_maintenance_do_this_daily');
