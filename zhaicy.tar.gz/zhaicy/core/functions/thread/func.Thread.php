<?php
/**
 * Copyright (c) 2016-2018, WebApproach.net
 * All right reserved.
 *
 * @since 2.6.0
 * @package Tint
 * @author Zhiyan
 * @date 2018/4/29 下午3:05
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */

?>
<?php

/**
 * 创建论坛自定义文章类型.
 *
 * @since 2.6.0
 */
function tt_create_thread_post_type()
{
    $thread_slug = tt_get_option('tt_thread_archives_slug', 'thread');
    register_post_type('thread',
        array(
            'labels' => array(
                'name' => _x('Threads', 'taxonomy general name', 'tt'),
                'singular_name' => _x('Thread', 'taxonomy singular name', 'tt'),
                'add_new' => __('Add New Thread', 'tt'),
                'add_new_item' => __('Add New Thread', 'tt'),
                'edit' => __('Edit', 'tt'),
                'edit_item' => __('Edit Thread', 'tt'),
                'new_item' => __('Add Thread', 'tt'),
                'view' => __('View', 'tt'),
                'all_items' => __('All Threads', 'tt'),
                'view_item' => __('View Thread', 'tt'),
                'search_items' => __('Search Thread', 'tt'),
                'not_found' => __('Thread not found', 'tt'),
                'not_found_in_trash' => __('Thread not found in trash', 'tt'),
                'parent' => __('Parent Thread', 'tt'),
                'menu_name' => __('Community Thread', 'tt'),
            ),

            'public' => true,
            'menu_position' => 16,
            'supports' => array('title', 'author', 'comments', 'excerpt', 'custom-fields'), // 'editor'
            'taxonomies' => array(''),
            'menu_icon' => 'dashicons-palmtree',
            'has_archive' => true,
            'rewrite' => array('slug' => $thread_slug),
        )
    );
}
add_action('init', 'tt_create_thread_post_type');

/**
 * 为论坛启用单独模板
 *
 * @since 2.6.0
 *
 * @param $template_path
 *
 * @return string
 */
function tt_include_thread_template_function($template_path)
{
    if (get_post_type() == 'thread') {
        if (is_single()) {
            //指定单个帖子模板
            if ($theme_file = locate_template(array('core/templates/thread/tpl.Thread.Post.php'))) {
                $template_path = $theme_file;
            }
        } elseif (tt_is_thread_category()) {
            //指定帖子分类模板
            if ($theme_file = locate_template(array('core/templates/thread/tpl.Thread.Category.php'))) {
                $template_path = $theme_file;
            }
        } elseif (tt_is_thread_tag()) {
            //指定帖子标签模板
            if ($theme_file = locate_template(array('core/templates/thread/tpl.Thread.Tag.php'))) {
                $template_path = $theme_file;
            }
        } elseif (is_archive()) {
            //指定帖子首页模板
            if ($theme_file = locate_template(array('core/templates/thread/tpl.Thread.Main.php'))) {
                $template_path = $theme_file;
            }
        }
    }

    return $template_path;
}
add_filter('template_include', 'tt_include_thread_template_function', 1);

/**
 * 为论坛启用分类和标签.
 *
 * @since 2.6.0
 */
function tt_create_thread_taxonomies()
{
    $thread_slug = tt_get_option('tt_thread_archives_slug', 'thread');
    // Categories
    $thread_category_labels = array(
        'name' => _x('Thread Categories', 'taxonomy general name', 'tt'),
        'singular_name' => _x('Thread Category', 'taxonomy singular name', 'tt'),
        'search_items' => __('Search Thread Categories', 'tt'),
        'all_items' => __('All Thread Categories', 'tt'),
        'parent_item' => __('Parent Thread Category', 'tt'),
        'parent_item_colon' => __('Parent Thread Category:', 'tt'),
        'edit_item' => __('Edit Thread Category', 'tt'),
        'update_item' => __('Update Thread Category', 'tt'),
        'add_new_item' => __('Add New Thread Category', 'tt'),
        'new_item_name' => __('Name of New Thread Category', 'tt'),
        'menu_name' => __('Thread Categories', 'tt'),
    );
    register_taxonomy('thread_category', 'thread', array(
        'hierarchical' => true,
        'labels' => $thread_category_labels,
        'show_ui' => true,
        'query_var' => true,
        'rewrite' => array(
            'slug' => $thread_slug.'/category',
            'with_front' => false,
        ),
    ));
    // Tags
    $thread_tag_labels = array(
        'name' => _x('Thread Tags', 'taxonomy general name', 'tt'),
        'singular_name' => _x('Thread Tag', 'taxonomy singular name', 'tt'),
        'search_items' => __('Search Thread Tags', 'tt'),
        'popular_items' => __('Popular Thread Tags', 'tt'),
        'all_items' => __('All Thread Tags', 'tt'),
        'parent_item' => null,
        'parent_item_colon' => null,
        'edit_item' => __('Edit Thread Tag', 'tt'),
        'update_item' => __('Update Thread Tag', 'tt'),
        'add_new_item' => __('Add New Thread Tag', 'tt'),
        'new_item_name' => __('Name of New Thread Tag', 'tt'),
        'separate_items_with_commas' => __('Separate Thread Tags with Commas', 'tt'),
        'add_or_remove_items' => __('Add or Remove Thread Tag', 'tt'),
        'choose_from_most_used' => __('Choose from Most Used Thread Tags', 'tt'),
        'menu_name' => __('Thread Tags', 'tt'),
    );

//    register_taxonomy('thread_tag', 'thread', array(
//        'hierarchical' => false,
//        'labels' => $thread_tag_labels,
//        'show_ui' => true,
//        'update_count_callback' => '_update_post_term_count',
//        'query_var' => true,
//        'rewrite' => array(
//            'slug' => $thread_slug.'/tag',
//            'with_front' => false,
//        ),
//    ));
}
add_action('init', 'tt_create_thread_taxonomies', 0);

/**
 * 自定义论坛的链接.
 *
 * @since 2.6.0
 *
 * @param $link
 * @param object $post
 *
 * @return string
 */
function tt_custom_thread_link($link, $post = null)
{
    $thread_slug = tt_get_option('tt_thread_archives_slug', 'thread');
    $thread_post_slug = tt_get_option('tt_thread_link_mode') == 'post_name' ? $post->post_name : $post->ID;
    if ($post->post_type == 'thread') {
        return home_url($thread_slug.'/'.$thread_post_slug.'.html');
    } else {
        return $link;
    }
}
add_filter('post_type_link', 'tt_custom_thread_link', 1, 2);

/**
 * 处理论坛自定义链接Rewrite规则.
 *
 * @since 2.6.0
 */
function tt_handle_custom_thread_rewrite_rules()
{
    $thread_slug = tt_get_option('tt_thread_archives_slug', 'thread');
    if (tt_get_option('tt_thread_link_mode') == 'post_name'):
        add_rewrite_rule(
            $thread_slug.'/([一-龥a-zA-Z0-9_-]+)?.html([\s\S]*)?$',
            'index.php?post_type=thread&name=$matches[1]',
            'top'); else:
        add_rewrite_rule(
            $thread_slug.'/([0-9]+)?.html([\s\S]*)?$',
            'index.php?post_type=thread&p=$matches[1]',
            'top');
    endif;
}
add_action('init', 'tt_handle_custom_thread_rewrite_rules');

/**
 * 后台帖子列表信息列.
 *
 * @since 2.6.0
 *
 * @param $columns
 *
 * @return array
 */
function tt_thread_post_columns($columns)
{
    $columns['thread_ID'] = __('Thread Post ID', 'tt');
//    unset($columns['comments']);
    if (isset($columns['title'])) {
        $columns['title'] = __('Thread Post Title', 'tt');
    }
    if (isset($columns['author'])) {
        $columns['author'] = __('Thread Post Publisher', 'tt');
    }
    if (isset($columns['views'])) {
        $columns['views'] = __('Hot Hits', 'tt');
    }

    $columns['comments'] = __('Thread Post Replies', 'tt');

    return $columns;
}
add_filter('manage_edit-thread_columns', 'tt_thread_post_columns');

function tt_populate_thread_post_columns($column)
{
    if ('thread_ID' == $column) {
        $thread_ID = esc_html(get_the_ID());
        echo $thread_ID;
    }
    // TODO more
}
add_action('manage_posts_custom_column', 'tt_populate_thread_post_columns');

/**
 * 后台帖子列表信息列排序.
 *
 * @param $columns
 *
 * @return mixed
 */
function tt_sort_thread_columns($columns)
{
    $columns['thread_ID'] = 'id';
    $columns['comments'] = 'comments';
    $columns['views'] = 'views';

    return $columns;
}
add_filter('manage_edit-thread_sortable_columns', 'tt_sort_thread_columns');
function tt_thread_column_orderby($vars)
{
    if (!is_admin()) {
        return $vars;
    }
    if (isset($vars['orderby']) && 'views' == $vars['orderby']) {
        $vars = array_merge($vars, array('meta_key' => 'views', 'orderby' => 'meta_value'));
    }

    return $vars;
}
add_filter('request', 'tt_thread_column_orderby');

/**
 * 后台论坛帖子列表分类筛选.
 *
 * @since 2.6.0
 */
function tt_filter_thread_posts_list()
{
    $screen = get_current_screen();
    global $wp_query;
    if ($screen->post_type == 'thread') {
        wp_dropdown_categories(array(
            'show_option_all' => __('Show all categories', 'tt'),
            'taxonomy' => 'thread_category',
            'name' => __('Thread Category'),
            'id' => 'filter-by-threads_category',
            'orderby' => 'name',
            'selected' => (isset($wp_query->query['thread_category']) ? $wp_query->query['thread_category'] : ''),
            'hierarchical' => false,
            'depth' => 3,
            'show_count' => false,
            'hide_empty' => true,
        ));
    }
}
add_action('restrict_manage_posts', 'tt_filter_thread_posts_list');
function tt_perform_thread_posts_filtering($query)
{
    $qv = &$query->query_vars;
    if (isset($qv['thread_category']) && is_numeric($qv['thread_category'])) {
        $term = get_term_by('id', $qv['thread_category'], 'thread_category');
        $qv['thread_category'] = $term->slug;
    }

    return $query;
}
add_filter('parse_query', 'tt_perform_thread_posts_filtering');

/**
 * 判断当前页面是否为帖子分类.
 *
 * @since 2.6.0
 *
 * @return bool
 */
function tt_is_thread_category()
{
    $object = get_queried_object();
    if ($object instanceof WP_Term && $object->taxonomy == 'thread_category') {
        return true;
    }

    return false;
}

/**
 * 判断当前页面是否为帖子标签.
 *
 * @since 2.6.0
 *
 * @return bool
 */
function tt_is_thread_tag()
{
    $object = get_queried_object();
    if ($object instanceof WP_Term && $object->taxonomy == 'thread_tag') {
        return true;
    }

    return false;
}
