<?php
/**
 * Copyright (c) 2016-2018, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 * @package Tint
 * @author Zhiyan
 * @date 2018/4/29 下午5:52
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 * @link https://webapproach.net/tint.html
 */

/**
 * 创建thread 服务绑定的错误.
 *
 * @param $message
 * @param int $status
 *
 * @return WP_Error
 */
function tt_create_thread_error($message, $status = 400)
{
    return new WP_Error('rest_thread_error', $message, array('status' => $status));
}

/**
 * 创建thread服务绑定的响应.
 *
 * @param $data
 * @param string $message
 * @param int    $status
 *
 * @return array
 */
function tt_create_thread_response($data, $message = '', $status = 200)
{
    return array(
        'data' => $data,
        'message' => $message,
        'code' => $status,
    );
}

function tt_exec_thread_api_services($service, $params)
{
    $func_name = 'tt_exec_thread_service_'.implode('_', explode('.', $service));
    if (!function_exists($func_name)) {
        return new WP_Error('rest_thread_service_not_implement', __('Sorry, the service is not implemented.', 'tt'), array('status' => 400));
    }

    return $func_name($params);
}


////// services //////

/**
 * 获取用户信息
 *
 * @since 2.6.0
 * @param $params
 * @return array
 */
function tt_exec_thread_service_open_user_info($params) {
    $user = wp_get_current_user();
    $data = $user->data;
    unset($data->user_pass);
    unset($data->user_activation_key);
    $info = array_merge(array(), (array)$data);
    $info['id'] = $user->ID;
    $info['avatar'] = tt_get_avatar($user->ID);
    $info['link'] = get_author_posts_url($user->ID);
    $info['roles'] = $user->roles;
    $info['cover_img'] =  tt_get_user_cover($user->ID, 'mini');
    $info['cover_img_big'] = tt_get_user_cover($user->ID, 'full');
    $info['thread_count'] = tt_count_user_thread($user->ID);
    $info['received_likes'] = tt_count_user_thread_received_likes($user->ID);

    return tt_create_thread_response($info);
}

/**
 * 获取论坛分类
 *
 * @since 2.6.0
 * @param $params
 * @return array
 */
function tt_exec_thread_service_open_category_list($params) {
    return tt_create_thread_response(tt_get_thread_categories());
}

/**
 * 获取帖子列表
 *
 * @since 2.6.0
 * @param $params
 * @return array
 */
function tt_exec_thread_service_open_thread_list($params) {
    return tt_create_thread_response(tt_get_thread_list($params['category'], $params['page']));
}

/**
 * 获取帖子详情
 *
 * @since 2.6.0
 * @param $params
 * @return array
 */
function tt_exec_thread_service_open_thread_detail($params) {
    return tt_create_thread_response(tt_get_thread_detail($params['id']));
}

/**
 * 获取帖子详情(用于编辑器)
 *
 * @since 2.6.0
 * @param $params
 * @return array
 */
function tt_exec_thread_service_open_thread_raw($params) {
    return tt_create_thread_response(tt_get_thread_detail($params['id'], true));
}

/**
 * 获取帖子回复列表
 *
 * @since 2.6.0
 * @param $params
 * @return array
 */
function tt_exec_thread_service_open_threadreply_list($params) {
    $page = $params['page'] ? intval($params['page']) : 1;
    return tt_create_thread_response(tt_get_thread_replylist($params['id'], $page));
}

/**
 * 回复帖子
 *
 * @since 2.6.0
 * @param $params
 * @return array|WP_Error
 */
function tt_exec_thread_service_open_thread_reply($params) {
    $parent = $params['parent'] ? intval($params['parent']) : 0;
    $mentions = explode(',', $params['mentions']);
    $result = tt_reply_thread(intval($params['id']), $params['content'], $params['raw'], $params['plain'], $parent, $mentions);
    if ($result instanceof WP_Error) {
        return tt_create_thread_error($result->get_error_message(), $result->get_error_code());
    }
    return tt_create_thread_response($result);
}

/**
 * 点赞或取消点赞帖子
 *
 * @since 2.6.0
 * @param $params
 * @return mixed
 */
function tt_exec_thread_service_open_thread_like($params) {
    $uid = intval($params['uid']);
    $id = intval($params['id']);

    $result = tt_toggle_thread_like($uid, $id);
    if ($result instanceof WP_Error) {
        return tt_create_thread_error($result->get_error_message(), $result->get_error_code());
    }
    return tt_create_thread_response($result);
}

/**
 * 帖子置顶或取消置顶
 *
 * @since 2.6.0
 * @param $params
 * @return array|WP_Error
 */
function tt_exec_thread_service_open_thread_sticky($params) {
    $id = intval($params['id']);
    $sticky = boolval($params['sticky']);

    $result = tt_toggle_thread_sticky($id, $sticky);
    if ($result instanceof WP_Error) {
        return tt_create_thread_error($result->get_error_message(), $result->get_error_code());
    }
    return tt_create_thread_response($result);
}

/**
 * 创建帖子
 *
 * @since 2.6.0
 * @param $params
 * @return array|WP_Error
 */
function tt_exec_thread_service_open_thread_create($params) {
    $data = array(
        'id' => 0,
        'title' => $params['title'],
        'content' => $params['content'],
        'excerpt' => $params['excerpt'],
        'raw' => $params['raw'],
        'category' => $params['category']
    );
    $result = tt_create_or_update_thread($data);

    if ($result instanceof WP_Error) {
        return tt_create_thread_error($result->get_error_message(), $result->get_error_code());
    }
    return tt_create_thread_response($result);
}

/**
 * 更新帖子
 *
 * @since 2.6.0
 * @param $params
 * @return array|WP_Error
 */
function tt_exec_thread_service_open_thread_update($params) {
    $data = array(
        'id' => $params['id'],
        'title' => $params['title'],
        'content' => $params['content'],
        'excerpt' => $params['excerpt'],
        'raw' => $params['raw'],
        'category' => $params['category']
    );
    $result = tt_create_or_update_thread($data);

    if ($result instanceof WP_Error) {
        return tt_create_thread_error($result->get_error_message(), $result->get_error_code());
    }
    return tt_create_thread_response($result);
}

/**
 * 上传帖子图片
 *
 * @since 2.6.0
 * @param $params
 */
function tt_exec_thread_service_open_image_upload($params) {
    // drop
}
