<?php
/**
 * Copyright (c) 2016-2018, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2018/4/29 下午5:33
 *
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @see https://webapproach.net/tint.html
 */

/**
 * 获取论坛分类.
 *
 * @since 2.6.0
 *
 * @return array
 */
function tt_get_thread_categories()
{
    return get_categories(array(
        'taxonomy' => 'thread_category',
        'orderby' => 'id',
        'order' => 'ASC',
        'hide_empty' => false,
    ));
}

/**
 * 组装列表帖子数据
 *
 * @since 2.6.0
 * @param $post WP_Post
 * @return array
 */
function tt_assemble_thread($post) {
    $thread = array();
    $thread['ID'] = $post->ID;
    $thread['id'] = $post->ID;
    $thread['title'] = get_the_title($post);
    $thread['permalink'] = get_permalink($post);
    $thread['comment_count'] = $post->comment_count;
    $thread['likes'] = (int) get_post_meta($post->ID, 'likes', true);
    $thread['excerpt'] = get_the_excerpt($post);
    $thread['category'] = wp_get_post_terms($post->ID, 'thread_category');
//        $author_id = get_the_author_meta('ID');
    $thread['author'] = get_the_author();
    $thread['author_id'] = $post->post_author;
    $thread['author_url'] = get_author_posts_url($post->post_author);
    $thread['author_avatar'] = tt_get_avatar($post->post_author);
    $thread['time'] = get_post_time('Y-m-d H:i', false, $post, false); //get_post_time( string $d = 'U', bool $gmt = false, int|WP_Post $post = null, bool $translate = false )
    $thread['datetime'] = get_the_time(DATE_W3C, $post);
    $thread['thumb'] = tt_get_thumb($post, 'medium');
    $thread['format'] = get_post_format($post) ?: 'standard';
    $thread['tags'] = get_the_term_list($post->ID, 'thread_tag', ' ', ' ', '');

    return $thread;
}

/**
 * 获取帖子列表.
 *
 * @since 2.6.0
 *
 * @param $category
 * @param int $page
 *
 * @return array
 */
function tt_get_thread_list($category, $page = 1)
{
    $uid = get_current_user_id();
    $liked_threads = $uid ? get_user_meta($uid, 'tt_like_thread', false) : array();
    $sticky_thread_ids = explode(',', get_option('tt_sticky_threads'));

    $pages = 1;
    // 先查询置顶的帖子
    $sticky_threads = array();
    if (count($sticky_thread_ids) > 0 && $page == 1) {
        $args = array(
            'post_type' => 'thread',
            'post_status' => 'publish',
            'posts_per_page' => 100,
            'paged' => 1,
            'has_password' => false,
            'ignore_sticky_posts' => true,
            'post__in' => $sticky_thread_ids,
            'orderby' => 'modified', // date // modified - 如果按最新编辑时间排序
            'order' => 'DESC',
        );

        if (!empty($category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'thread_category',
                    'field'    => 'slug',
                    'terms'    => array( $category )
                )
            );
        }

        $query = new WP_Query($args);
        $GLOBALS['wp_query'] = $query;

        while ($query->have_posts()) : $query->the_post();
            global $post;
            $thread = tt_assemble_thread($post);
            $thread['is_sticky'] = true;
            $thread['liked'] = in_array(strval($post->ID), $liked_threads);
            $sticky_threads[] = $thread;
        endwhile;

        wp_reset_postdata();
    }

    // 查询非置顶帖子
    $threads = array();
    if (count($sticky_threads) < 20) {
        $args = array(
            'post_type' => 'thread',
            'post_status' => 'publish',
            'posts_per_page' => 20,
            'paged' => $page,
            'has_password' => false,
            'ignore_sticky_posts' => true,
            'post__not_in' => $sticky_thread_ids,
            'orderby' => 'modified', // date // modified - 如果按最新编辑时间排序
            'order' => 'DESC',
        );

        if (!empty($category)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'thread_category',
                    'field'    => 'slug',
                    'terms'    => array( $category )
                )
            );
        }

        $query = new WP_Query($args);
        $GLOBALS['wp_query'] = $query;

        $pages = $query->max_num_pages;

        while ($query->have_posts()) : $query->the_post();
            global $post;
            $thread = tt_assemble_thread($post);
            $thread['is_sticky'] = in_array($post->ID, $sticky_thread_ids);
            $thread['liked'] = in_array(strval($post->ID), $liked_threads);
            $threads[] = $thread;
        endwhile;

        wp_reset_postdata();
    }

    return array(
        'pages' => $pages,
        'threads' => array_merge($sticky_threads, $threads),
    );
}

/**
 * 获取帖子详情.
 *
 * @since 2.6.0
 *
 * @param $id
 * @param $raw
 * @return array
 */
function tt_get_thread_detail($id, $raw = false)
{
    $uid = get_current_user_id();

    $query = new WP_Query(array(
        'p' => $id,
        'post_type' => 'thread',
        'post_status' => 'publish',
        //'category__not_in' => $featured_catIds,
        'has_password' => false,
        'ignore_sticky_posts' => true,
    //        'post__not_in' => get_option('sticky_posts'),
        'orderby' => 'modified', // date // modified - 如果按最新编辑时间排序
        'order' => 'DESC',
    ));

    $thread = null;

    while ($query->have_posts()) : $query->the_post();
    global $post;
    $thread['id'] = $post->ID;
    $thread['title'] = get_the_title($post);
    $thread['permalink'] = get_permalink($post);
    $thread['category'] = wp_get_post_terms($post->ID, 'thread_category');
//        $author_id = get_the_author_meta('ID');
    $thread['author'] = get_the_author();
    $thread['author_id'] = $post->post_author;
    if (!$raw) {
        $sticky_list = explode(',', get_option('tt_sticky_threads'));

        $thread['comment_count'] = $post->comment_count;
        $thread['likes'] = (int) get_post_meta($post->ID, 'likes', true);
        $thread['liked'] = $uid && tt_thread_liked_by_user($post->ID, $uid);
        $thread['excerpt'] = get_the_excerpt($post);
        $thread['content'] = $post->post_content;
        $thread['author_url'] = get_author_posts_url($post->post_author);
        $thread['author_avatar'] = tt_get_avatar($post->post_author);
        $thread['time'] = get_post_time('Y-m-d H:i', false, $post, false); //get_post_time( string $d = 'U', bool $gmt = false, int|WP_Post $post = null, bool $translate = false )
        $thread['datetime'] = get_the_time(DATE_W3C, $post);
        $thread['thumb'] = tt_get_thumb($post, 'medium');
        $thread['format'] = get_post_format($post) ?: 'standard';
        $thread['is_sticky'] = in_array($post->ID, $sticky_list);
//    $thread['tags'] = get_the_term_list($post->ID, 'thread_tag', ' ', ' ', '');
        $thread['floor_no'] = 1;
        $thread['is_master'] = true;
        $thread['author_thread_count'] = tt_count_user_thread($post->post_author);
        $thread['author_received_likes'] = tt_count_user_thread_received_likes($post->post_author);
    } else {
        $thread['excerpt'] = $post->post_excerpt;
        $thread['raw'] = get_post_meta($post->ID, 'tt_thread_raw', true);
    }
    endwhile;

    wp_reset_postdata();

    return $thread;
}


/**
 * 获取指定帖子的回复总数
 * @param $id
 * @return int
 */
function tt_get_thread_relpy_count($id) {
    global $wpdb;

    $count = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments WHERE comment_post_ID=$id AND comment_approved='1'");
    return intval($count);
}


/**
 * 获取帖子回复
 *
 * @since 2.6.0
 * @param $id
 * @param int $page
 * @return array
 */
function tt_get_thread_replylist($id, $page = 1) {
    $the_comments = get_comments(array(
        'status' => 'approve',
        'type' => 'comment', // 'pings' (includes 'pingback' and 'trackback'),
        'post_id'=> $id,
        //'meta_key' => 'tt_sticky_comment',
        'orderby' => 'comment_date', //meta_value_num
        'order' => 'ASC',
        'number' => 20,
        'offset' => ($page - 1) * 20
    ));

    $total = tt_get_thread_relpy_count( $id );
    $pages = ceil($total / 20);

    $replies = array();
    $users = array();

    foreach ($the_comments as $index => $the_comment) {
        $reply = array();
        $uid = intval($the_comment->user_id);
        if (!array_key_exists($uid, $users)) {
            $user = get_user_by('id', $uid);
            $author = array(
                'author_avatar' => tt_get_avatar($uid),
                'author' => $user->data->display_name,
                'author_id' => $uid,
                'author_url' => get_author_posts_url($uid),
                'author_email' => $user->data->user_email,
                'author_thread_count' => tt_count_user_thread($uid),
                'author_received_likes' => tt_count_user_thread_received_likes($uid)
            );
            $users[$uid] = $author;
        }
        $reply['id'] = intval($the_comment->comment_ID);
        $reply['agent'] = $the_comment->comment_agent;
        $reply['approved'] = !!intval($the_comment->comment_approved);
        $reply['parent'] = intval($the_comment->comment_parent);
        $reply['thread_id'] = intval($the_comment->comment_post_ID);
        $reply['time'] = $the_comment->comment_date;
        $reply['content'] = $the_comment->comment_content;
        $reply['ip'] = $the_comment->comment_author_IP;
        $reply['floor_no'] = 1 + ($page - 1) * 20 + $index + 1;
        $reply['is_master'] = false;
        $reply = array_merge(array(), $reply, $users[$uid]);
        array_push($replies, $reply);
    }

    return array(
        'pages' => $pages,
        'replies' => $replies
    );
}


/**
 * 创建帖子回复
 *
 * @since 2.6.0
 * @param $id
 * @param $content
 * @param int $parent
 * @return string|WP_Error
 */
function tt_reply_thread($id, $content, $raw, $plain, $parent = 0, $mentions = array()) {
    $comment_post_ID = absint($id);
    $user = wp_get_current_user();

    $post_type = 'thread';

    if($comment_post_ID <= 0 || !comments_open($comment_post_ID)) {
        return new WP_Error(400, __('Comment closed for the thread', 'tt'));
    }
    if(get_post_status($comment_post_ID) != 'publish') {
        return new WP_Error(400, __('Cannot comment a unpublished thread', 'tt'));
    }
    if(post_password_required($comment_post_ID)) {
        return new WP_Error(400, __('Cannot comment a password protected thread', 'tt'));
    }

    if (empty($content)) {
        return new WP_Error(400, __('Cannot comment with empty text', 'tt'));
    }
//    do_action('pre_comment_on_post', $comment_post_ID);

    $comment_content = trim( $content );
    $comment_type = '';
//    $ksesNonce = trim( $_POST['ksesNonce'] );
    $comment_parent = absint($parent);
    $comment_author = $user->user_login;
    $comment_author_email = $user->user_email;
    $comment_author_url = get_author_posts_url($user->ID);
    $user_ID = $user->ID;

    $commentdata = compact('comment_post_ID', 'comment_author', 'comment_author_email', 'comment_author_url', 'comment_content', 'comment_type', 'comment_parent', 'user_ID');

    $comment_id = wp_new_comment( $commentdata );

    if(!$comment_id) {
        return new WP_Error(400, __('Add comment failed', 'tt'));
    }

    // raw data saved to comment meta
    add_comment_meta($comment_id, 'tt_thread_comment_raw', $raw);

    $thread = null;
    $comment_link = home_url(tt_get_option('tt_thread_archives_slug', 'thread') . '/' . $comment_post_ID . '.html');
    $mail_send = 0;

    foreach ($mentions as $mention) {
        $mention_id = intval($mention);
        if ($mention_id == $user->ID) {
            continue;
        }
        $mention_user = get_user_by('ID', $mention_id);
        if ($mention_user) {
            if (!$thread) {
                $thread = get_post($comment_post_ID);
            }
            $args = array(
                'postTitle' => $thread->post_title,
                'commentAuthor' => $comment_author,
                'commentContent' => $plain,
                'commentLink' => $comment_link
            );
            if ($mail_send == 0) {
                tt_async_mail('', $mention_user->user_email, sprintf(__('%1$s在帖子『%2$s』中@了你', 'tt'), $user->display_name, $thread->post_title), $args, 'thread-at');
            } else {
                tt_mail('', $mention_user->user_email, sprintf(__('%1$s在帖子『%2$s』中@了你', 'tt'), $user->display_name, $thread->post_title), $args, 'thread-at');
            }
            $mail_send++;
        }
    }

//    $comment = get_comment($comment_id);
//    $comment_html = wp_list_comments(array(
//        'type'=>'all',
//        'callback'=>'tt_comment',
//        'end-callback'=>'tt_end_comment',
//        'max_depth'=>3,
//        'reverse_top_level'=>0,
//        'style'=>'div',
//        'page'=>1,
//        'per_page'=>1,
//        'echo'=>false
//    ), array($comment));
    return $comment_id;
}

/**
 * 统计用户发帖数量
 *
 * @since 2.6.0
 * @param $uid
 * @return string
 */
function tt_count_user_thread($uid) {
    return count_user_posts($uid, 'thread');
}

/**
 * 统计用户发布的帖子收到的点赞数量
 *
 * @param $uid
 * @return int
 */
function tt_count_user_thread_received_likes($uid) {
    // author_received_likes
    global $wpdb;
    $post_ids = $wpdb->get_results("SELECT ID FROM $wpdb->posts WHERE post_author=$uid AND post_type='thread' AND post_status='publish'");
    $ids_str = implode(',', array_map(function($item){
        return $item->ID;
    }, $post_ids));

    $likes = $wpdb->get_results(" SELECT sum(meta_value) as count FROM $wpdb->postmeta WHERE meta_key='likes' AND post_id in ($ids_str)");

    return intval($likes[0]->count);
}

/**
 * 判断用户是否点赞过帖子
 *
 * @since 2.6.0
 * @param $pid
 * @param $uid
 * @return bool
 */
function tt_thread_liked_by_user($pid, $uid) {
    $like_threads = get_user_meta($uid, 'tt_like_thread', false);
    return in_array(strval($pid), $like_threads);
}

/**
 * 帖子点赞
 *
 * @since 2.6.0
 * @param $uid
 * @param $pid
 * @return bool|WP_Error
 */
function tt_toggle_thread_like($uid, $pid) {
    // 判断是否已经点赞过
    if (tt_thread_liked_by_user($pid, $uid)) {
        $result = delete_user_meta($uid, 'tt_like_thread', strval($pid));
        if (!$result) {
            return new WP_Error(400, __('Cancel thread like failed', 'tt'));
        }
        $thread_likes = (int)get_post_meta($pid, 'likes', true);
        update_post_meta($pid, 'likes', max(0, intval($thread_likes) - 1));
        return false;
    } else {
        $result = add_user_meta($uid, 'tt_like_thread', strval($pid));
        if (!$result) {
            return new WP_Error(400, __('Mark thread like failed', 'tt'));
        }
        $thread_likes = (int)get_post_meta($pid, 'likes', true);
        update_post_meta($pid, 'likes',intval($thread_likes) + 1);
        return true;
    }
}

/**
 * 创建或更新帖子
 *
 * @since 2.6.0
 * @param $data array
 * @return array|WP_Error
 */
function tt_create_or_update_thread($data) {
    $title = sanitize_text_field(trim($data['title']));
    if(strlen($title) < 10) {
        return new WP_Error(400, __('The thread title is too short or empty', 'tt'));
    }

    $content = trim($data['content']);
    $raw = trim($data['raw']);
    $excerpt = trim($data['excerpt']);
    if(strlen($excerpt) < absint(20)) {
        return new WP_Error(400, __('The thread content is too short or empty', 'tt'));
    }

    $cat = sanitize_text_field(trim($data['category']));

    $action = 'publish';

    $id = (int)sanitize_text_field(trim($data['id']));
    $uid = get_current_user_id();

    if ($id) {
        // 更新文章先校验权限
        $author = intval(get_post_field('post_author', $id));
        if ($author !== $uid && !current_user_can('administrator')) {
            return new WP_Error(403, __('You have no permission to update this thread', 'tt'));
        }

        $result = wp_update_post( array( //Return: The ID of the post if the post is successfully updated in the database. Otherwise returns 0
            'post_type'     => 'thread',
            'ID'            => $id,
            'post_title'    => $title,
            'post_excerpt'  => $excerpt,
            'post_content'  => $content,
            'post_status'   => $action
//            'post_author'   => $author,
//            'thread_category' => $cat
        ), true );

        if ($result && !$result instanceof WP_Error) {
            wp_set_object_terms($id, $cat, 'thread_category');
            // 标记thread最后由谁更新
            $data = array(
              'by' => $uid,
              'time' => time()
            );
            update_post_meta($id, 'tt_thread_last_modified', json_encode($data));
            if (update_post_meta($id, 'tt_thread_raw', $raw)) {
                return $result;
            }

            return new WP_Error(400, __('Update thread failed', 'tt'));
        }

        return $result;
    } else {
        // 插入帖子
        $new_post = wp_insert_post( array(
            'post_type'     => 'thread',
            'post_title'    => $title,
            'post_excerpt'  => $excerpt,
            'post_content'  => $content,
            'post_status'   => $action,
            'post_author'   => $uid,
//            'thread_category' => array($cat)
        ) );

        if ($new_post && !$new_post instanceof WP_Error) {
            wp_set_object_terms($new_post, $cat, 'thread_category');
            if (add_post_meta($new_post, 'tt_thread_raw', $raw, true)) {
                return $new_post;
            }
        }

        return new WP_Error(400, __('Create thread failed', 'tt'));
    }
}


/**
 * 帖子置顶或取消置顶
 * @param $id
 * @param $sticky
 * @return WP_Error|boolean
 */
function tt_toggle_thread_sticky($id, $sticky) {
    if (!current_user_can('administrator') && !current_user_can('editor')) {
        return new WP_Error(403, __('You have no permission to do this', 'tt'));
    }
    $thread = get_post($id);
    if (!$thread) {
        return new WP_Error(404, __('The thread is not exist', 'tt'));
    } else if ($thread->post_type !== 'thread') {
        return new WP_Error(400, __('Invalid thread id', 'tt'));
    }

    $stickies = explode(',', get_option('tt_sticky_threads'));
    if ($sticky) {
        array_push($stickies, $id);
    } else {
        if (($key = array_search(strval($id), $stickies)) !== false) {
            unset($stickies[$key]);
        }
    }
    $stickies = array_unique($stickies);
    $result = update_option('tt_sticky_threads', implode(',', $stickies));
    return $result;
}