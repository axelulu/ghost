<?php

/**
 * 校验用户发送消息的额度.
 *
 * @since 2.7.0
 *
 * @param $uid
 *
 * @return bool|WP_Error
 */
function tt_check_user_message_limit($uid)
{
    if (user_can($uid, 'administrator')) {
        return true;
    }

    $now = date('Ymd');
    $record = get_user_meta($uid, 'tt_last_pm', true);
    if (!$record) {
        add_user_meta($uid, 'tt_last_pm', json_encode(array('count' => 1, 'time' => time(), 'day' => $now)), true);

        return true;
    }

    $info = json_decode($record);

    if (time() - intval($info->time) < 5 * 60) {
//        return new WP_Error(400, __('消息发送过于频繁', 'tt'));
        return false;
    } elseif (intval($info->count) >= 10 && $info->day == $now) {
//        return new WP_Error(400, __('消息发送额度已耗尽', 'tt'));
        return false;
    }

    $new_count = $info->day == $now ? $info->count + 1 : 1;

    update_user_meta($uid, 'tt_last_pm', json_encode(array('count' => $new_count, 'time' => time(), 'day' => $now)));

    return true;
}

/**
 * 创建消息.
 *
 *
 * @since 2.0.0
 *
 * @param int    $user_id   接收用户ID
 * @param int    $sender_id 发送者ID(可空)
 * @param string $sender    发送者
 * @param string $type      消息类型(notification/chat/credit)
 * @param string $title     消息标题
 * @param string $content   消息内容
 * @param int    $read      (已读/未读)
 * @param string $status    消息状态(publish/trash)
 * @param string $date      消息时间
 *
 * @return bool
 */
function tt_create_message($user_id = 0, $sender_id = 0, $sender, $type = '', $title = '', $content = '', $read = MsgReadStatus::UNREAD, $status = 'publish', $date = '')
{
    $user_id = absint($user_id);
    $sender_id = absint($sender_id);
    $title = sanitize_text_field($title);

    if (!$user_id || empty($title)) {
        return false;
    }

    $type = $type ? sanitize_text_field($type) : 'chat';
    $date = $date ? $date : current_time('mysql');
    $content = htmlspecialchars($content);

    global $wpdb;
    $table_name = $wpdb->prefix.'tt_messages';

    if ($wpdb->query($wpdb->prepare("INSERT INTO $table_name (user_id, sender_id, sender, msg_type, msg_title, msg_content, msg_read, msg_status, msg_date) VALUES (%d, %d, %s, %s, %s, %s, %d, %s, %s)", $user_id, $sender_id, $sender, $type, $title, $content, $read, $status, $date))) {
        return true;
    }

    return false;
}

/**
 * 创建一条私信
 *
 * @param $receiver_id
 * @param $sender
 * @param $text
 * @param $send_mail
 *
 * @return bool
 */
function tt_create_pm($receiver_id, $sender, $text, $send_mail = false)
{
    // 清理未读消息统计数的缓存
    if (wp_using_ext_object_cache()) {
        $key = 'tt_user_'.$receiver_id.'_unread';
        wp_cache_delete($key);
    }

    if ($sender instanceof WP_User && $sender->ID) {
        if (!tt_check_user_message_limit($sender->ID)) {
            return false;
        }
        if ($send_mail && $sender->user_email) {
            $subject = sprintf(__('%1$s向你发送了一条消息 - %2$s', 'tt'), $sender->display_name, get_bloginfo('name'));
            $args = array(
                'senderName' => $sender->display_name,
                'message' => $text,
                'chatLink' => tt_url_for('uc_chat', $sender),
            );
            //tt_async_mail('', get_user_by('id', $receiver_id)->user_email, $subject, $args, 'pm');
            tt_mail('', get_user_by('id', $receiver_id)->user_email, $subject, $args, 'pm');
        }

        return tt_create_message($receiver_id, $sender->ID, $sender->display_name, 'chat', $text);
    } elseif (is_int($sender)) {
        $sender = get_user_by('ID', $sender);
        if (!tt_check_user_message_limit($sender->ID)) {
            return false;
        }
        if ($send_mail && $sender->user_email) {
            $subject = sprintf(__('%1$s向你发送了一条消息 - %2$s', 'tt'), $sender->display_name, get_bloginfo('name'));
            $args = array(
                'senderName' => $sender->display_name,
                'message' => $text,
                'chatLink' => tt_url_for('uc_chat', $sender),
            );
            //tt_async_mail('', get_user_by('id', $receiver_id)->user_email, $subject, $args, 'pm');
            tt_mail('', get_user_by('id', $receiver_id)->user_email, $subject, $args, 'pm');
        }

        return tt_create_message($receiver_id, $sender->ID, $sender->display_name, 'chat', $text);
    }

    return false;
}

/**
 * 标记消息阅读状态
 *
 * @since 2.0.0
 *
 * @param $id
 * @param int $read
 *
 * @return bool
 */
function tt_mark_message($id, $read = MsgReadStatus::READ)
{
    $id = absint($id);
    $user_id = get_current_user_id(); //确保只能标记自己的消息

    if ((!$id || !$user_id)) {
        return false;
    }

    $read = $read == MsgReadStatus::UNREAD ?: MsgReadStatus::READ;

    global $wpdb;
    $table_name = $wpdb->prefix.'tt_messages';

    if ($wpdb->query($wpdb->prepare("UPDATE $table_name SET `msg_read` = %d WHERE `msg_id` = %d AND `user_id` = %d", $read, $id, $user_id))) {
        // 清理未读消息统计数的缓存
        if (wp_using_ext_object_cache()) {
            $key = 'tt_user_'.$user_id.'_unread';
            wp_cache_delete($key);
        }

        return true;
    }

    return false;
}

/**
 * 标记所有未读消息已读.
 *
 * @since 2.0.0
 *
 * @return bool
 */
function tt_mark_all_message_read()
{
    $user_id = get_current_user_id();
    if (!$user_id) {
        return false;
    }

    global $wpdb;
    $table_name = $wpdb->prefix.'tt_messages';

    if ($wpdb->query($wpdb->prepare("UPDATE $table_name SET `msg_read` = 1 WHERE `user_id` = %d AND `msg_read` = 0", $user_id))) {
        // 清理未读消息统计数的缓存
        if (wp_using_ext_object_cache()) {
            $key = 'tt_user_'.$user_id.'_unread';
            wp_cache_delete($key);
        }

        return true;
    }

    return false;
}

/**
 * 获取单条消息.
 *
 * @since 2.0.0
 *
 * @param $msg_id
 *
 * @return bool|object
 */
function tt_get_message($msg_id)
{
    $user_id = get_current_user_id();
    if (!$user_id) {
        return false;
    } // 用于防止获取其他用户的消息

    global $wpdb;
    $table_name = $wpdb->prefix.'tt_messages';

    $row = $wpdb->get_row(sprintf("SELECT * FROM $table_name WHERE `msg_id`=%d AND `user_id`=%d OR `sender_id`=%d", $msg_id, $user_id, $user_id));
    if ($row) {
        return $row;
    }

    return false;
}

/**
 * 查询消息.
 *
 * @since 2.0.0
 *
 * @param string $type       (notification/chat/credit)
 * @param int    $limit
 * @param int    $offset
 * @param int    $read
 * @param string $msg_status
 * @param int    $sender_id
 * @param bool   $count
 *
 * @return array|bool|null|object|int
 */
function tt_get_messages($type = 'chat', $limit = 20, $offset = 0, $read = MsgReadStatus::UNREAD, $msg_status = 'publish', $sender_id = 0, $count = false)
{
    $user_id = get_current_user_id();

    if (!$user_id) {
        return false;
    }

    if (is_array($type)) {
        $type = implode("','", $type); //NOTE  IN('comment','star','update','notification') IN表达式的引号
    }
    if (!in_array($read, array(MsgReadStatus::READ, MsgReadStatus::UNREAD, MsgReadStatus::ALL))) {
        $read = MsgReadStatus::UNREAD;
    }
    if (!in_array($msg_status, array('publish', 'trash', 'all'))) {
        $msg_status = 'publish';
    }

    global $wpdb;
    $table_name = $wpdb->prefix.'tt_messages';

    $sql = sprintf("SELECT %s FROM $table_name WHERE `user_id`=%d%s AND `msg_type` IN('$type')%s%s ORDER BY (CASE WHEN `msg_read`='all' THEN 1 ELSE 0 END) DESC, `msg_date` DESC%s", $count ? 'COUNT(*)' : '*', $user_id, $sender_id ? " AND `sender_id`=$sender_id" : '', $read != MsgReadStatus::ALL ? " AND `msg_read`=$read" : '', $msg_status != 'all' ? " AND `msg_status`='$msg_status'" : '', $count ? '' : " LIMIT $offset, $limit");

    $results = $count ? $wpdb->get_var($sql) : $wpdb->get_results($sql);
    if ($results) {
        return $results;
    }

    return 0;
}

/**
 * 指定类型消息计数.
 *
 * @since 2.0.0
 *
 * @param string $type
 * @param int    $read
 * @param string $msg_status
 * @param int    $sender_id
 *
 * @return array|bool|int|null|object
 */
function tt_count_messages($type = 'chat', $read = MsgReadStatus::UNREAD, $msg_status = 'publish', $sender_id = 0)
{
    return tt_get_messages($type, 0, 0, $read, $msg_status, $sender_id, true);
}

/**
 * 获取未读消息.
 *
 * @since 2.0.0
 *
 * @param string $type
 * @param int    $limit
 * @param int    $offset
 * @param string $msg_status
 *
 * @return array|bool|int|null|object
 */
function tt_get_unread_messages($type = 'chat', $limit = 20, $offset = 0, $msg_status = 'publish')
{
    return tt_get_messages($type, $limit, $offset, MsgReadStatus::UNREAD, $msg_status);
}

/**
 * 未读消息计数.
 *
 * @since 2.0.0
 *
 * @param string $type
 * @param string $msg_status
 *
 * @return array|bool|int|null|object
 */
function tt_count_unread_messages($type = 'chat', $msg_status = 'publish')
{
    return tt_count_messages($type, MsgReadStatus::UNREAD, $msg_status);
}

/**
 * 获取积分消息.
 *
 *
 * @since 2.0.0
 *
 * @param int    $limit
 * @param int    $offset
 * @param string $msg_status
 *
 * @return array|bool|int|null|object
 */
function tt_get_credit_messages($limit = 20, $offset = 0, $msg_status = 'all')
{ //TODO: 积分消息不应该有msg_status，不可删除
    $messages = tt_get_messages('credit', $limit, $offset, MsgReadStatus::ALL, $msg_status); //NOTE: 积分消息不分已读未读
    return $messages ? $messages : array();
}

/**
 * 获取现金余额变动消息.
 *
 *
 * @since 2.2.0
 *
 * @param int    $limit
 * @param int    $offset
 * @param string $msg_status
 *
 * @return array|bool|int|null|object
 */
function tt_get_cash_messages($limit = 20, $offset = 0, $msg_status = 'all')
{ //TODO: 余额消息不应该有msg_status，不可删除
    $messages = tt_get_messages('cash', $limit, $offset, MsgReadStatus::ALL, $msg_status); //NOTE: 余额消息不分已读未读
    return $messages ? $messages : array();
}

/**
 * 积分消息计数.
 *
 * @since 2.0.0
 *
 * @return array|bool|int|null|object
 */
function tt_count_credit_messages()
{
    return tt_count_messages('credit', MsgReadStatus::ALL, 'all');
}

/**
 * 现金余额相关消息计数.
 *
 * @since 2.2.0
 *
 * @return array|bool|int|null|object
 */
function tt_count_cash_messages()
{
    return tt_count_messages('cash', MsgReadStatus::ALL, 'all');
}

/**
 * 获取收到的对话消息.
 *
 * @since 2.0.0
 *
 * @param $sender_id
 * @param int $limit
 * @param int $offset
 * @param int $read
 *
 * @return array|bool|int|null|object
 */
function tt_get_pm($sender_id = 0, $limit = 20, $offset = 0, $read = MsgReadStatus::UNREAD)
{
    return tt_get_messages('chat', $limit, $offset, $read, 'publish', $sender_id);
}

/**
 * 获取来自指定发送者的聊天消息数量(sender_id为0时不指定发送者).
 *
 * @param int $sender_id
 * @param int $read
 *
 * @return int
 */
function tt_count_pm($sender_id = 0, $read = MsgReadStatus::UNREAD)
{
    return tt_count_messages('chat', $read, 'publish', $sender_id);
}

function tt_count_pm_cached($user_id = 0, $sender_id = 0, $read = MsgReadStatus::UNREAD)
{
    if (wp_using_ext_object_cache()) {
        $user_id = $user_id ?: get_current_user_id();
        $key = 'tt_user_'.$user_id.'_unread';
        $cache = wp_cache_get($key);
        if ($cache !== false) {
            return (int) $cache;
        }
        $unread = tt_count_pm($sender_id, $read);
        wp_cache_add($key, $unread, '', 3600);

        return $unread;
    }

    return tt_count_pm($sender_id, $read);
}

/**
 * 获取我发送的消息($to_user为0时不指定收件人).
 *
 * @since 2.0.0
 *
 * @param int        $to_user
 * @param int        $limit
 * @param int        $offset
 * @param int|string $read
 * @param string     $msg_status
 * @param bool       $count
 *
 * @return array|bool|int|null|object|string
 */
function tt_get_sent_pm($to_user = 0, $limit = 20, $offset = 0, $read = MsgReadStatus::ALL, $msg_status = 'publish', $count = false)
{
    $sender_id = get_current_user_id();

    if (!$sender_id) {
        return false;
    }

    $type = 'chat';
    if (!in_array($read, array(MsgReadStatus::UNREAD, MsgReadStatus::READ, MsgReadStatus::UNREAD))) {
        $read = MsgReadStatus::ALL;
    }
    if (!in_array($msg_status, array('publish', 'trash', 'all'))) {
        $msg_status = 'publish';
    }

    global $wpdb;
    $table_name = $wpdb->prefix.'tt_messages';

    $sql = sprintf("SELECT %s FROM $table_name WHERE `sender_id`=%d%s AND `msg_type` IN('$type')%s%s ORDER BY (CASE WHEN `msg_read`='all' THEN 1 ELSE 0 END) DESC, `msg_date` DESC%s", $count ? 'COUNT(*)' : '*', $sender_id, $to_user ? " AND `user_id`=$to_user" : '', $read != MsgReadStatus::ALL ? " AND `msg_read`='$read'" : '', $msg_status != 'all' ? " AND `msg_status`='$msg_status'" : '', $count ? '' : " LIMIT $offset, $limit");

    $results = $count ? $wpdb->get_var($sql) : $wpdb->get_results($sql);
    if ($results) {
        return $results;
    }

    return 0;
}

/**
 * 获取我发送的消息数量.
 *
 * @since 2.0.0
 *
 * @param int $to_user
 * @param int $read
 *
 * @return int
 */
function tt_count_sent_pm($to_user = 0, $read = MsgReadStatus::ALL)
{
    return tt_get_sent_pm($to_user, 0, 0, $read, 'publish', true);
}

/**
 * 删除消息.
 *
 * @since 2.0.0
 *
 * @param $msg_id
 *
 * @return bool
 */
function tt_trash_message($msg_id)
{
    $user_id = get_current_user_id();
    if (!$user_id) {
        return false;
    }

    global $wpdb;
    $table_name = $wpdb->prefix.'tt_messages';

    if ($wpdb->query($wpdb->prepare("UPDATE $table_name SET `msg_status` = 'trash' WHERE `msg_id` = %d AND `user_id` = %d", $msg_id, $user_id)) || $wpdb->query($wpdb->prepare("UPDATE $table_name SET `msg_status` = 'trash' WHERE `msg_id` = %d AND `sender_id` = %d", $msg_id, $user_id))) { //TODO optimize
        return true;
    }

    return false;
}

/**
 * 恢复消息.
 *
 * @since 2.0.0
 *
 * @param $msg_id
 *
 * @return bool
 */
function tt_restore_message($msg_id)
{ //NOTE: 应该不用
    $user_id = get_current_user_id();
    if (!$user_id) {
        return false;
    }

    global $wpdb;
    $table_name = $wpdb->prefix.'tt_messages';

    if ($wpdb->query($wpdb->prepare("UPDATE $table_name SET `msg_status` = 'publish' WHERE `msg_id` = %d AND `user_id` = %d", $msg_id, $user_id))) {
        return true;
    }

    return false;
}

/**
 * 获取对话(双向消息).
 *
 * @since 2.0.0
 *
 * @param $one_uid
 * @param int    $limit
 * @param int    $offset
 * @param int    $read
 * @param string $msg_status
 * @param bool   $count
 *
 * @return array|bool|int|null|object|string
 */
function tt_get_bothway_chat($one_uid, $limit = 20, $offset = 0, $read = MsgReadStatus::UNREAD, $msg_status = 'publish', $count = false)
{
    $user_id = get_current_user_id();

    if (!$user_id) {
        return false;
    }

    if (!in_array($read, array(MsgReadStatus::UNREAD, MsgReadStatus::READ, MsgReadStatus::ALL))) {
        $read = MsgReadStatus::UNREAD;
    }
    if (!in_array($msg_status, array('publish', 'trash', 'all'))) {
        $msg_status = 'publish';
    }

    global $wpdb;
    $table_name = $wpdb->prefix.'tt_messages';
    $concat_id_str = '\''.$one_uid.'_'.$user_id.'\','.'\''.$user_id.'_'.$one_uid.'\'';

    $sql = sprintf("SELECT %s FROM $table_name WHERE CONCAT_WS('_', `user_id`, `sender_id`) IN (%s) AND `msg_type`='chat'%s%s ORDER BY (CASE WHEN `msg_read`='all' THEN 1 ELSE 0 END) DESC, `msg_date` DESC%s", $count ? 'COUNT(*)' : '*', $concat_id_str, $read != MsgReadStatus::ALL ? " AND `msg_read`='$read'" : '', $msg_status != 'all' ? " AND `msg_status`='$msg_status'" : '', $count ? '' : " LIMIT $offset, $limit");
    $results = $count ? $wpdb->get_var($sql) : $wpdb->get_results($sql);

    if ($results) {
        return $results;
    }

    return 0;
}
