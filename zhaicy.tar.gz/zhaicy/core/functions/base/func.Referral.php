<?php

/**
 * 捕获链接中的推广者.
 *
 * @since 2.0.0
 */
function tt_retrieve_referral_keyword()
{
    if (isset($_REQUEST['ref'])) {
        $ref = absint($_REQUEST['ref']);
        do_action('tt_ref', $ref);
    }
}
//add_action('template_redirect', 'tt_retrieve_referral_keyword');

function tt_handle_ref($ref)
{
    //TODO
}
//add_action('tt_ref', 'tt_handle_ref', 10, 1);
