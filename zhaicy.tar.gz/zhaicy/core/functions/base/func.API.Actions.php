<?php

/**
 * 执行向API发送的action.
 *
 * @since 2.0.0
 *
 * @param $action
 *
 * @return WP_Error|WP_REST_Response
 */
function tt_exec_api_actions($action)
{
    switch ($action) {
        case 'daily_sign':
            $result = tt_daily_sign();
            if ($result instanceof WP_Error) {
                return $result;
            }
            if ($result) {
                return tt_api_success(sprintf(__('Daily sign successfully and gain %d credits', 'tt'), (int) tt_get_option('tt_daily_sign_credits', 10)));
            }
            break;
        case 'credits_charge':
            $charge_order = tt_create_credit_charge_order(get_current_user_id(), intval($_POST['amount']));
            if (!$charge_order) {
                return tt_api_fail(__('Create credits charge order failed', 'tt'));
            } elseif (is_array($charge_order) && isset($charge_order['order_id'])) {
                // $pay_method = tt_get_cash_pay_method();
                // switch ($pay_method){
                //     case 'alipay':
                //         return tt_api_success('', array('data' => array( // 返回payment gateway url
                //             'orderId' => $charge_order['order_id'],
                //             'url' => tt_get_alipay_gateway($charge_order['order_id'])
                //         )));
                //     default: //qrcode
                //         return tt_api_success('', array('data' => array( // 直接返回扫码支付url,后面手动修改订单
                //             'orderId' => $charge_order['order_id'],
                //             'url' => tt_get_qrpay_gateway($charge_order['order_id'])
                //         )));
                // }
                $checkout_nonce = wp_create_nonce('checkout');
                $checkout_url = add_query_arg(array('oid' => $charge_order['order_id'], 'spm' => $checkout_nonce), tt_url_for('checkout'));
                $charge_order['url'] = $checkout_url;

                return tt_api_success(__('Create order successfully', 'tt'), array('data' => $charge_order));
            }
            break;
        case 'add_credits':
            $user_id = absint($_POST['uid']);
            $amount = absint($_POST['num']);
            $result = tt_update_user_credit($user_id, $amount, '', true);
            if ($result) {
                return tt_api_success(__('Update user credits successfully', 'tt'));
            }

            return tt_api_fail(__('Update user credits failed', 'tt'));
        case 'add_cash':
            $user_id = absint($_POST['uid']);
            $amount = absint($_POST['num']);
            $result = tt_update_user_cash($user_id, $amount, '', true);
            if ($result) {
                return tt_api_success(__('Update user cash successfully', 'tt'));
            }

            return tt_api_fail(__('Update user cash failed', 'tt'));
        case 'apply_card':
            $card_id = htmlspecialchars($_POST['card_id']);
            $card_secret = htmlspecialchars($_POST['card_secret']);
            $result = tt_add_cash_by_card($card_id, $card_secret);
            if ($result instanceof WP_Error) {
                return $result;
            } elseif ($result) {
                return tt_api_success(sprintf(__('Apply card to charge successfully, balance add %0.2f', 'tt'), $result / 100));
            }

            return tt_api_fail(__('Apply card to charge failed', 'tt'));
    }

    return null;
}
