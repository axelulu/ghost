<?php

/**
 * 获取用户的现金余额.
 *
 * @since 2.2.0
 *
 * @param int $user_id
 *
 * @return float
 */
function tt_get_user_cash($user_id = 0)
{
    $user_id = $user_id ?: get_current_user_id();
    // 注意 余额按分为单位存储
    return sprintf('%0.2f', (int) get_user_meta($user_id, 'tt_cash', true) / 100);
}

/**
 * 获取用户已经消费的现金.
 *
 * @since 2.2.0
 *
 * @param $user_id
 *
 * @return int
 */
function tt_get_user_consumed_cash($user_id = 0)
{
    $user_id = $user_id ?: get_current_user_id();

    return sprintf('%0.2f', (int) get_user_meta($user_id, 'tt_consumed_cash', true) / 100);
}

/**
 * 更新用户余额(充值或消费现金余额).
 *
 * @since 2.2.0
 *
 * @param int    $user_id
 * @param int    $amount(单位：分)
 * @param string $msg
 * @param bool   $admin_handle
 *
 * @return bool
 */
function tt_update_user_cash($user_id = 0, $amount = 0, $msg = '', $admin_handle = false)
{
    $user_id = $user_id ?: get_current_user_id();
    $before_cash = (int) get_user_meta($user_id, 'tt_cash', true);
    // 管理员直接更改用户余额
    if ($admin_handle) {
        $update = update_user_meta($user_id, 'tt_cash', max(0, (int) $amount) + $before_cash);
        if ($update) {
            // 添加余额变动消息
            $msg = $msg ?: sprintf(__('Administrator add %s cash to you, current cash balance %s', 'tt'), sprintf('%0.2f', max(0, (int) $amount) / 100), sprintf('%0.2f', max(0, (int) $amount) + $before_cash) / 100);
            tt_create_message($user_id, 0, 'System', 'cash', $msg, '', MsgReadStatus::UNREAD, 'publish');
        }

        return (bool) $update;
    }
    // 普通更新
    if ($amount > 0) {
        $update = update_user_meta($user_id, 'tt_cash', $before_cash + $amount); //Meta ID if the key didn't exist; true on successful update; false on failure or if $meta_value is the same as the existing meta value in the database.
        if ($update) {
            // 添加余额变动消息
            $msg = $msg ?: sprintf(__('Charge %s cash, current cash balance %s', 'tt'), sprintf('%0.2f', $amount / 100), sprintf('%0.2f', (int) ($amount + $before_cash) / 100));
            tt_create_message($user_id, 0, 'System', 'cash', $msg, '', MsgReadStatus::UNREAD, 'publish');
        }
    } elseif ($amount < 0) {
        if ($before_cash + $amount < 0) {
            return false;
        }
        $before_consumed = (int) get_user_meta($user_id, 'tt_consumed_cash', true);
        update_user_meta($user_id, 'tt_consumed_cash', $before_consumed - $amount);
        $update = update_user_meta($user_id, 'tt_cash', $before_cash + $amount);
        if ($update) {
            // 添加余额变动消息
            $msg = $msg ?: sprintf(__('Spend %s cash, current cash balance %s', 'tt'), sprintf('%0.2f', absint($amount) / 100), (int) ($before_cash + $amount) / 100);
            tt_create_message($user_id, 0, 'System', 'cash', $msg, '', MsgReadStatus::UNREAD, 'publish');
        }
    }

    return true;
}

/**
 * 余额充值到账(目前只能卡密充值).
 *
 * @since 2.2.0
 *
 * @param $card_id
 * @param $card_pwd
 *
 * @return bool|WP_Error
 */
function tt_add_cash_by_card($card_id, $card_pwd)
{
    $card = tt_get_card($card_id, $card_pwd);
    if (!$card) {
        return new WP_Error('card_not_exist', __('Card is not exist', 'tt'));
    } elseif ($card->status != 1) {
        return new WP_Error('card_invalid', __('Card is not valid', 'tt'));
    }

    tt_mark_card_used($card->id);

    $user = wp_get_current_user();
    $cash = intval($card->denomination);
    $balance = tt_get_user_cash($user->ID);
    $update = tt_update_user_cash($user->ID, $cash, sprintf(__('Charge <strong>%s</strong> Cash by card, current cash balance %s', 'tt'), sprintf('%0.2f', $cash / 100), sprintf('%0.2f', $cash / 100 + $balance)));

    // 发送邮件
    $blog_name = get_bloginfo('name');
    $subject = sprintf(__('Charge Cash Successfully - %s', 'tt'), $blog_name);
    $args = array(
        'blogName' => $blog_name,
        'cashNum' => sprintf('%0.2f', $cash / 100),
        'currentCash' => tt_get_user_cash($user->ID),
        'adminEmail' => get_option('admin_email'),
    );
    // tt_async_mail('', $user->user_email, $subject, $args, 'charge-cash-success');
    tt_mail('', $user->user_email, $subject, $args, 'charge-cash-success');
    if ($update) {
        return $cash; // 充值卡面额(分)
    }

    return $update;
}

/**
 * 使用现金余额支付.
 *
 * @since 2.2.0
 *
 * @param float  $amount
 * @param string $product_subject
 * @param bool   $rest
 *
 * @return bool|WP_Error
 */
function tt_cash_pay($amount = 0.0, $product_subject = '', $rest = false)
{
    $amount = abs($amount);
    $user_id = get_current_user_id();
    if (!$user_id) {
        return $rest ? new WP_Error('unknown_user', __('You must sign in before payment', 'tt')) : false;
    }

    $balance = (float) tt_get_user_cash($user_id);
    if ($amount - $balance >= 0.0001) {
        return $rest ? new WP_Error('insufficient_cash', __('You do not have enough cash to accomplish this payment', 'tt')) : false;
    }

    $msg = $product_subject ? sprintf(__('Cost %0.2f cash to buy %s, current cash balance %s', 'tt'), $amount, $product_subject, $balance - $amount) : '';
    tt_update_user_cash($user_id, (int) ($amount * (-100)), $msg); //TODO confirm update
    return true;
}

/**
 * 在后台用户列表中显示余额.
 *
 * @since 2.2.0
 *
 * @param $columns
 *
 * @return mixed
 */
function tt_cash_column($columns)
{
    $columns['tt_cash'] = __('Cash Balance', 'tt');

    return $columns;
}
add_filter('manage_users_columns', 'tt_cash_column');

function tt_cash_column_callback($value, $column_name, $user_id)
{
    if ('tt_cash' == $column_name) {
        $cash = intval(get_user_meta($user_id, 'tt_cash', true));
        $void = intval(get_user_meta($user_id, 'tt_consumed_cash', true));
        $value = sprintf(__('总额 %1$s 已消费 %2$s 余额 %3$s', 'tt'), sprintf('%0.2f', $cash + $void), sprintf('%0.2f', $void), sprintf('%0.2f', $cash));
    }

    return $value;
}
add_action('manage_users_custom_column', 'tt_cash_column_callback', 10, 3);
