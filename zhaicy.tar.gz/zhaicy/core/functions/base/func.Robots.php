<?php

/**
 * 对于部分链接，拒绝搜索引擎索引.
 *
 * @since   2.0.0
 *
 * @param string $output Robots.txt内容
 * @param bool   $public
 *
 * @return string
 */
function tt_robots_modification($output, $public)
{
    $output .= "\nDisallow: /oauth";
    $output .= "\nDisallow: /m";
    $output .= "\nDisallow: /me";

    return $output;
}
add_filter('robots_txt', 'tt_robots_modification', 10, 2);

/**
 * 为部分页面添加noindex的meta标签.
 *
 * @since   2.0.0
 */
function tt_add_noindex_meta()
{
    if (get_query_var('is_uc') || get_query_var('action') || get_query_var('site_util') || get_query_var('is_me_route')) {
        wp_no_robots();
    }
}
add_action('wp_head', 'tt_add_noindex_meta');
