<?php
/**
 * Copyright (c) 2016-2018, WebApproach.net
 * All right reserved.
 *
 * @since 2.7.0
 *
 * @author Zhiyan
 * @date 2018/5/12 1:31
 *
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @see https://webapproach.net/tint.html
 */

/**
 * 创建common服务绑定的错误.
 *
 * @param $message
 * @param int $status
 *
 * @return WP_Error
 */
function tt_create_common_error($message, $status = 400)
{
    return new WP_Error('rest_common_service_error', $message, array('status' => $status));
}

/**
 * 创建common服务绑定的响应.
 *
 * @param $data
 * @param string $message
 * @param int    $status
 *
 * @return array
 */
function tt_create_common_response($data, $message = '', $status = 200)
{
    return array(
        'data' => $data,
        'message' => $message,
        'code' => $status,
    );
}

function tt_exec_common_api_services($service, $params)
{
    $func_name = 'tt_exec_common_service_'.implode('_', explode('.', $service));
    if (!function_exists($func_name)) {
        return new WP_Error('rest_common_service_not_implement', __('Sorry, the service is not implemented.', 'tt'), array('status' => 400));
    }

    return $func_name($params);
}

////// services //////

/**
 * 积分小工具服务-数据.
 */
function tt_exec_common_service_common_widget_credit_data($params)
{
    $credits = intval(tt_get_user_credit());

    // $rules = array();
    $has_signed = false;
    if (get_user_meta($params['uid'], 'tt_daily_sign', true)) {
        date_default_timezone_set('Asia/Shanghai');
        $sign_date_meta = get_user_meta($params['uid'], 'tt_daily_sign', true);
        $sign_date = date('Y-m-d', strtotime($sign_date_meta));
        $now_date = date('Y-m-d', time());
        if ($sign_date == $now_date) {
            $has_signed = true;
        }
    }
    // $price = intval(tt_get_option('tt_hundred_credit_price', 1));
    $data = array(
        'credits' => $credits,
        'signed' => $has_signed,
        // 'price' => $price
    );

    return tt_create_common_response($data);
}

/**
 * 积分小工具服务-签到.
 */
function tt_exec_common_service_common_widget_credit_sign($params)
{
    $result = tt_daily_sign();
    if ($result instanceof WP_Error) {
        return tt_create_common_error($result->get_error_message(), $result->get_error_code());
    }
    return tt_create_common_response(array(
        'credits' => intval(tt_get_user_credit())
    ));
}
