<?php

/**
 * 保存文章时添加最近变动字段.
 *
 * @since   2.0.0
 *
 * @param   $post_ID
 */
function tt_add_post_review_fields($post_ID)
{
    if (!wp_is_post_revision($post_ID)) {
        update_post_meta($post_ID, 'tt_latest_reviewed', time());
    }
}
add_action('save_post', 'tt_add_post_review_fields');

/**
 * 删除文章时删除最近变动字段.
 *
 * @since   2.0.0
 *
 * @param   $post_ID
 */
function tt_delete_post_review_fields($post_ID)
{
    if (!wp_is_post_revision($post_ID)) {
        delete_post_meta($post_ID, 'tt_latest_reviewed');
    }
}
add_action('delete_post', 'tt_delete_post_review_fields');
