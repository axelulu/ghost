<?php

/**
 * 处理文章内容图片链接以支持lightbox.
 *
 * @since 2.0.0
 *
 * @param string $content
 *
 * @return string
 */

/**
 * 替换摘要more字样.
 *
 * @param $more
 *
 * @return mixed
 */
function tt_excerpt_more($more)
{
    $read_more = tt_get_option('tt_read_more', ' ···');

    return $read_more;
}
add_filter('excerpt_more', 'tt_excerpt_more');
