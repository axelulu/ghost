<?php

/**
 * 检查用户是否购买了文章内付费资源.
 *
 * @since 2.0.0
 *
 * @param $post_id
 * @param $resource_seq
 *
 * @return bool
 */
function tt_check_bought_post_resources($post_id, $resource_seq)
{
    $user_id = get_current_user_id();
    if (!$user_id) {
        return false;
    }

    $user_bought = get_user_meta($user_id, 'tt_bought_posts', true);
    if (empty($user_bought)) {
        return false;
    }
    $user_bought = maybe_unserialize($user_bought);
    if (!isset($user_bought['p_'.$post_id])) {
        return false;
    }

    $post_bought_resources = $user_bought['p_'.$post_id];
    if (isset($post_bought_resources[$resource_seq]) && $post_bought_resources[$resource_seq]) {
        return true;
    }

    return false;
}

/**
 * 购买文章内容资源.
 *
 * @since 2.0.0
 *
 * @param $post_id
 * @param $resource_seq
 * @param $is_new_type
 *
 * @return WP_Error|array
 */
function tt_bought_post_resource($post_id, $resource_seq, $is_new_type = false)
{
    $user = wp_get_current_user();
    $user_id = $user->ID;
    if (!$user_id) {
        return new WP_Error('user_not_signin', __('You must sign in to continue your purchase', 'tt'), array('status' => 401));
    }

    //检查文章资源是否存在
    $resource_meta_key = $is_new_type ? 'tt_sale_dl2' : 'tt_sale_dl';
    $post_resources = explode(PHP_EOL, trim(get_post_meta($post_id, $resource_meta_key, true)));
    if (!isset($post_resources[$resource_seq - 1])) {
        return new WP_Error('post_resource_not_exist', __('The resource you willing to buy is not existed', 'tt'), array('status' => 404));
    }
    $the_post_resource = explode('|', $post_resources[$resource_seq - 1]);
    // <!-- 资源名称|资源下载url1_密码1,资源下载url2_密码2|资源价格|币种 -->
    $currency = $is_new_type && isset($the_post_resource[3]) && strtolower(trim($the_post_resource[3]) === 'cash') ? 'cash' : 'credit';
    $price = isset($the_post_resource[2]) ? abs(trim($the_post_resource[2])) : 1;
    $resource_name = $the_post_resource[0];
    if ($is_new_type) {
        $pans = explode(',', $the_post_resource[1]);
        $pan_detail = explode('__', $pans[0]);
        $resource_link = $pan_detail[0];
        $resource_pass = isset($pan_detail[1]) ? trim($pan_detail[1]) : __('None', 'tt');
    } else {
        $resource_link = $the_post_resource[1];
        $resource_pass = isset($the_post_resource[3]) ? trim($the_post_resource[3]) : __('None', 'tt');
    }

    //检查是否已购买
    if ($is_new_type ? tt_check_bought_post_resources2($post_id, $resource_seq) : tt_check_bought_post_resources($post_id, $resource_seq)) {
        return new WP_Error('post_resource_bought', __('You have bought the resource yet, do not repeat a purchase', 'tt'), array('status' => 200));
    }

    // 先计算VIP价格优惠
    $member = new Member($user);
    $vip_price = $price;
    $vip_type = $member->vip_type;
    switch ($vip_type) {
        case Member::MONTHLY_VIP:
            $vip_price = absint(tt_get_option('tt_monthly_vip_discount', 100) * $price / 100);
            break;
        case Member::ANNUAL_VIP:
            $vip_price = absint(tt_get_option('tt_annual_vip_discount', 90) * $price / 100);
            break;
        case Member::PERMANENT_VIP:
            $vip_price = absint(tt_get_option('tt_permanent_vip_discount', 80) * $price / 100);
            break;
    }
    $vip_string = tt_get_member_type_string($vip_type);

    if ($is_new_type) {
        $create = tt_create_resource_order($post_id, $resource_name, $resource_seq, $vip_price, $currency === 'cash');
        if ($create instanceof WP_Error) {
            return $create;
        } elseif (!$create) {
            return new WP_Error('create_order_failed', __('Create order failed', 'tt'));
        }
        $checkout_nonce = wp_create_nonce('checkout');
        $checkout_url = add_query_arg(array('oid' => $create['order_id'], 'spm' => $checkout_nonce), tt_url_for('checkout'));
        if ($vip_price - 0 >= 0.01) {
            $create['url'] = $checkout_url;
        } else {
            $create = array_merge($create, array(
                'cost' => 0,
                'text' => sprintf(__('消费: %1$d (%2$s优惠, 原价%3$d)', 'tt'), $vip_price, $vip_string, $price),
                'vip_str' => $vip_string,
            ));
        }

        return tt_api_success(__('Create order successfully', 'tt'), array('data' => $create));
    } else {
        //检查用户积分是否足够
        $payment = tt_credit_pay($vip_price, $resource_name, true);
        if ($payment instanceof WP_Error) {
            return $payment;
        }

        $user_bought = get_user_meta($user_id, 'tt_bought_posts', true);
        if (empty($user_bought)) {
            $user_bought = array(
                'p_'.$post_id => array($resource_seq => true),
            );
        } else {
            $user_bought = maybe_unserialize($user_bought);
            if (!isset($user_bought['p_'.$post_id])) {
                $user_bought['p_'.$post_id] = array($resource_seq => true);
            } else {
                $buy_seqs = $user_bought['p_'.$post_id];
                $buy_seqs[$resource_seq] = true;
                $user_bought['p_'.$post_id] = $buy_seqs;
            }
        }
        $save = maybe_serialize($user_bought);
        $update = update_user_meta($user_id, 'tt_bought_posts', $save); //Meta ID if the key didn't exist; true on successful update; false on failure or if $meta_value is the same as the existing meta value in the database.
        if (!$update) { //TODO 返还扣除的积分
            return new WP_Error('post_resource_bought_failure', __('Failed to buy the resource, or maybe you have bought before', 'tt'), array('status' => 500));
        }

        // 发送邮件
        $subject = __('Payment for the resource finished successfully', 'tt');
        $balance = get_user_meta($user_id, 'tt_credits', true);
        $args = array(
            'adminEmail' => get_option('admin_email'),
            'resourceName' => $resource_name,
            'resourceLink' => $resource_link,
            'resourcePass' => $resource_pass,
            'spentCredits' => $price,
            'creditsBalance' => $balance,
        );
        tt_async_mail('', $user->user_email, $subject, $args, 'buy-resource');

        if ($price - $vip_price > 0) {
            $text = sprintf(__('消费积分: %1$d (%2$s优惠, 原价%3$d)<br>当前积分余额: %2$d', 'tt'), $vip_price, $vip_string, $price, $balance);
            $cost = $vip_price;
        } else {
            $text = sprintf(__('消费积分: %1$d<br>当前积分余额: %2$d', 'tt'), $price, $balance);
            $cost = $price;
        }

        return array(
            'cost' => $cost,
            'text' => $text,
            'vip_str' => $vip_string,
            'balance' => $balance,
        );
    }
}

// 2.4+ 新引入

/**
 * 内嵌资源积分返还给作者.
 *
 * @since 2.6.0
 */
function tt_add_bought_resource_rewards($order_id)
{
    $order = tt_get_order($order_id);
    if (!$order || $order->order_status != OrderStatus::TRADE_SUCCESS) {
        return;
    }

    preg_match('/([0-9]+)_([0-9]+)/i', $order_id, $matches);
    if (!$matches || count($matches) < 3) {
        return;
    }

    $resource_seq = $matches[2] * 1;

    $product_id = $order->product_id;

    $author_id = get_post_field('post_author', $product_id);

    $post_resources = explode(PHP_EOL, trim(get_post_meta($product_id, 'tt_sale_dl2', true)));
    if (!isset($post_resources[$resource_seq - 1])) {
        return false;
    }

    // <!-- 资源名称|资源下载url1_密码1,资源下载url2_密码2|资源价格|币种 -->
    $currency = $order->order_currency;
    $price = $order->order_total_price * 1;
    $resource_name = $order->product_name;

    if ($currency == 'cash') {
        $ratio = tt_get_option('tt_hundred_credit_price', 1);
        $price = $price / $ratio * 100;
    } else {
        $price = $price * 1;
    }

    return tt_update_user_credit($author_id, $price, sprintf(__('付费资源>>%1$s<<售出奖励%2$d积分', 'tt'), $resource_name, $price), false);
}
add_action('tt_order_status_change', 'tt_add_bought_resource_rewards');

/**
 * 创建资源订单(文章内嵌资源对接订单系统).
 *
 * @since 2.4.0
 *
 * @param $product_id
 * @param string $product_name
 * @param number $resource_seq
 * @param $order_price
 * @param $is_cash
 *
 * @return bool|array
 */
function tt_create_resource_order($product_id, $product_name, $resource_seq, $order_price = 1, $is_cash)
{
    $user_id = get_current_user_id();
    $order_id = tt_generate_order_num().'_'.$resource_seq;
    $order_time = current_time('mysql');
    $currency = $is_cash ? 'cash' : 'credit';
    $order_quantity = 1;
    $order_total_price = $order_price;

    global $wpdb;
    $prefix = $wpdb->prefix;
    $orders_table = $prefix.'tt_orders';
    $insert = $wpdb->insert(
        $orders_table,
        array(
            'parent_id' => 0,
            'order_id' => $order_id,
            'product_id' => $product_id,
            'product_name' => $product_name,
            'order_time' => $order_time,
            'order_price' => $order_price,
            'order_currency' => $currency,
            'order_quantity' => $order_quantity,
            'order_total_price' => $order_total_price,
            'user_id' => $user_id,
            'order_status' => $order_total_price - 0 < 0.01 ? OrderStatus::TRADE_SUCCESS : OrderStatus::WAIT_PAYMENT,
        ),
        array(
            '%d',
            '%s',
            '%d',
            '%s',
            '%s',
            '%f',
            '%s',
            '%d',
            '%f',
            '%d',
            '%d',
        )
    );
    if ($insert) {
        // 新创建现金订单时邮件通知管理员
        if ($currency == 'cash') {
            do_action('tt_order_status_change', $order_id);
        }

        return array(
            'insert_id' => $wpdb->insert_id,
            'order_id' => $order_id,
            'total_price' => $order_total_price,
        );
    }

    return false;
}

/**
 * 检查用户是否购买了文章内付费资源.
 *
 * @since 2.0.0
 *
 * @param $post_id
 * @param $resource_seq
 *
 * @return bool
 */
function tt_check_bought_post_resources2($post_id, $resource_seq)
{
    $user_id = get_current_user_id();
    if (!$user_id) {
        return false;
    }

    $orders = tt_get_user_post_resource_orders($user_id, $post_id);
    if (count($orders) == 0) {
        return false;
    }

    $suffix = '_'.$resource_seq;
    $length = strlen($suffix);
    foreach ($orders as $order) {
        if (substr($order->order_id, -1 * $length) == $suffix) {
            return true;
        }
    }

    return false;
}

/**
 * 获取文章内嵌的资源列表.
 *
 * @param $post_id
 *
 * @return array
 */
function tt_get_post_sale_resources($post_id)
{
    $sale_dls = trim(get_post_meta($post_id, 'tt_sale_dl2', true));
    $sale_dls = !empty($sale_dls) ? explode(PHP_EOL, $sale_dls) : array();
    $resources = array();
    $seq = 0;
    foreach ($sale_dls as $sale_dl) {
        $sale_dl = explode('|', $sale_dl);
        if (count($sale_dl) < 3) {
            continue;
        } else {
            ++$seq;
        }
        $resource = array();
        $resource['seq'] = $seq;
        $resource['name'] = $sale_dl[0];
        $pans = explode(',', $sale_dl[1]);
        $downloads = array();
        foreach ($pans as $pan) {
            $pan_details = explode('__', $pan);
            array_push($downloads, array(
               'url' => $pan_details[0],
                'password' => $pan_details[1],
            ));
        }
        $resource['downloads'] = $downloads;
        $resource['price'] = isset($sale_dl[2]) ? trim($sale_dl[2]) : 1;
        $resource['currency'] = isset($sale_dl[3]) && strtolower(trim($sale_dl[3])) == 'cash' ? 'cash' : 'credit';
        array_push($resources, $resource);
    }

    return $resources;
}

/**
 * 获取并生成文章内嵌资源的HTML内容用于邮件发送
 *
 * @param $post_id
 * @param $seq
 *
 * @return array|string
 */
function tt_get_post_download_content($post_id, $seq)
{
    $content = '';
    $resources = tt_get_post_sale_resources($post_id);
    if ($seq == 0 || $seq > count($resources)) {
        return $content;
    }
    $resource = $resources[$seq - 1];
    $downloads = $resource['downloads'];
    foreach ($downloads as $download) {
        $content .= sprintf(__('<li style="margin: 0 0 10px 0;"><p style="padding: 5px 0; margin: 0;">%1$s</p><p style="padding: 5px 0; margin: 0;">下载链接：<a href="%2$s" title="%1$s" target="_blank">%2$s</a>下载密码：%3$s</p></li>', 'tt'), $resource['name'], $download['url'], $download['password']);
    }

    return $content;
}
