<?php

/* Vue shared global vars */
defined('VUETT') || define('VUETT', array(
    'uid' => get_current_user_id(),
    'publicPath' => THEME_ASSET,
    'home' => esc_url_raw(home_url()),
    'themeRoot' => THEME_URI,
    'commonServiceApi' => home_url('/api/v1/commonservice'),
    '_wpnonce' => wp_create_nonce('wp_rest')
));

if ($_SERVER['REMOTE_ADDR'] == '127.0.0.1' && THREAD_DEBUG) {
    defined('FULL_THREAD_JS_VENDOR') || define('FULL_THREAD_JS_VENDOR',  'tt_home', THEME_ASSET,'/js/vendor.js');
    defined('FULL_THREAD_JS_APP') || define('FULL_THREAD_JS_APP', 'tt_home', THEME_ASSET,'/js/thread.js');
} else {
    defined('FULL_THREAD_JS_VENDOR') || define('FULL_THREAD_JS_VENDOR', THEME_ASSET.'/react/'.JS_THREAD_VENDOR);
    defined('FULL_THREAD_JS_APP') || define('FULL_THREAD_JS_APP', THEME_ASSET.'/react/'.JS_THREAD_APP);
}

/**
 * 注册Scripts.
 *
 * @since   2.0.0
 */
function tt_register_scripts()
{
   /* $jquery_url = json_decode(JQUERY_SOURCES)->{tt_get_option('tt_jquery', 'local_1')};
    wp_register_script('tt_jquery', $jquery_url, array(), null, tt_get_option('tt_foot_jquery', false));
    //wp_register_script( 'tt_common', THEME_CDN_ASSET . '/js/' . JS_COMMON, array(), null, true );
    wp_register_script('tt_home', THEME_CDN_ASSET.'/js/'.JS_HOME, array(), null, true);
    wp_register_script('tt_front_page', THEME_CDN_ASSET.'/js/'.JS_FRONT_PAGE, array(), null, true);
    wp_register_script('tt_single_post', THEME_CDN_ASSET.'/js/'.JS_SINGLE, array(), null, true);
    wp_register_script('tt_single_page', THEME_CDN_ASSET.'/js/'.JS_PAGE, array(), null, true);
    wp_register_script('tt_archive_page', THEME_CDN_ASSET.'/js/'.JS_ARCHIVE, array(), null, true);
    wp_register_script('tt_product_page', THEME_CDN_ASSET.'/js/'.JS_PRODUCT, array(), null, true);
    wp_register_script('tt_products_page', THEME_CDN_ASSET.'/js/'.JS_PRODUCT_ARCHIVE, array(), null, true);
    wp_register_script('tt_uc_page', THEME_CDN_ASSET.'/js/'.JS_UC, array(), null, true);
    wp_register_script('tt_me_page', THEME_CDN_ASSET.'/js/'.JS_ME, array(), null, true);
    wp_register_script('tt_action_page', THEME_CDN_ASSET.'/js/'.JS_ACTION, array(), null, true);
    wp_register_script('tt_404_page', THEME_CDN_ASSET.'/js/'.JS_404, array(), null, true);
    wp_register_script('tt_site_utils', THEME_CDN_ASSET.'/js/'.JS_SITE_UTILS, array(), null, true);
    wp_register_script('tt_oauth_page', THEME_CDN_ASSET.'/js/'.JS_OAUTH, array(), null, true);
    wp_register_script('tt_manage_page', THEME_CDN_ASSET.'/js/'.JS_MANAGE, array(), null, true);
    wp_register_script('tt_thread_page', THEME_CDN_ASSET.'/js/'.JS_THREAD, array(), null, true);
    wp_register_script('tt_thread_vendor', FULL_THREAD_JS_VENDOR, array(), null, true);
    wp_register_script('tt_thread_app', FULL_THREAD_JS_APP, array('tt_thread_vendor'), null, true);
*/
   $jquery_url = json_decode(JQUERY_SOURCES)->{tt_get_option('tt_jquery', 'local_1')};
    wp_register_script('tt_jquery', $jquery_url, array(), null, tt_get_option('tt_foot_jquery', false));
    //wp_register_script( 'tt_common', THEME_ASSET . '/js/' . JS_COMMON, array(), null, true );
    wp_register_script('tt_home', THEME_ASSET.'/js/'.JS_HOME, array(), null, true);
    wp_register_script('tt_front_page', THEME_ASSET.'/js/'.JS_FRONT_PAGE, array(), null, true);
    wp_register_script('tt_single_post', THEME_ASSET.'/js/'.JS_SINGLE, array(), null, true);
    wp_register_script('tt_single_page', THEME_ASSET.'/js/'.JS_PAGE, array(), null, true);
    wp_register_script('tt_archive_page', THEME_ASSET.'/js/'.JS_ARCHIVE, array(), null, true);
    wp_register_script('tt_product_page', THEME_ASSET.'/js/'.JS_PRODUCT, array(), null, true);
    wp_register_script('tt_products_page', THEME_ASSET.'/js/'.JS_PRODUCT_ARCHIVE, array(), null, true);
    wp_register_script('tt_uc_page', THEME_ASSET.'/js/'.JS_UC, array(), null, true);
    wp_register_script('tt_me_page', THEME_ASSET.'/js/'.JS_ME, array(), null, true);
    wp_register_script('tt_action_page', THEME_ASSET.'/js/'.JS_ACTION, array(), null, true);
    wp_register_script('tt_404_page', THEME_ASSET.'/js/'.JS_404, array(), null, true);
    wp_register_script('tt_site_utils', THEME_ASSET.'/js/'.JS_SITE_UTILS, array(), null, true);
    wp_register_script('tt_oauth_page', THEME_ASSET.'/js/'.JS_OAUTH, array(), null, true);
    wp_register_script('tt_manage_page', THEME_ASSET.'/js/'.JS_MANAGE, array(), null, true);
    wp_register_script('tt_thread_page', THEME_ASSET.'/js/'.JS_THREAD, array(), null, true);
    wp_register_script('tt_thread_vendor', FULL_THREAD_JS_VENDOR, array(), null, true);
    wp_register_script('tt_thread_app', FULL_THREAD_JS_APP, array('tt_thread_vendor'), null, true);
    global $tt_auth_config;
    $data = array(
        'debug' => tt_get_option('tt_theme_debug', false),
        'uid' => get_current_user_id(),
        'language' => get_option('WPLANG', 'zh_CN'),
        'apiRoot' => esc_url_raw(get_rest_url()),
        '_wpnonce' => wp_create_nonce('wp_rest'), // REST_API服务验证该nonce, 如果不提供将清除登录用户信息  @see rest-api.php `rest_cookie_check_errors`
        'home' => esc_url_raw(home_url()),
        'themeRoot' => THEME_URI,
        'isHome' => is_home(),
        'commentsPerPage' => tt_get_option('tt_comments_per_page', 20),
        'sessionApiTail' => tt_get_option('tt_session_api', 'session'),
        'contributePostWordsMin' => absint(tt_get_option('tt_contribute_post_words_min', 100)),
        'o' => $tt_auth_config['order'],
        'e' => get_bloginfo('admin_email'),
        'v' => trim(wp_get_theme()->get('Version')),
        'yzApi' => tt_get_option('tt_youzan_util_api', ''),
        'siteName' => get_bloginfo('name'),
        'weiboKey' => tt_get_option('tt_weibo_openkey'),
        'threadSlug' => tt_get_option('tt_thread_archives_slug', 'thread'),
        'threadVendor' => FULL_THREAD_JS_VENDOR,
        'publicPath' => THEME_ASSET,
    );
    if (is_single()) {
        $data['isSingle'] = true;
        $data['pid'] = get_queried_object_id();
    }
    //wp_localize_script( 'tt_common', 'TT', $data );
    wp_enqueue_script('tt_jquery');
    //wp_enqueue_script( 'tt_common' );
    $script = '';
    $post_type = get_post_type();

    if (is_home()) {
        $script = 'tt_home';
    } elseif ($post_type === 'thread' || get_query_var('is_thread_route')) {
        $script = array('tt_thread_vendor', 'tt_thread_app');
    } elseif (is_single()) {
        $script = $post_type === 'product' ? 'tt_product_page' : ($post_type === 'bulletin' ? 'tt_single_page' : 'tt_single_post');
    } elseif ((is_archive() && !is_author()) || (is_search() && isset($_GET['in_shop']) && $_GET['in_shop'] == 1)) {
        $script = $post_type === 'product' || (is_search() && isset($_GET['in_shop']) && $_GET['in_shop'] == 1) ? 'tt_products_page' : 'tt_archive_page';
    } elseif (is_author()) {
        $script = 'tt_uc_page';
    } elseif (is_404()) {
        $script = 'tt_404_page';
    } elseif (get_query_var('is_me_route')) {
        $script = 'tt_me_page';
    } elseif (get_query_var('action')) {
        $script = 'tt_action_page';
    } elseif (is_front_page()) {
        $script = 'tt_front_page';
    } elseif (get_query_var('site_util')) {
        $script = 'tt_site_utils';
    } elseif (get_query_var('oauth')) {
        $script = 'tt_oauth_page';
    } elseif (get_query_var('is_manage_route')) {
        $script = 'tt_manage_page';
    } else {
        // is_page() ?
        $script = 'tt_single_page';
    }

    if ($script) {
        if (!is_array($script)) {
            $script = array($script);
        }
        foreach ($script as $key => $item) {
            if ($key == 0) {
                wp_localize_script($item, 'TT', $data);
            }
            wp_enqueue_script($item);
        }
    }
}
add_action('wp_enqueue_scripts', 'tt_register_scripts');
