<?php

/**
 * 允许投稿者上传图片.
 */
function tt_allow_contributor_uploads()
{
    $contributor = get_role('contributor');
    $contributor->add_cap('upload_files');
}

if (current_user_can('contributor') && !current_user_can('upload_files')) {
    add_action('init', 'tt_allow_contributor_uploads');
}

/**
 * 前台投稿页面的媒体上传预览准备数据filter掉post_id.
 */
function tt_remove_post_id_for_front_contribute($settings)
{
    if (get_query_var('me_child_route') === 'newpost') {
        $settings['post'] = array();
    }

    return $settings;
}

if (!is_admin()) {
    add_filter('media_view_settings', 'tt_remove_post_id_for_front_contribute', 10, 1);
}
