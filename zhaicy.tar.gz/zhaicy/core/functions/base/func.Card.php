<?php

/**
 * 通过卡号卡密获取卡记录.
 *
 * @since 2.2.0
 *
 * @param $card_id
 * @param $card_secret
 *
 * @return array|null|object|void
 */
function tt_get_card($card_id, $card_secret)
{
    global $wpdb;
    $prefix = $wpdb->prefix;
    $cards_table = $prefix.'tt_cards';
    $row = $wpdb->get_row(sprintf("SELECT * FROM $cards_table WHERE `card_id`='%s' AND `card_secret`='%s'", $card_id, $card_secret));

    return $row;
}

/**
 * 标记卡已被使用.
 *
 * @since 2.2.0
 *
 * @param $id
 *
 * @return false|int
 */
function tt_mark_card_used($id)
{
    global $wpdb;
    $prefix = $wpdb->prefix;
    $cards_table = $prefix.'tt_cards';
    $update = $wpdb->update(
        $cards_table,
        array(
            'status' => 0,
        ),
        array('id' => $id),
        array('%d'),
        array('%d')
    );

    return $update;
}

/**
 * 统计卡数量.
 *
 * @since 2.2.0
 *
 * @param $in_effect
 *
 * @return int
 */
function tt_count_cards($in_effect = false)
{
    global $wpdb;
    $prefix = $wpdb->prefix;
    $cards_table = $prefix.'tt_cards';
    if ($in_effect) {
        $sql = sprintf("SELECT COUNT(*) FROM $cards_table WHERE `status`=1");
    } else {
        $sql = "SELECT COUNT(*) FROM $cards_table";
    }
    $count = $wpdb->get_var($sql);

    return $count;
}

/**
 * 删除card记录.
 *
 * @since 2.2.0
 *
 * @param $id
 *
 * @return bool
 */
function tt_delete_card($id)
{
    global $wpdb;
    $prefix = $wpdb->prefix;
    $cards_table = $prefix.'tt_cards';
    $delete = $wpdb->delete(
        $cards_table,
        array('id' => $id),
        array('%d')
    );

    return (bool) $delete;
}

/**
 * 随机生成一定数量的卡
 *
 * @since 2.2.0
 *
 * @param $quantity
 * @param $denomination
 *
 * @return array | bool
 */
function tt_gen_cards($quantity, $denomination)
{
    $raw_cards = array();
    $cards = array();
    $place_holders = array();
    $denomination = absint($denomination);
    $create_time = current_time('mysql');
    for ($i = 0; $i < $quantity; ++$i) {
        $card_id = Utils::generateRandomStr(10, 'number');
        $card_secret = Utils::generateRandomStr(16);
        array_push($raw_cards, array(
            'card_id' => $card_id,
            'card_secret' => $card_secret,
        ));
        array_push($cards, $card_id, $card_secret, $denomination, $create_time, 1);
        array_push($place_holders, "('%s', '%s', '%d', '%s', '%d')");
    }

    global $wpdb;
    $prefix = $wpdb->prefix;
    $cards_table = $prefix.'tt_cards';

    $query = "INSERT INTO $cards_table (card_id, card_secret, denomination, create_time, status) VALUES ";
    $query .= implode(', ', $place_holders);
    $result = $wpdb->query($wpdb->prepare("$query ", $cards));

    if (!$result) {
        return false;
    }

    return $raw_cards;
}

/**
 * 获取多条充值卡
 *
 * @since 2.2.0
 *
 * @param int  $limit
 * @param int  $offset
 * @param bool $in_effect
 *
 * @return array|null|object
 */
function tt_get_cards($limit = 20, $offset = 0, $in_effect = false)
{
    global $wpdb;
    $prefix = $wpdb->prefix;
    $cards_table = $prefix.'tt_cards';
    if ($in_effect) {
        $sql = sprintf("SELECT * FROM $cards_table WHERE `status`=1 ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset);
    } else {
        $sql = sprintf("SELECT * FROM $cards_table ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset);
    }
    $results = $wpdb->get_results($sql);

    return $results;
}
