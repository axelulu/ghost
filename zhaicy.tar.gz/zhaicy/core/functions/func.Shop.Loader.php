<?php

/**
 * Copyright (c) 2014-2017, WebApproach.net
 * All right reserved.
 *
 * @since 2.0.0
 *
 * @author Zhiyan
 * @date 2017/12/30 14:55
 *
 * @license GPL v3 LICENSE
 * @license uri http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @see https://webapproach.net/tint.html
 */
?>
<?php

load_func('shop/func.Shop');

load_func('shop/func.Order');

load_func('shop/func.Coupon');

load_func('shop/func.Cart');

load_func('shop/func.Address');

load_func('shop/func.Schedule');

load_func('shop/alipay/func.Alipay');
